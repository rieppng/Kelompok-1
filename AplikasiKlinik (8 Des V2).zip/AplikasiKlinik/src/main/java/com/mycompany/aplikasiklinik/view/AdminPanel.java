// File: com/mycompany/aplikasiklinik/view/AdminPanel.java (diupdate)
package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty;
import com.mycompany.aplikasiklinik.model.entity.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdminPanel extends JPanel {

    // --- Komponen Asli ---
    private final JTextField txtNewUsername = new JTextField(15);
    private final JTextField txtNewPassword = new JTextField(15);
    private final JTextField txtFullname = new JTextField(20);
    private final JComboBox<String> comboRole = new JComboBox<>(new String[]{"RECEPTIONIST", "DOCTOR", "PHARMACIST", "CASHIER", "SUPERADMIN"});

    private final JButton btnAddUser = new JButton("Tambah User");
    private final JButton btnNavFeeManagement = new JButton("Kelola Biaya Layanan");

    private final JTable tableUsers = new JTable();
    private DefaultTableModel userTableModel;

    // --- Komponen Baru: CRUD Poli ---
    private final JTextField txtSpecialtyName = new JTextField(20);
    private final JTable tableSpecialties = new JTable();
    private DefaultTableModel specialtyTableModel;
    private final JButton btnAddSpecialty = new JButton("Tambah Poli");
    private final JButton btnUpdateSpecialty = new JButton("Update Poli");
    private final JButton btnDeleteSpecialty = new JButton("Hapus Poli");

    // --- Komponen Baru: Tambah Dokter ---
    private final JTextField txtDoctorUsername = new JTextField(15);
    private final JTextField txtDoctorPassword = new JTextField(15);
    private final JTextField txtDoctorFullname = new JTextField(20);
    private final JComboBox<MedicalSpecialty> comboDoctorSpecialty = new JComboBox<>();
    private final JTextField txtDoctorConsultationFee = new JTextField(10); // Baru: Biaya Jasa
    private final JButton btnAddDoctor = new JButton("Tambah Dokter");

    // --- Komponen Baru: Cari & Update Dokter ---
    private final JTextField txtSearchDoctorId = new JTextField(10);
    private final JButton btnSearchDoctor = new JButton("Cari Dokter");
    private final JTextField txtUpdateUsername = new JTextField(15);
    private final JTextField txtUpdateFullname = new JTextField(20);
    private final JComboBox<MedicalSpecialty> comboUpdateSpecialty = new JComboBox<>();
    private final JTextField txtUpdateConsultationFee = new JTextField(10); // Baru: Biaya Jasa
    private final JButton btnUpdateDoctor = new JButton("Update Dokter");

    public AdminPanel() {
        setLayout(new BorderLayout());
        initializeComponents();
        setupLayout();
    }

    private void initializeComponents() {
        // Inisialisasi model tabel user
        userTableModel = new DefaultTableModel(new Object[]{"ID", "Username", "Nama", "Role", "Aktif", "Biaya Jasa"}, 0) { // Tambahkan kolom
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableUsers.setModel(userTableModel);

        // Inisialisasi model tabel poli
        specialtyTableModel = new DefaultTableModel(new Object[]{"ID", "Nama Poli"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableSpecialties.setModel(specialtyTableModel);
    }

    private void setupLayout() {
        // Panel Utama (Tabbed)
        JTabbedPane tabbedPane = new JTabbedPane();

        // --- Tab 1: Manajemen User (Asli) ---
        JPanel userPanel = new JPanel(new BorderLayout());
        JPanel userFormPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        userFormPanel.setBorder(BorderFactory.createTitledBorder("Tambah Staff Baru"));
        userFormPanel.add(new JLabel("Username:")); userFormPanel.add(txtNewUsername);
        userFormPanel.add(new JLabel("Password:")); userFormPanel.add(txtNewPassword);
        userFormPanel.add(new JLabel("Nama Lengkap:")); userFormPanel.add(txtFullname);
        userFormPanel.add(new JLabel("Role:")); userFormPanel.add(comboRole);
        userFormPanel.add(new JLabel("")); userFormPanel.add(btnAddUser);
        userPanel.add(userFormPanel, BorderLayout.NORTH);
        userPanel.add(new JScrollPane(tableUsers), BorderLayout.CENTER);
        tabbedPane.addTab("Manajemen User", userPanel);

        // --- Tab 2: Manajemen Poli ---
        JPanel specialtyPanel = new JPanel(new BorderLayout());
        JPanel specialtyFormPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        specialtyFormPanel.setBorder(BorderFactory.createTitledBorder("Tambah/Update Poli"));
        specialtyFormPanel.add(new JLabel("Nama Poli:")); specialtyFormPanel.add(txtSpecialtyName);
        JPanel specialtyButtonPanel = new JPanel();
        specialtyButtonPanel.add(btnAddSpecialty);
        specialtyButtonPanel.add(btnUpdateSpecialty);
        specialtyButtonPanel.add(btnDeleteSpecialty);
        specialtyFormPanel.add(new JLabel("")); specialtyFormPanel.add(specialtyButtonPanel);
        specialtyPanel.add(specialtyFormPanel, BorderLayout.NORTH);
        specialtyPanel.add(new JScrollPane(tableSpecialties), BorderLayout.CENTER);
        tabbedPane.addTab("Manajemen Poli", specialtyPanel);

        // --- Tab 3: Tambah Dokter ---
        JPanel addDoctorPanel = new JPanel(new BorderLayout());
        JPanel addDoctorFormPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        addDoctorFormPanel.setBorder(BorderFactory.createTitledBorder("Tambah Dokter Baru"));
        addDoctorFormPanel.add(new JLabel("Username:")); addDoctorFormPanel.add(txtDoctorUsername);
        addDoctorFormPanel.add(new JLabel("Password:")); addDoctorFormPanel.add(txtDoctorPassword);
        addDoctorFormPanel.add(new JLabel("Nama Lengkap:")); addDoctorFormPanel.add(txtDoctorFullname);
        addDoctorFormPanel.add(new JLabel("Poli:")); addDoctorFormPanel.add(comboDoctorSpecialty);
        addDoctorFormPanel.add(new JLabel("Biaya Jasa (Rp):")); addDoctorFormPanel.add(txtDoctorConsultationFee); // Baru
        addDoctorFormPanel.add(new JLabel("")); addDoctorFormPanel.add(btnAddDoctor);
        addDoctorPanel.add(addDoctorFormPanel, BorderLayout.NORTH);
        tabbedPane.addTab("Tambah Dokter", addDoctorPanel);

        // --- Tab 4: Cari & Update Dokter ---
        JPanel updateDoctorPanel = new JPanel(new BorderLayout());
        JPanel updateDoctorFormPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        updateDoctorFormPanel.setBorder(BorderFactory.createTitledBorder("Cari & Update Dokter"));

        updateDoctorFormPanel.add(new JLabel("Cari ID Dokter:")); updateDoctorFormPanel.add(txtSearchDoctorId);
        updateDoctorFormPanel.add(new JLabel("")); updateDoctorFormPanel.add(btnSearchDoctor); // Placeholder dan tombol

        updateDoctorFormPanel.add(new JLabel("Username:")); updateDoctorFormPanel.add(txtUpdateUsername);
        updateDoctorFormPanel.add(new JLabel("Nama Lengkap:")); updateDoctorFormPanel.add(txtUpdateFullname);
        updateDoctorFormPanel.add(new JLabel("Poli:")); updateDoctorFormPanel.add(comboUpdateSpecialty);
        updateDoctorFormPanel.add(new JLabel("Biaya Jasa (Rp):")); updateDoctorFormPanel.add(txtUpdateConsultationFee); // Baru
        updateDoctorFormPanel.add(new JLabel("")); updateDoctorFormPanel.add(btnUpdateDoctor); // Placeholder dan tombol

        updateDoctorPanel.add(updateDoctorFormPanel, BorderLayout.NORTH);
        tabbedPane.addTab("Update Dokter", updateDoctorPanel);

        // Panel Navigasi (Utara)
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        navPanel.setBorder(BorderFactory.createTitledBorder("Navigasi Admin"));
        navPanel.add(btnNavFeeManagement);
        add(navPanel, BorderLayout.NORTH);

        add(tabbedPane, BorderLayout.CENTER);
    }

    // --- Getter untuk komponen asli ---
    public String getUsername() { return txtNewUsername.getText(); }
    public String getPassword() { return txtNewPassword.getText(); }
    public String getFullname() { return txtFullname.getText(); }
    public String getSelectedRole() { return (String) comboRole.getSelectedItem(); }
    public JButton getBtnAddUser() { return btnAddUser; }
    public JButton getBtnNavFeeManagement() { return btnNavFeeManagement; }
    public DefaultTableModel getUserTableModel() { return userTableModel; }

    // --- Getter untuk komponen CRUD Poli ---
    public String getSpecialtyNameInput() { return txtSpecialtyName.getText(); }
    public JTable getTableSpecialties() { return tableSpecialties; }
    public DefaultTableModel getSpecialtyTableModel() { return specialtyTableModel; }
    public JButton getBtnAddSpecialty() { return btnAddSpecialty; }
    public JButton getBtnUpdateSpecialty() { return btnUpdateSpecialty; }
    public JButton getBtnDeleteSpecialty() { return btnDeleteSpecialty; }
    public JTextField getTxtSpecialtyName() { return txtSpecialtyName; }

    // --- Getter untuk komponen Tambah Dokter ---
    public String getDoctorUsername() { return txtDoctorUsername.getText(); }
    public String getDoctorPassword() { return txtDoctorPassword.getText(); }
    public String getDoctorFullname() { return txtDoctorFullname.getText(); }
    public MedicalSpecialty getSelectedDoctorSpecialty() { return (MedicalSpecialty) comboDoctorSpecialty.getSelectedItem(); }
    public String getDoctorConsultationFee() { return txtDoctorConsultationFee.getText(); } // Baru
    public JButton getBtnAddDoctor() { return btnAddDoctor; }

    // --- Getter untuk komponen Cari & Update Dokter ---
    public String getSearchDoctorId() { return txtSearchDoctorId.getText(); } // Baru
    public JButton getBtnSearchDoctor() { return btnSearchDoctor; } // Baru
    public JTextField getTxtUpdateUsername() { return txtUpdateUsername; } // Baru
    public JTextField getTxtUpdateFullname() { return txtUpdateFullname; } // Baru
    public JComboBox<MedicalSpecialty> getComboUpdateSpecialty() { return comboUpdateSpecialty; } // Baru
    public JTextField getTxtUpdateConsultationFee() { return txtUpdateConsultationFee; } // Baru
    public JButton getBtnUpdateDoctor() { return btnUpdateDoctor; } // Baru

    public void clearForm() {
        txtNewUsername.setText("");
        txtNewPassword.setText("");
        txtFullname.setText("");
    }

    public void clearSpecialtyForm() {
        txtSpecialtyName.setText("");
        tableSpecialties.clearSelection();
        btnUpdateSpecialty.setEnabled(false);
        btnDeleteSpecialty.setEnabled(false);
    }

    public void clearAddDoctorForm() {
        txtDoctorUsername.setText("");
        txtDoctorPassword.setText("");
        txtDoctorFullname.setText("");
        comboDoctorSpecialty.setSelectedIndex(-1);
        txtDoctorConsultationFee.setText(""); // Baru
    }

    // --- Baru: Clear form update dokter ---
    public void clearUpdateDoctorForm() {
        txtSearchDoctorId.setText("");
        txtUpdateUsername.setText("");
        txtUpdateFullname.setText("");
        comboUpdateSpecialty.setSelectedIndex(-1);
        txtUpdateConsultationFee.setText("");
    }

    // --- Getter untuk mengisi combo box dokter ---
    public JComboBox<MedicalSpecialty> getComboDoctorSpecialty() { return comboDoctorSpecialty; }
}
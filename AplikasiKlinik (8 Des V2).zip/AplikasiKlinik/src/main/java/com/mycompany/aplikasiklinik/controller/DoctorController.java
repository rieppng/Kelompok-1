/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.AppointmentServiceDAO;
import com.mycompany.aplikasiklinik.model.dao.BillDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalRecordDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicationDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.PrescriptionItemDAO;
import com.mycompany.aplikasiklinik.model.dao.ServiceFeeDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO; // Tambahkan import UserDAO jika belum ada
import com.mycompany.aplikasiklinik.model.entity.AppointmentService;
import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecord;
import com.mycompany.aplikasiklinik.model.entity.Medication;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.DoctorPanel;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

public class DoctorController {

    private final DoctorPanel doctorPanel;
    private final AppointmentDAO appointmentDAO;
    private final MedicalRecordDAO medicalRecordDAO;
    private final BillDAO billDAO;
    private final PrescriptionItemDAO prescriptionItemDAO;
    private final AppointmentServiceDAO appointmentServiceDAO;
    private final PatientDAO patientDAO;
    private final MedicationDAO medicationDAO;
    private final ServiceFeeDAO serviceFeeDAO;
    
    private final UserDAO userDAO;
    private final int doctorId;

    private Appointment selectedAppointment;
    private final List<Appointment> waitingListCache;
    private final List<PrescriptionItem> tempPrescriptionList; 
    private final List<AppointmentService> tempServiceList;    

    private Timer refreshTimer;
    private static final int REFRESH_INTERVAL_MS = 5000;

    public DoctorController(DoctorPanel doctorPanel, UserDAO userDAO, int doctorId) {
        this.doctorPanel = doctorPanel;
        this.appointmentDAO = new AppointmentDAO();
        this.medicalRecordDAO = new MedicalRecordDAO();
        this.billDAO = new BillDAO();
        this.prescriptionItemDAO = new PrescriptionItemDAO();
        this.appointmentServiceDAO = new AppointmentServiceDAO();
        this.patientDAO = new PatientDAO();
        this.medicationDAO = new MedicationDAO();
        this.serviceFeeDAO = new ServiceFeeDAO();
        
        this.userDAO = userDAO;
        this.doctorId = doctorId;

        this.waitingListCache = new ArrayList<>();
        this.tempPrescriptionList = new ArrayList<>();
        this.tempServiceList = new ArrayList<>();

        loadTreatmentServiceList(); 
        loadWaitingList();          
        setupActionListeners();     
        startAutoRefresh();         
        updateBtnStartConsultState(); 
        
        // Listener window closing
        javax.swing.SwingUtilities.getWindowAncestor(doctorPanel).addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                userDAO.updateUserActiveStatus(doctorId, false);
            }
        });
    }

    private void setupActionListeners() {
        doctorPanel.getBtnStartConsult().addActionListener(e -> startConsultation());
        doctorPanel.getBtnSaveRecord().addActionListener(e -> saveMedicalRecord());
        doctorPanel.getBtnAddMedication().addActionListener(e -> showAddMedicationDialog());
        
        doctorPanel.getComboTreatmentService().addActionListener(e -> handleServiceSelection()); 

        doctorPanel.getBtnRemoveSelectedPrescription().addActionListener(e -> removeSelectedPrescriptionItem());
        doctorPanel.getTableWaitingList().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> {
            if (selectedAppointment == null) {
                loadWaitingList();
            }
        });
        refreshTimer.start();
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    private void loadWaitingList() {
        DefaultTableModel model = doctorPanel.getWaitingListModel();
        model.setRowCount(0);

        User currentDoctor = SessionManager.getInstance().getCurrentUser();
        if (currentDoctor == null) return;

        waitingListCache.clear();
        waitingListCache.addAll(appointmentDAO.getWaitingListByDoctor(currentDoctor.getId(), LocalDate.now()));
        for (Appointment app : waitingListCache) {
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            String patientName = (patient != null) ? patient.getName() : "Pasien Tidak Ditemukan (ID: " + app.getPatientId() + ")";
            model.addRow(new Object[]{
                app.getQueueNumber(),
                patientName,
                app.getStatus()
            });
        }
    }

    private void loadTreatmentServiceList() {
        List<ServiceFee> services = serviceFeeDAO.getAllServiceFees();
        DefaultComboBoxModel<ServiceFee> model = new DefaultComboBoxModel<>();
        if (services != null) {
            for (ServiceFee service : services) {
                model.addElement(service);
            }
        }
        doctorPanel.getComboTreatmentService().setModel(model);
        doctorPanel.getComboTreatmentService().setSelectedIndex(-1);
    }

    private void tableSelectionChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting() || selectedAppointment != null) {
            if (doctorPanel.getTableWaitingList().getSelectedRow() != -1 && selectedAppointment != null) {
                doctorPanel.getTableWaitingList().clearSelection();
                JOptionPane.showMessageDialog(doctorPanel, "Anda sedang memeriksa pasien. Simpan rekam medis terlebih dahulu.");
            }
            return;
        }

        int row = doctorPanel.getTableWaitingList().getSelectedRow();
        if (row >= 0 && row < waitingListCache.size()) {
            Appointment selected = waitingListCache.get(row);
            if (!"IN_CONSULTATION".equals(selected.getStatus())) {
                doctorPanel.getBtnStartConsult().setEnabled(true);
            } else {
                doctorPanel.getTableWaitingList().clearSelection();
                doctorPanel.getBtnStartConsult().setEnabled(false);
            }
        } else {
            doctorPanel.getBtnStartConsult().setEnabled(false);
        }
    }

    private void startConsultation() {
        int selectedRow = doctorPanel.getTableWaitingList().getSelectedRow();
        if (selectedRow == -1 || selectedAppointment != null) {
            JOptionPane.showMessageDialog(doctorPanel, "Pilih pasien yang belum diperiksa.");
            return;
        }

        Appointment appToConsult = waitingListCache.get(selectedRow);
        if ("IN_CONSULTATION".equals(appToConsult.getStatus())) {
            JOptionPane.showMessageDialog(doctorPanel, "Pasien ini sedang diperiksa.");
            return;
        }

        if (appointmentDAO.updateStatus(appToConsult.getId(), "IN_CONSULTATION")) {
            appToConsult.setStatus("IN_CONSULTATION");
            selectedAppointment = appToConsult;
            doctorPanel.getBtnStartConsult().setEnabled(false);
            doctorPanel.getTableWaitingList().clearSelection();
            
            // --- BARU: AMBIL DAN TAMPILKAN DATA PASIEN ---
            Patient patient = patientDAO.getPatientById(appToConsult.getPatientId());
            if (patient != null) {
                doctorPanel.setPatientInfo(
                    patient.getName(),
                    patient.getNik(),
                    patient.getGender(),
                    patient.getBirthDate().toString(),
                    patient.getPhoneNumber(),
                    patient.getAddress(),
                    String.valueOf(appToConsult.getWeight()), // Ambil dari appointment
                    String.valueOf(appToConsult.getHeight()), // Ambil dari appointment
                    appToConsult.getBloodPressure() // Ambil dari appointment
                );
                
                // Pindah ke tampilan Info Pasien
                doctorPanel.showPatientInfoView();
            }
            // ---------------------------------------------
            
            JOptionPane.showMessageDialog(doctorPanel, "Mulai pemeriksaan untuk Antrian No: " + appToConsult.getQueueNumber());
        } else {
            JOptionPane.showMessageDialog(doctorPanel, "Gagal memperbarui status pasien.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    


    private void saveMedicalRecord() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu.");
            return;
        }

        String symptoms = doctorPanel.getSymptoms().trim();
        String diagnosis = doctorPanel.getDiagnosis().trim();
        String treatment = doctorPanel.getTreatment().trim();

        // --- PERUBAHAN: Ambil biaya konsultasi dari OBJEK USER dokter yang login ---
        User currentDoctor = SessionManager.getInstance().getCurrentUser();
        if (currentDoctor == null || !"DOCTOR".equals(currentDoctor.getRole().name())) {
            JOptionPane.showMessageDialog(doctorPanel, "Sesi dokter tidak valid.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Ambil nilai biaya konsultasi dari dokter yang sedang login
        double consultationFeeValue = currentDoctor.getConsultationFee(); // Ambil dari objek User dokter
        System.out.println("DEBUG DoctorController: Biaya konsultasi dokter: " + consultationFeeValue); // Tambahkan logging

        if (symptoms.isEmpty() || diagnosis.isEmpty() || treatment.isEmpty()) {
            JOptionPane.showMessageDialog(doctorPanel, "Semua field gejala, diagnosa, dan tindakan harus diisi.");
            return;
        }

        try {
            // Gunakan consultationFeeValue (dari User) saat membuat MedicalRecord
            MedicalRecord mr = new MedicalRecord(0, selectedAppointment.getId(), symptoms, diagnosis, treatment, consultationFeeValue); // Gunakan nilai dari User
            
            int medicalRecordId = medicalRecordDAO.addMedicalRecord(mr);

            if (medicalRecordId > 0) {
                double totalMedCost = 0, totalServCost = 0;

                for (PrescriptionItem item : tempPrescriptionList) {
                    item.setMedicalRecordId(medicalRecordId);
                    item.setStatus("PENDING");
                    prescriptionItemDAO.addPrescriptionItem(item);
                    totalMedCost += item.getSubTotal();
                }

                // --- PERUBAHAN: Perbarui logika untuk tindakan tambahan ---
                // Kita tetap menyimpan tindakan tambahan (jika ada) ke database menggunakan AppointmentServiceDAO
                // Namun, biaya konsultasi utama TIDAK disimpan di sini, melainkan di Bill
                for (AppointmentService service : tempServiceList) {
                    service.setAppointmentId(selectedAppointment.getId());
                    appointmentServiceDAO.addAppointmentService(service); // Simpan ke database
                    totalServCost += service.getSubTotal(); // Akumulasikan biaya tindakan tambahan
                }

                // --- PERUBAHAN: Buat Bill dengan biaya konsultasi dari User ---
                // Gunakan consultationFeeValue dari objek User dokter
                Bill newBill = new Bill(0, selectedAppointment.getId(), totalMedCost, totalServCost, consultationFeeValue, false); // Gunakan biaya dari User
                System.out.println("DEBUG DoctorController: Membuat objek Bill. Sebelum DAO, nilai Bill.getConsultationFee(): " + newBill.getConsultationFee()); // Tambahkan logging
                System.out.println("DEBUG DoctorController: Bill.getTotalAmount(): " + newBill.getTotalAmount()); // Tambahkan logging

                if (billDAO.createBill(newBill)) {
                    String nextStatus = "IN_PHARMACY";

                    // Logika status berdasarkan item resep dan tindakan
                    if (tempPrescriptionList.isEmpty() && !tempServiceList.isEmpty()) {
                        // Hanya tindakan, langsung ke kasir
                        nextStatus = "IN_CASHIER";
                    } else if (tempPrescriptionList.isEmpty() && tempServiceList.isEmpty()) {
                        // Tidak ada obat dan tidak ada tindakan, langsung ke kasir
                        nextStatus = "IN_CASHIER";
                    }

                    appointmentDAO.updateStatus(selectedAppointment.getId(), nextStatus);
                    selectedAppointment = null;

                    String message = "Rekam medis dan tagihan disimpan.";
                    if ("IN_CASHIER".equals(nextStatus)) {
                        message += " Status pasien: IN_CASHIER (langsung ke kasir).";
                    } else {
                        message += " Status pasien: IN_PHARMACY.";
                    }

                    JOptionPane.showMessageDialog(doctorPanel, message);
                    doctorPanel.clearForm();

                    tempPrescriptionList.clear();
                    tempServiceList.clear();
                    doctorPanel.getComboTreatmentService().setSelectedIndex(-1); // Reset combo tindakan

                    doctorPanel.showQueueView();
                    loadWaitingList();
                    updateBtnStartConsultState();
                } else {
                    JOptionPane.showMessageDialog(doctorPanel, "Gagal menyimpan Rekam Medis atau Tagihan.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(doctorPanel, "Gagal menyimpan Rekam Medis.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(doctorPanel, "Error saat menyimpan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }











    private void showAddMedicationDialog() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu.");
            return;
        }

        List<Medication> meds = medicationDAO.getAllMedications();
        JComboBox<Medication> comboMeds = new JComboBox<>(meds.toArray(new Medication[0]));
        JTextField txtQty = new JTextField("1");
        JTextField txtInstructions = new JTextField();
        final JComponent[] inputs = new JComponent[]{
            new JLabel("Pilih Obat:"), comboMeds,
            new JLabel("Jumlah:"), txtQty,
            new JLabel("Aturan Pakai:"), txtInstructions
        };
        int result = JOptionPane.showConfirmDialog(null, inputs, "Tambah Obat", JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                Medication med = (Medication) comboMeds.getSelectedItem();
                int qty = Integer.parseInt(txtQty.getText());
                String instructions = txtInstructions.getText();

                if (qty <= 0 || qty > med.getStockQuantity()) {
                    JOptionPane.showMessageDialog(doctorPanel, "Jumlah tidak valid atau stok tidak mencukupi.");
                    return;
                }

                PrescriptionItem item = new PrescriptionItem();
                item.setMedicationId(med.getId());
                item.setQuantity(qty);
                item.setInstructions(instructions);
                item.setPriceAtTime(med.getPrice());
                item.setStatus("PENDING"); 

                tempPrescriptionList.add(item);
                doctorPanel.getPrescriptionModel().addRow(new Object[]{"Obat", med.getName(), qty, med.getPrice(), item.getSubTotal(), instructions});
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(doctorPanel, "Jumlah harus angka.");
            }
        }
    }

    private void handleServiceSelection() {
        ServiceFee selectedService = (ServiceFee) doctorPanel.getComboTreatmentService().getSelectedItem();
        
        if (selectedService == null) {
            return; 
        }

        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu.");
            doctorPanel.getComboTreatmentService().setSelectedIndex(-1);
            return;
        }

        int qty = 1;

        AppointmentService service = new AppointmentService(selectedAppointment.getId(), selectedService.getId(), qty, selectedService.getPrice());
        tempServiceList.add(service);
        
        doctorPanel.getPrescriptionModel().addRow(new Object[]{"Tind. Layanan", selectedService.getName(), qty, selectedService.getPrice(), service.getSubTotal(), ""}); 
        
        javax.swing.SwingUtilities.invokeLater(() -> {
            doctorPanel.getComboTreatmentService().setSelectedIndex(-1);
        });
    }

    private void removeSelectedPrescriptionItem() {
        int selectedRow = doctorPanel.getTablePrescription().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(doctorPanel, "Pilih item yang akan dihapus dari tabel.");
            return;
        }

        DefaultTableModel model = doctorPanel.getPrescriptionModel();
        String jenisItem = (String) model.getValueAt(selectedRow, 0);

        if ("Obat".equals(jenisItem)) {
            tempPrescriptionList.remove(selectedRow);
        } else if ("Tind. Layanan".equals(jenisItem)) {
             String namaItem = (String) model.getValueAt(selectedRow, 1);
             int qtyItem = (Integer) model.getValueAt(selectedRow, 2);
             double hargaItem = (Double) model.getValueAt(selectedRow, 3);
             
             tempServiceList.removeIf(s -> s.getQuantity() == qtyItem && s.getPriceAtTime() == hargaItem && serviceFeeDAO.getServiceFeeById(s.getServiceFeeId()).getName().equals(namaItem));
        }

        model.removeRow(selectedRow);
    }

    private void updateBtnStartConsultState() {
        boolean hasSelection = doctorPanel.getTableWaitingList().getSelectedRow() != -1;
        doctorPanel.getBtnStartConsult().setEnabled(selectedAppointment == null && hasSelection);
    }

    public Appointment getSelectedAppointment() {
        return selectedAppointment;
    }
}
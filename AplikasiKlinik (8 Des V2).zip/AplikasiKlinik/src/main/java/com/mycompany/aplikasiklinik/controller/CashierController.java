/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.BillDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.view.CashierPanel;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

// Import iTextPDF
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;

public class CashierController {

    private final CashierPanel cashierPanel;
    private final BillDAO billDAO;
    private final PatientDAO patientDAO;
    private final UserDAO userDAO;
    private final AppointmentDAO appointmentDAO;

    private Bill selectedBill; // Menyimpan tagihan yang dipilih dari tabel

    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 8000; // Refresh setiap 8 detik

    public CashierController(CashierPanel cashierPanel) {
        this.cashierPanel = cashierPanel;
        this.billDAO = new BillDAO();
        this.patientDAO = new PatientDAO(); // Inisialisasi
        this.userDAO = new UserDAO();       // Inisialisasi
        this.appointmentDAO = new AppointmentDAO(); // Inisialisasi

        loadAllBills(); // Muat data awal

        // Hubungkan listener ke komponen
        this.cashierPanel.getBtnRefresh().addActionListener(e -> loadAllBills());
        this.cashierPanel.getBtnPay().addActionListener(e -> processPayment());
        this.cashierPanel.getBtnPrintReceipt().addActionListener(e -> printReceiptAsPdf());
        this.cashierPanel.getTableAllBills().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);

        startAutoRefresh();
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> loadAllBills()); // Refresh tabel utama
        refreshTimer.start();
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    // --- METHOD DIUPDATE: Muat SEMUA tagihan ---
    public void loadAllBills() {
        DefaultTableModel model = cashierPanel.getAllBillsModel();
        model.setRowCount(0); // Kosongkan tabel sebelum diisi

        // Ambil dari BillDAO
        List<Bill> allBills = billDAO.getAllBills(); // Method baru di BillDAO diperlukan

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (Bill bill : allBills) {
            // Ambil nama pasien dan dokter dari Appointment/Patient/User DAO
            Appointment app = appointmentDAO.getAppointmentById(bill.getAppointmentId());
            String patientName = "Unknown";
            String doctorName = "Unknown";

            if (app != null) {
                Patient patient = patientDAO.getPatientById(app.getPatientId());
                User doctor = userDAO.getUserById(app.getDoctorId());
                patientName = (patient != null) ? patient.getName() : "Pasien Error (ID: " + app.getPatientId() + ")";
                doctorName = (doctor != null) ? doctor.getFullName() : "Dokter Error (ID: " + app.getDoctorId() + ")";
            }

            String statusStr = bill.isPaid() ? "LUNAS" : "BELUM DIBAYAR";
            String paymentDateStr = bill.isPaid() && bill.getPaymentDate() != null ? bill.getPaymentDate().format(formatter) : "-";

            model.addRow(new Object[]{
                bill.getId(),
                patientName,
                doctorName,
                bill.getTotalAmount(),
                statusStr // Kolom status
                // paymentDateStr // Bisa ditambahkan jika diperlukan
            });
        }
    }

    private void tableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && cashierPanel.getTableAllBills().getSelectedRow() != -1) {
            int row = cashierPanel.getTableAllBills().getSelectedRow();
            int billId = (int) cashierPanel.getAllBillsModel().getValueAt(row, 0); // Ambil ID Bill dari kolom pertama

            // Ambil Bill dari DB berdasarkan ID
            selectedBill = billDAO.getBillById(billId); // Method di BillDAO harus mengembalikan Bill lengkap

            if (selectedBill != null) {
                // Ambil detail pasien dan dokter untuk tampilan detail
                Appointment app = appointmentDAO.getAppointmentById(selectedBill.getAppointmentId());
                Patient patient = null;
                User doctor = null;

                if (app != null) {
                    patient = patientDAO.getPatientById(app.getPatientId());
                    doctor = userDAO.getUserById(app.getDoctorId());
                }

                // Bangun string detail
                String details = buildBillDetailsString(selectedBill, patient, doctor);
                cashierPanel.getTxtBillDetails().setText(details);
                cashierPanel.setTotalLabel(selectedBill.getTotalAmount());

                // Update status tombol berdasarkan status bill
                cashierPanel.updateActionButtons(selectedBill.isPaid()); // true jika lunas, false jika belum
            }
        } else if (!e.getValueIsAdjusting() && cashierPanel.getTableAllBills().getSelectedRow() == -1) {
            // Jika tidak ada baris yang dipilih
            selectedBill = null;
            cashierPanel.clearBillDetails(); // Reset detail dan tombol
        }
    }

    private void processPayment() {
        // Validasi: Apakah ada tagihan dipilih dan apakah statusnya belum dibayar
        if (selectedBill == null) {
            JOptionPane.showMessageDialog(cashierPanel, "Pilih tagihan yang akan dibayar dari tabel!");
            return;
        }

        if (selectedBill.isPaid()) {
            JOptionPane.showMessageDialog(cashierPanel, "Tagihan ini sudah lunas.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(cashierPanel,
                "Proses pembayaran total Rp " + selectedBill.getTotalAmount() + "?",
                "Konfirmasi Pembayaran", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (billDAO.markAsPaid(selectedBill.getId())) { // Update status di DB
                JOptionPane.showMessageDialog(cashierPanel, "Pembayaran berhasil!");
                selectedBill = null; // Reset pilihan
                cashierPanel.clearBillDetails(); // Bersihkan detail dan nonaktifkan tombol
                loadAllBills(); // Refresh tabel agar status berubah
            } else {
                JOptionPane.showMessageDialog(cashierPanel, "Gagal memproses pembayaran.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // --- METHOD DIUPDATE: Cetak Kwitansi ---
    private void printReceiptAsPdf() {
        // Validasi: Apakah ada tagihan dipilih dan apakah statusnya sudah dibayar
        if (selectedBill == null) {
            JOptionPane.showMessageDialog(cashierPanel, "Pilih tagihan lunas dari tabel untuk dicetak.");
            return;
        }

        if (!selectedBill.isPaid()) {
            JOptionPane.showMessageDialog(cashierPanel, "Tagihan belum dibayar. Tidak bisa dicetak.");
            return;
        }

        // Ambil data lengkap untuk PDF
        Appointment app = appointmentDAO.getAppointmentById(selectedBill.getAppointmentId());
        Patient patient = null;
        User doctor = null;

        if (app != null) {
            patient = patientDAO.getPatientById(app.getPatientId());
            doctor = userDAO.getUserById(app.getDoctorId());
        }

        String receiptDetails = buildBillDetailsString(selectedBill, patient, doctor);

        // --- PERUBAHAN: Bangun nama file dari data pasien dan tanggal pembayaran ---
        String patientName = (patient != null) ? patient.getName() : "Pasien_Tidak_Ditemukan";
        String patientNik = (patient != null) ? patient.getNik() : "NIK_Tidak_Ditemukan";
        String paymentDateStr = selectedBill.getPaymentDate() != null ? selectedBill.getPaymentDate().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) : "Tanggal_Tidak_Ditemukan"; // Format tanggal untuk nama file

        // Ganti karakter yang tidak valid dalam nama file
        String safePatientName = patientName.replaceAll("[^a-zA-Z0-9.-]", "_");
        String safePatientNik = patientNik.replaceAll("[^a-zA-Z0-9.-]", "_");

        String fileName = safePatientName + "_" + safePatientNik + "_" + paymentDateStr + ".pdf";

        // JFileChooser untuk menyimpan file
        javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();
        fileChooser.setDialogTitle("Simpan Kwitansi sebagai PDF");
        // Gunakan nama file yang dibangun
        fileChooser.setSelectedFile(new java.io.File(fileName));
        int userSelection = fileChooser.showSaveDialog(cashierPanel);

        if (userSelection == javax.swing.JFileChooser.APPROVE_OPTION) {
            java.io.File fileToSave = fileChooser.getSelectedFile();
            String filePath = fileToSave.getAbsolutePath();

            if (!filePath.toLowerCase().endsWith(".pdf")) {
                filePath += ".pdf";
            }

            try (PdfWriter writer = new PdfWriter(filePath);
                 PdfDocument pdfDoc = new PdfDocument(writer);
                 Document document = new Document(pdfDoc)) {

                document.add(new Paragraph("KWITANSI PEMBAYARAN")
                        .setTextAlignment(TextAlignment.CENTER)
                        .setFontSize(18)
                        .setBold());
                document.add(new Paragraph("\n")); // Baris kosong
                document.add(new Paragraph(receiptDetails));

                JOptionPane.showMessageDialog(cashierPanel, "Kwitansi berhasil disimpan sebagai PDF di:\n" + filePath, "Berhasil", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(cashierPanel, "Gagal menyimpan file PDF: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
        // Jika user cancel filechooser, tidak ada yang dilakukan
    }

    // --- METHOD BARU: Bangun string detail tagihan (bisa digunakan untuk UI dan PDF) ---
    private String buildBillDetailsString(Bill bill, Patient patient, User doctor) {
        StringBuilder sb = new StringBuilder();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        sb.append("=== KWITANSI PEMBAYARAN ===\n\n");
        sb.append("ID Tagihan: ").append(bill.getId()).append("\n");
        // sb.append("Tanggal Pembuatan Tagihan: ").append(bill.getPaymentDate() != null ? bill.getPaymentDate().format(formatter) : "Belum Dibayar").append("\n\n"); // Tanggal bayar lebih relevan

        if (bill.isPaid() && bill.getPaymentDate() != null) {
            sb.append("Tanggal Pembayaran: ").append(bill.getPaymentDate().format(formatter)).append("\n\n");
        }

        if (patient != null) {
            sb.append("--- DETAIL PASIEN ---\n");
            sb.append("Nama: ").append(patient.getName()).append("\n");
            sb.append("NIK: ").append(patient.getNik()).append("\n");
            sb.append("Alamat: ").append(patient.getAddress()).append("\n");
            sb.append("No. HP: ").append(patient.getPhoneNumber()).append("\n\n");
        }

        if (doctor != null) {
            sb.append("--- DETAIL DOKTER ---\n");
            sb.append("Nama Dokter: ").append(doctor.getFullName()).append("\n\n");
        }

        sb.append("--- RINCIAN BIAYA ---\n");
        sb.append("Biaya Obat: Rp ").append(String.format("%.2f", bill.getTotalMedicationCost())).append("\n");
        sb.append("Biaya Tindakan: Rp ").append(String.format("%.2f", bill.getTotalServiceCost())).append("\n");
        sb.append("Biaya Konsultasi: Rp ").append(String.format("%.2f", bill.getConsultationFee())).append("\n");
        sb.append("-------------------------\n");
        sb.append("TOTAL: Rp ").append(String.format("%.2f", bill.getTotalAmount())).append("\n\n");

        sb.append("Status Pembayaran: ");
        if (bill.isPaid()) {
            sb.append("LUNAS");
        } else {
            sb.append("BELUM DIBAYAR");
        }

        return sb.toString();
    }
}
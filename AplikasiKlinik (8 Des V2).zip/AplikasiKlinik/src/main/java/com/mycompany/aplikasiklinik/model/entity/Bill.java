package com.mycompany.aplikasiklinik.model.entity;

import java.time.LocalDateTime;

/**
 *
 * @author LENOVO
 */
public class Bill {
    private int id;
    private int appointmentId;  // Kunci utama untuk melacak tagihan siapa

    private double totalMedicationCost; // Total harga obat
    private double totalServiceCost;    // Total harga tindakan (baru)
    private double consultationFee;     // Biaya dokter
    private double totalAmount;         // Grand Total (Obat + Tindakan + Dokter) - dihitung otomatis

    private boolean isPaid;             // Status pembayaran
    private LocalDateTime paymentDate;  // Waktu bayar

    public Bill() {}

    // Constructor lama (untuk kompatibilitas, tetapi totalServiceCost di-set 0)
    public Bill(int id, int appointmentId, double totalMedicationCost, double consultationFee, boolean isPaid) {
        this.id = id;
        this.appointmentId = appointmentId;
        this.totalMedicationCost = totalMedicationCost;
        this.totalServiceCost = 0; // Default 0
        this.consultationFee = consultationFee;
        this.isPaid = isPaid;
        this.recalculateTotal(); // Hitung totalAmount otomatis
    }

    // Constructor baru (lebih representatif)
    public Bill(int id, int appointmentId, double totalMedicationCost, double totalServiceCost, double consultationFee, boolean isPaid) {
        this.id = id;
        this.appointmentId = appointmentId;
        this.totalMedicationCost = totalMedicationCost;
        this.totalServiceCost = totalServiceCost;
        this.consultationFee = consultationFee;
        this.isPaid = isPaid;
        this.recalculateTotal(); // Hitung totalAmount otomatis
    }

    // --- Getters ---
    public int getId() { return id; }
    public int getAppointmentId() { return appointmentId; }
    public double getTotalMedicationCost() { return totalMedicationCost; }
    public double getTotalServiceCost() { return totalServiceCost; }
    public double getConsultationFee() { return consultationFee; }
    // public double getTotalAmount() { return totalAmount; }
    public boolean isPaid() { return isPaid; }
    public LocalDateTime getPaymentDate() { return paymentDate; }

    // --- Setters (dengan perhitungan otomatis totalAmount) ---
    public void setId(int id) { this.id = id; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    public void setTotalMedicationCost(double totalMedicationCost) {
        this.totalMedicationCost = totalMedicationCost;
        this.recalculateTotal(); // Perbarui totalAmount
    }

    public void setTotalServiceCost(double totalServiceCost) { // Setter baru
        this.totalServiceCost = totalServiceCost;
        this.recalculateTotal(); // Perbarui totalAmount
    }

    public void setConsultationFee(double consultationFee) {
        this.consultationFee = consultationFee;
        this.recalculateTotal(); // Perbarui totalAmount
    }

    // Tidak ada setter untuk totalAmount karena dihitung otomatis
    // public void setTotalAmount(double totalAmount) { ... } // HAPUS BARIS INI

    public void setPaid(boolean paid) { isPaid = paid; }

    public void setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    // Tambahkan getter ini
    public double getTotalAmount() {
        // Jika totalAmount tidak disimpan, hitung otomatis
        // return this.totalMedicationCost + this.totalServiceCost + this.consultationFee;
        // Atau jika disimpan, kembalikan nilainya
        return this.totalAmount;
    }

    // --- Method helper untuk update total otomatis ---
    private void recalculateTotal() {
        this.totalAmount = this.totalMedicationCost + this.totalServiceCost + this.consultationFee;
    }

    @Override
    public String toString() {
        return "Bill{" +
                "id=" + id +
                ", appointmentId=" + appointmentId +
                ", totalMedicationCost=" + totalMedicationCost +
                ", totalServiceCost=" + totalServiceCost +
                ", consultationFee=" + consultationFee +
                ", totalAmount=" + totalAmount +
                ", isPaid=" + isPaid +
                ", paymentDate=" + paymentDate +
                '}';
    }
}
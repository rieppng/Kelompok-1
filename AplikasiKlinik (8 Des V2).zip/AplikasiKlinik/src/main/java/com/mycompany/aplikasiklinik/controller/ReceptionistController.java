/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalSpecialtyDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty;
import com.mycompany.aplikasiklinik.view.ReceptionistPanel;

import java.awt.Component;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date; // Import Date
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer; // Perbaikan typo dari DefaultListCellRenderer
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class ReceptionistController {
    private final ReceptionistPanel receptionistPanel;
    private final UserDAO userDAO;
    private final PatientDAO patientDAO;
    private final AppointmentDAO appointmentDAO;
    private final MedicalSpecialtyDAO specialtyDAO; 

    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 6000;

    public ReceptionistController(ReceptionistPanel receptionistPanel) {
        this.receptionistPanel = receptionistPanel;
        this.userDAO = new UserDAO();
        this.patientDAO = new PatientDAO();
        this.appointmentDAO = new AppointmentDAO();
        this.specialtyDAO = new MedicalSpecialtyDAO();

        // Custom Renderer
        receptionistPanel.getComboActiveDoctor().setRenderer(new DefaultListCellRenderer() { // Gunakan DefaultListCellRenderer
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof User) {
                    User doctor = (User) value;
                    setText(doctor.getFullName()); 
                }
                return this;
            }
        });

        loadSpecialtiesList(); 
        loadQueueList();

        receptionistPanel.getBtnAddToQueue().addActionListener(e -> handleAddToQueue());
        receptionistPanel.getComboSpecialty().addActionListener(e -> loadActiveDoctorsForSelectedSpecialty());
        receptionistPanel.getBtnRefreshDoctorList().addActionListener(e -> loadActiveDoctorsForSelectedSpecialty());
        
        // --- Listener Tombol Cari NIK ---
        receptionistPanel.getBtnSearchNik().addActionListener(e -> handleSearchByNik());
        
        startAutoRefresh();
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> loadQueueList());
        refreshTimer.start();
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    private void loadSpecialtiesList() {
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        for (MedicalSpecialty specialty : specialties) {
            model.addElement(specialty);
        }
        receptionistPanel.getComboSpecialty().setModel(model);
        receptionistPanel.getComboActiveDoctor().setModel(new DefaultComboBoxModel<>());
    }

    private void loadActiveDoctorsForSelectedSpecialty() {
        MedicalSpecialty selectedSpecialty = (MedicalSpecialty) receptionistPanel.getComboSpecialty().getSelectedItem();
        if (selectedSpecialty == null) {
            receptionistPanel.getComboActiveDoctor().setModel(new DefaultComboBoxModel<>());
            return;
        }

        List<User> activeDoctorsInSpecialty = userDAO.getActiveDoctorsBySpecialtyId(selectedSpecialty.getId());

        DefaultComboBoxModel<User> model = new DefaultComboBoxModel<>();
        for (User doctor : activeDoctorsInSpecialty) {
            model.addElement(doctor);
        }

        receptionistPanel.getComboActiveDoctor().setModel(model);
    }

    private void loadQueueList() {
        List<Appointment> waitingList = appointmentDAO.getAppointmentsByDate(LocalDate.now());

        receptionistPanel.getQueueModel().setRowCount(0);

        for (Appointment app : waitingList) {
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            User doctor = userDAO.getUserById(app.getDoctorId());

            String patientName = (patient != null) ? patient.getName() : "Pasien Error";
            String doctorName = (doctor != null) ? doctor.getFullName() : "Dokter Error"; 

            receptionistPanel.getQueueModel().addRow(new Object[]{
                app.getQueueNumber(),
                patientName,
                doctorName,
                app.getStatus()
            });
        }
    }
    
    // --- METHOD BARU: Logika Pencarian NIK ---
    private void handleSearchByNik() {
        String nik = receptionistPanel.getNik().trim();
        if (nik.isEmpty()) {
            JOptionPane.showMessageDialog(receptionistPanel, "Masukkan NIK terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Patient existingPatient = patientDAO.getPatientByNik(nik);
        
        if (existingPatient != null) {
            // Data ditemukan, isi form otomatis
            receptionistPanel.getTxtName().setText(existingPatient.getName());
            receptionistPanel.getTxtAddress().setText(existingPatient.getAddress());
            receptionistPanel.getTxtPhone().setText(existingPatient.getPhoneNumber());
            receptionistPanel.setGender(existingPatient.getGender());
            receptionistPanel.getDateChooserDob().setDate(java.sql.Date.valueOf(existingPatient.getBirthDate()));
            
            // Simpan ID pasien lama di komponen hidden untuk referensi nanti
            receptionistPanel.setExistingPatientId(existingPatient.getId());
            
            JOptionPane.showMessageDialog(receptionistPanel, "Data Pasien Lama Ditemukan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Data tidak ditemukan
            receptionistPanel.setExistingPatientId(0); // Reset ID
            // Opsional: Clear form selain NIK
            // receptionistPanel.getTxtName().setText(""); 
            JOptionPane.showMessageDialog(receptionistPanel, "Data Pasien tidak ditemukan. Silakan isi form manual.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void handleAddToQueue() {
        // Ambil ID dokter dari combo box aktif (yang diisi oleh loadActiveDoctorsForSelectedSpecialty)
        String doctorIdStr = receptionistPanel.getSelectedDoctorId();
        if (doctorIdStr == null) {
             JOptionPane.showMessageDialog(receptionistPanel, "Pilih dokter aktif dari daftar!", "Peringatan", JOptionPane.WARNING_MESSAGE);
             return;
        }

        // Ambil data pasien dari panel
        String name = receptionistPanel.getPatientName().trim();
        String nik = receptionistPanel.getNik().trim();
        LocalDate birthDate = receptionistPanel.getDob();
        String phone = receptionistPanel.getPhone().trim();
        String address = receptionistPanel.getAddress().trim();
        String weightStr = receptionistPanel.getWeight().trim();
        String heightStr = receptionistPanel.getPatientHeight().trim();
        String bloodPressure = receptionistPanel.getBloodPressure().trim(); // Ambil tekanan darah

        int doctorId = Integer.parseInt(doctorIdStr); // Konversi ID dokter

        if (name.isEmpty() || nik.isEmpty() || phone.isEmpty() || address.isEmpty() ||
            weightStr.isEmpty() || heightStr.isEmpty() || birthDate == null) {

            JOptionPane.showMessageDialog(receptionistPanel, "Semua kolom wajib diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double weight = Double.parseDouble(weightStr);
            double height = Double.parseDouble(heightStr);
            // Tekanan darah bisa kosong, jadi tidak perlu di-parse

            // --- HAPUS BAGIAN INI: Ambil ID Biaya Konsultasi dari Dokter ---
            /*
            User selectedDoctor = (User) receptionistPanel.getComboActiveDoctor().getSelectedItem();
            if (selectedDoctor == null) {
                 JOptionPane.showMessageDialog(receptionistPanel, "Error internal: Dokter tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                 return;
            }

            int consultationFeeId = selectedDoctor.getConsultationServiceFeeId(); // Gunakan getter dari User.java

            if (consultationFeeId <= 0) {
                JOptionPane.showMessageDialog(receptionistPanel, "Biaya konsultasi untuk dokter ini tidak ditemukan. Harap hubungi Admin.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            */

            Patient newPatient = new Patient(0, name, nik, birthDate, "L", address, phone); // Tambahkan gender

            int newPatientId = patientDAO.addPatient(newPatient); // Ambil ID pasien baru

            if (newPatientId > 0) { // Periksa apakah pasien disimpan
                Appointment newAppt = new Appointment();
                newAppt.setPatientId(newPatientId); // Gunakan ID pasien baru
                newAppt.setDoctorId(doctorId);      // Gunakan ID dokter yang dipilih
                newAppt.setDate(LocalDate.now());
                newAppt.setWeight(weight);
                newAppt.setHeight(height);
                newAppt.setBloodPressure(bloodPressure); // Simpan tekanan darah
                newAppt.setStatus("WAITING");

                // --- HAPUS BAGIAN INI: Set ID Biaya Konsultasi ke Appointment ---
                // newAppt.setConsultationServiceFeeId(consultationFeeId); // Hapus baris ini

                int queueNumber = appointmentDAO.getNextQueueNumber(doctorId, LocalDate.now()); // Gunakan ID dokter
                newAppt.setQueueNumber(queueNumber);

                if (appointmentDAO.addAppointment(newAppt)) { // Simpan janji temu
                    JOptionPane.showMessageDialog(receptionistPanel,
                            "Pasien " + name + " terdaftar! No. Antrian: " + queueNumber);

                    receptionistPanel.clearForm(); // Bersihkan form setelah sukses
                    loadQueueList(); // Refresh tabel antrian
                } else {
                    JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan antrian ke database.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(receptionistPanel, "Gagal menyimpan data pasien ke database.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(receptionistPanel, "Berat dan Tinggi harus berupa angka!", "Error Input", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) { // Catch exception umum lainnya
            JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan pasien/antrian: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
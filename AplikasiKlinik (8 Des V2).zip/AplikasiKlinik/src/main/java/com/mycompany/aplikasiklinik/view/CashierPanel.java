package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import com.mycompany.aplikasiklinik.model.entity.Bill;

public class CashierPanel extends JPanel {

    // --- Bagian Kiri: Tabel Semua Tagihan (Lunas & Belum) ---
    private final JTable tableAllBills = new JTable();
    private final DefaultTableModel allBillsModel;
    private final JButton btnRefresh = new JButton("Refresh Data");

    // --- Bagian Kanan: Detail & Aksi ---
    private final JTextArea txtBillDetails = new JTextArea();
    private final JLabel lblTotalAmount = new JLabel("Total: Rp 0", SwingConstants.CENTER);
    private final JButton btnPay = new JButton("Proses Pembayaran");
    private final JButton btnPrintReceipt = new JButton("Cetak Kwitansi");

    public CashierPanel() {
        setLayout(new GridLayout(1, 2)); // Split kiri kanan

        // --- PANEL KIRI: Tabel Semua Tagihan ---
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBorder(BorderFactory.createTitledBorder("Daftar Tagihan"));

        allBillsModel = new DefaultTableModel(new Object[]{"ID Tagihan", "Pasien", "Dokter", "Total Biaya", "Status"}, 0);
        tableAllBills.setModel(allBillsModel);

        leftPanel.add(new JScrollPane(tableAllBills), BorderLayout.CENTER);
        leftPanel.add(btnRefresh, BorderLayout.SOUTH); // Tombol refresh di bawah tabel

        // --- PANEL KANAN: Detail & Aksi Pembayaran ---
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Detail Tagihan & Pembayaran"));

        txtBillDetails.setEditable(false); // Tidak bisa diedit
        lblTotalAmount.setFont(new Font("Arial", Font.BOLD, 24)); // Font besar untuk total

        // Panel untuk tombol aksi
        JPanel actionPanel = new JPanel(new GridLayout(2, 1, 5, 5)); // 2 baris, 1 kolom, dengan jarak
        actionPanel.add(btnPay);
        actionPanel.add(btnPrintReceipt);

        rightPanel.add(new JScrollPane(txtBillDetails), BorderLayout.CENTER); // Detail di tengah
        rightPanel.add(lblTotalAmount, BorderLayout.NORTH); // Total di atas
        rightPanel.add(actionPanel, BorderLayout.SOUTH); // Tombol di bawah

        add(leftPanel);
        add(rightPanel);
    }

    // --- Getter untuk komponen Tabel ---
    public JTable getTableAllBills() { return tableAllBills; }
    public DefaultTableModel getAllBillsModel() { return allBillsModel; }
    public JButton getBtnRefresh() { return btnRefresh; }

    // --- Getter untuk komponen Detail & Aksi ---
    public JTextArea getTxtBillDetails() { return txtBillDetails; }
    public void setTotalLabel(double amount) { lblTotalAmount.setText("Total: Rp " + amount); }

    public JButton getBtnPay() { return btnPay; }
    public JButton getBtnPrintReceipt() { return btnPrintReceipt; }

    // --- Method untuk mengisi tabel tagihan (akan dipanggil oleh controller) ---
    public void populateAllBillsTable(List<Bill> bills) { // Terima list bill dari controller
        DefaultTableModel model = getAllBillsModel();
        model.setRowCount(0); // Kosongkan tabel sebelum diisi

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (Bill bill : bills) {
            // Ambil nama pasien dan dokter dari Appointment/Patient/User DAO (implisit di controller)
            // Untuk sementara, kita gunakan ID atau placeholder
            String patientName = "Pasien (ID: " + bill.getAppointmentId() + ")"; // Perlu di-update untuk nama asli
            String doctorName = "Dokter (ID: " + bill.getAppointmentId() + ")"; // Perlu di-update untuk nama asli
            String statusStr = bill.isPaid() ? "LUNAS" : "BELUM DIBAYAR";
            String paymentDateStr = bill.isPaid() && bill.getPaymentDate() != null ? bill.getPaymentDate().format(formatter) : "-";

            model.addRow(new Object[]{
                bill.getId(),
                patientName,
                doctorName,
                bill.getTotalAmount(), // Pastikan Bill memiliki getter getTotalAmount()
                statusStr // Kolom status
                // paymentDateStr // Bisa ditambahkan kolom tanggal bayar jika diperlukan
            });
        }
    }

    // --- Method untuk mengatur enable/disable tombol berdasarkan status tagihan yang dipilih ---
    public void updateActionButtons(boolean isPaid) {
        btnPay.setEnabled(!isPaid); // Tombol bayar aktif jika belum dibayar
        btnPrintReceipt.setEnabled(isPaid); // Tombol cetak aktif jika sudah dibayar
    }

    // --- Method untuk membersihkan detail saat tabel tidak dipilih ---
    public void clearBillDetails() {
        txtBillDetails.setText("");
        lblTotalAmount.setText("Total: Rp 0");
        updateActionButtons(false); // Reset tombol ke status default (bayar aktif, cetak non-aktif)
    }
}
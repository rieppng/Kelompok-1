// File: com/mycompany/aplikasiklinik/model/dao/BillDAO.java
package com.mycompany.aplikasiklinik.model.dao;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;

/**
 *
 * @author LENOVO
 */
public class BillDAO {

    public boolean markAsPaid(int billId) {
        String sql = "UPDATE bills SET is_paid = true, payment_date = NOW() WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, billId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method untuk mengambil bill berdasarkan appointment_id (misalnya untuk CashierController)
    public Bill getBillByAppointmentId(int appointmentId) {
        String sql = "SELECT * FROM bills WHERE appointment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, appointmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // Jangan gunakan rs.getDouble("total_amount") jika total dihitung otomatis di sini
                // bill.setTotalAmount(rs.getDouble("total_amount")); // Hapus baris ini
                bill.setPaid(rs.getBoolean("is_paid"));
                if (rs.getTimestamp("payment_date") != null) {
                    bill.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                }
                return bill;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method untuk CashierController: ambil semua bill yang belum dibayar
    public List<Bill> getUnpaidBills() {
        List<Bill> unpaidBills = new ArrayList<>();
        String sql = "SELECT id, appointment_id, total_medication_cost, total_service_cost, consultation_fee, (total_medication_cost + total_service_cost + consultation_fee) AS calculated_total FROM bills WHERE is_paid = 0";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement(); // Gunakan Statement karena query tidak memiliki parameter
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // Gunakan nilai yang dihitung oleh DB sebagai total
                // bill.setTotalAmount(rs.getDouble("calculated_total")); // Hapus baris ini karena tidak ada setter
                // Kita set totalAmount dari komponen-komponen ini di objek Bill (misalnya di method recalculateTotal)
                // Kita asumsikan Bill memiliki method ini atau field totalAmount dihitung saat getter getTotalAmount() dipanggil
                // Atau, kita buat Bill memiliki field totalAmount dan setter/getter-nya, dan dihitung di sini
                // Asumsikan Bill memiliki field private double totalAmount dan setter/getter-nya
                bill.setTotalAmount(rs.getDouble("calculated_total")); // Gunakan setter ini jika ada di Bill.java

                bill.setPaid(false); // Karena query hanya ambil yang is_paid = 0
                unpaidBills.add(bill);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return unpaidBills;
    }

    // --- METHOD BARU: Ambil semua bill yang SUDAH dibayar ---
    public List<Bill> getPaidBills() {
        String sql = "SELECT * FROM bills WHERE is_paid = 1 ORDER BY payment_date DESC LIMIT 20"; // Ambil 20 terbaru yang dibayar
        List<Bill> bills = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement(); // Gunakan Statement karena query tidak memiliki parameter
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // bill.setTotalAmount(rs.getDouble("calculated_total")); // Hapus jika dihitung otomatis di getter Bill
                bill.setTotalAmount(rs.getDouble("total_amount")); // Gunakan setter jika Bill memiliki field dan setter totalAmount
                bill.setPaid(rs.getBoolean("is_paid"));
                if (rs.getTimestamp("payment_date") != null) {
                    bill.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                }
                bills.add(bill);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bills;
    }

    // Method opsional: ambil bill berdasarkan ID bill
    public Bill getBillById(int id) {
        String sql = "SELECT * FROM bills WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // bill.setTotalAmount(rs.getDouble("calculated_total")); // Hapus jika dihitung otomatis di getter Bill
                bill.setTotalAmount(rs.getDouble("total_amount")); // Gunakan setter jika Bill memiliki field dan setter totalAmount
                bill.setPaid(rs.getBoolean("is_paid"));
                if (rs.getTimestamp("payment_date") != null) {
                    bill.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                }
                return bill;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- METHOD BARU: Ambil semua bill (lunas dan belum) ---
    public List<Bill> getAllBills() {
        String sql = "SELECT * FROM bills ORDER BY is_paid ASC, id ASC"; // Urutkan: Belum Lunas dulu, lalu Lunas, berdasarkan ID
        List<Bill> bills = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement(); // Statement karena query tidak pakai parameter
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                bill.setTotalAmount(rs.getDouble("total_amount")); // Gunakan setter jika Bill memiliki field totalAmount
                bill.setPaid(rs.getBoolean("is_paid"));
                // Perhatikan: payment_date bisa null jika is_paid false
                if (rs.getTimestamp("payment_date") != null) {
                    bill.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                }
                bills.add(bill);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Log error, gunakan logger di production
        }
        return bills;
    }

    // File: com/mycompany/aplikasiklinik/model/dao/BillDAO.java (diupdate bagian createBill)

        public boolean createBill(Bill bill) {
        // Pastikan query menyertakan consultation_fee
        String sql = "INSERT INTO bills (appointment_id, total_medication_cost, total_service_cost, consultation_fee, total_amount, is_paid) VALUES (?, ?, ?, ?, ?, ?)";
        System.out.println("DEBUG BillDAO: Menjalankan query: " + sql); // Tambahkan logging
        System.out.println("DEBUG BillDAO: Dengan params: AppID=" + bill.getAppointmentId() + ", MedCost=" + bill.getTotalMedicationCost() + ", ServCost=" + bill.getTotalServiceCost() + ", ConsFee=" + bill.getConsultationFee() + ", Total=" + bill.getTotalAmount() + ", Paid=" + bill.isPaid()); // Tambahkan logging parameter

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bill.getAppointmentId());
            stmt.setDouble(2, bill.getTotalMedicationCost());
            stmt.setDouble(3, bill.getTotalServiceCost());
            // --- TAMBAHKAN LOGGING DAN CEK NULL DI SINI ---
            double feeToInsert = bill.getConsultationFee();
            System.out.println("DEBUG BillDAO: Setting parameter 4 (ConsFee) ke nilai: " + feeToInsert); // Tambahkan logging
            if (Double.isNaN(feeToInsert) || Double.isInfinite(feeToInsert)) { // Cek apakah nilainya NaN atau Infinite
                 System.out.println("ERROR BillDAO: Nilai consultation_fee adalah NaN atau Infinite. Tidak bisa disimpan ke database.");
                 return false; // Gagal jika nilai tidak valid
            }
            stmt.setDouble(4, feeToInsert); // Gunakan variabel lokal untuk logging
            // ----------------------------------------------

            // Hitung total_amount di sini atau di Bill entity (lebih baik di entity)
            // Kita gunakan getter totalAmount yang dihitung otomatis oleh Bill
            stmt.setDouble(5, bill.getTotalAmount()); // Gunakan total yang sudah dihitung
            stmt.setBoolean(6, bill.isPaid()); // Default false saat dibuat

            int rowsAffected = stmt.executeUpdate();
            System.out.println("DEBUG BillDAO: Rows affected after executeUpdate: " + rowsAffected); // Tambahkan logging

            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("DEBUG BillDAO: SQLException occurred during createBill: " + e.getMessage()); // Tambahkan logging
            e.printStackTrace(); // Log error
            return false;
        }
    }
}
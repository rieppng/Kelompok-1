/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalSpecialtyDAO; // Import DAO baru
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty; // Import entitas baru
import com.mycompany.aplikasiklinik.view.AdminPanel;
import com.mycompany.aplikasiklinik.view.MainDashboard;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

public class AdminController {
    private MainDashboard dashboard;
    private AdminPanel adminPanel;
    private UserDAO userDAO;
    private MedicalSpecialtyDAO specialtyDAO; // DAO baru

    public AdminController(MainDashboard dashboard, AdminPanel adminPanel, UserDAO userDAO) {
        this.dashboard = dashboard;
        this.adminPanel = adminPanel;
        this.userDAO = userDAO;
        this.specialtyDAO = new MedicalSpecialtyDAO(); // Inisialisasi

        // Load data awal
        loadAllUsers();
        loadAllSpecialties();
        loadSpecialtiesToDoctorCombo();

        // Hubungkan aksi tombol
        this.adminPanel.getBtnAddUser().addActionListener(e -> addUser());
        this.adminPanel.getBtnNavFeeManagement().addActionListener(e -> navigateToFeeManagement());

        // --- Tambahkan listener untuk CRUD Poli ---
        this.adminPanel.getBtnAddSpecialty().addActionListener(e -> addSpecialty());
        this.adminPanel.getBtnUpdateSpecialty().addActionListener(e -> updateSpecialty());
        this.adminPanel.getBtnDeleteSpecialty().addActionListener(e -> deleteSpecialty());
        this.adminPanel.getTableSpecialties().getSelectionModel().addListSelectionListener(this::specialtyTableSelectionChanged);

        // --- Tambahkan listener untuk Tambah Dokter ---
        this.adminPanel.getBtnAddDoctor().addActionListener(e -> addDoctor());

        // --- Tambahkan listener untuk Cari & Update Dokter ---
        this.adminPanel.getBtnSearchDoctor().addActionListener(e -> searchDoctorToUpdate());
        this.adminPanel.getBtnUpdateDoctor().addActionListener(e -> updateDoctor());

        // Muat data spesialisasi ke combo update dokter
        loadSpecialtiesToUpdateDoctorCombo();
    }

    private void navigateToFeeManagement() {
        dashboard.getCardLayout().show(dashboard.getMainPanel(), "FEE_MANAGEMENT");
    }

    // --- Method untuk Manajemen User (lama) ---
    private void addUser() {
        try {
            String username = adminPanel.getUsername();
            String password = adminPanel.getPassword();
            String fullname = adminPanel.getFullname();
            String roleName = adminPanel.getSelectedRole();

            if (username.isEmpty() || password.isEmpty() || fullname.isEmpty()) {
                JOptionPane.showMessageDialog(adminPanel, "Semua field harus diisi!");
                return;
            }

            if (roleName.equals("SUPERADMIN")) {
                JOptionPane.showMessageDialog(adminPanel, "Role SUPERADMIN tidak dapat ditambahkan melalui menu ini!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UserRole role = UserRole.valueOf(roleName);
            User newUser = new User(username, password, fullname, role, 0, false, 0.0); // Default biaya jasa 0.0

            if (userDAO.addUser(newUser)) {
                JOptionPane.showMessageDialog(adminPanel, "User berhasil ditambahkan!");
                adminPanel.clearForm();
                loadAllUsers();
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan user. Mungkin username sudah ada.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(adminPanel, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadAllUsers() {
        DefaultTableModel model = adminPanel.getUserTableModel();
        model.setRowCount(0);

        List<User> users = userDAO.getAllUsers();
        for (User user : users) {
            model.addRow(new Object[]{
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.getRole().toString(),
                user.isActive() ? "Ya" : "Tidak",
                user.getConsultationFee() // Tambahkan kolom biaya jasa
            });
        }
    }

    // --- Method untuk CRUD Poli ---
    private void addSpecialty() {
        String name = adminPanel.getSpecialtyNameInput().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Nama poli tidak boleh kosong!");
            return;
        }

        MedicalSpecialty newSpecialty = new MedicalSpecialty(name);
        if (specialtyDAO.addSpecialty(newSpecialty)) {
            JOptionPane.showMessageDialog(adminPanel, "Poli berhasil ditambahkan!");
            adminPanel.clearSpecialtyForm();
            loadAllSpecialties();
            loadSpecialtiesToDoctorCombo(); // Refresh combo box dokter
        } else {
            JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan poli.");
        }
    }

    private void updateSpecialty() {
        int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(adminPanel, "Pilih poli dari tabel untuk diupdate.");
            return;
        }

        int id = (int) adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0); // Ambil ID dari tabel
        String name = adminPanel.getSpecialtyNameInput().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Nama poli tidak boleh kosong!");
            return;
        }

        MedicalSpecialty updatedSpecialty = new MedicalSpecialty(id, name);
        if (specialtyDAO.updateSpecialty(updatedSpecialty)) {
            JOptionPane.showMessageDialog(adminPanel, "Poli berhasil diperbarui!");
            adminPanel.clearSpecialtyForm();
            loadAllSpecialties();
            loadSpecialtiesToDoctorCombo(); // Refresh combo box dokter
        } else {
            JOptionPane.showMessageDialog(adminPanel, "Gagal memperbarui poli.");
        }
    }

    private void deleteSpecialty() {
        int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(adminPanel, "Pilih poli dari tabel untuk dihapus.");
            return;
        }

        int id = (int) adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0); // Ambil ID dari tabel
        int confirm = JOptionPane.showConfirmDialog(adminPanel, "Yakin hapus poli dengan ID " + id + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (specialtyDAO.deleteSpecialty(id)) {
                JOptionPane.showMessageDialog(adminPanel, "Poli berhasil dihapus!");
                adminPanel.clearSpecialtyForm();
                loadAllSpecialties();
                loadSpecialtiesToDoctorCombo(); // Refresh combo box dokter
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menghapus poli. Mungkin ada dokter yang terdaftar di poli ini.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadAllSpecialties() {
        DefaultTableModel model = adminPanel.getSpecialtyTableModel();
        model.setRowCount(0);

        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) {
            model.addRow(new Object[]{specialty.getId(), specialty.getName()});
        }
    }

    private void specialtyTableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && adminPanel.getTableSpecialties().getSelectedRow() != -1) {
            int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
            String id = adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0).toString();
            String name = adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 1).toString();

            adminPanel.getTxtSpecialtyName().setText(name);
            adminPanel.getBtnUpdateSpecialty().setEnabled(true);
            adminPanel.getBtnDeleteSpecialty().setEnabled(true);
        } else if (!e.getValueIsAdjusting() && adminPanel.getTableSpecialties().getSelectedRow() == -1){
             adminPanel.getBtnUpdateSpecialty().setEnabled(false);
             adminPanel.getBtnDeleteSpecialty().setEnabled(false);
        }
    }

    // --- Method untuk mengisi combo box di form tambah dokter ---
    private void loadSpecialtiesToDoctorCombo() {
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) {
            model.addElement(specialty); // Tambahkan objek MedicalSpecialty
        }
        adminPanel.getComboDoctorSpecialty().setModel(model);
    }

    // --- Method untuk Tambah Dokter ---
    private void addDoctor() {
        String username = adminPanel.getDoctorUsername().trim();
        String password = adminPanel.getDoctorPassword().trim();
        String fullname = adminPanel.getDoctorFullname().trim();
        MedicalSpecialty selectedSpecialty = adminPanel.getSelectedDoctorSpecialty(); // Ambil objek
        String consultationFeeStr = adminPanel.getDoctorConsultationFee().trim(); // Ambil biaya jasa

        if (username.isEmpty() || password.isEmpty() || fullname.isEmpty() || selectedSpecialty == null || consultationFeeStr.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Semua field untuk tambah dokter harus diisi!");
            return;
        }

        try {
            double consultationFee = Double.parseDouble(consultationFeeStr);
            if (consultationFee < 0) {
                JOptionPane.showMessageDialog(adminPanel, "Biaya jasa tidak boleh negatif!");
                return;
            }

            UserRole role = UserRole.DOCTOR;
            User newDoctor = new User(username, password, fullname, role, selectedSpecialty.getId(), false, consultationFee); // Gunakan biaya jasa

            if (userDAO.addUser(newDoctor)) {
                JOptionPane.showMessageDialog(adminPanel, "Dokter berhasil ditambahkan!");
                adminPanel.clearAddDoctorForm();
                loadAllUsers(); // Refresh tabel user
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan dokter. Mungkin username sudah ada.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(adminPanel, "Biaya jasa harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Method Baru: Load Spesialisasi ke Combo Update Dokter ---
    private void loadSpecialtiesToUpdateDoctorCombo() {
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) {
            model.addElement(specialty);
        }
        adminPanel.getComboUpdateSpecialty().setModel(model);
    }

    // --- Method Baru: Cari Dokter untuk Update ---
    private void searchDoctorToUpdate() {
        String idStr = adminPanel.getSearchDoctorId().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Masukkan ID dokter yang akan dicari.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int doctorId = Integer.parseInt(idStr);
            User doctor = userDAO.getUserById(doctorId); // Gunakan method yang sudah diupdate

            if (doctor != null && doctor.getRole() == UserRole.DOCTOR) { // Pastikan user adalah dokter
                // Isi form update dengan data dokter
                adminPanel.getTxtUpdateUsername().setText(doctor.getUsername());
                adminPanel.getTxtUpdateFullname().setText(doctor.getFullName());
                // Set combo spesialisasi berdasarkan ID
                MedicalSpecialty specialty = specialtyDAO.getSpecialtyById(doctor.getMedicalSpecialtyId());
                if (specialty != null) {
                    adminPanel.getComboUpdateSpecialty().setSelectedItem(specialty);
                } else {
                    adminPanel.getComboUpdateSpecialty().setSelectedIndex(-1); // Reset jika tidak ditemukan
                }
                adminPanel.getTxtUpdateConsultationFee().setText(String.valueOf(doctor.getConsultationFee())); // Isi biaya jasa

            } else {
                JOptionPane.showMessageDialog(adminPanel, "Dokter dengan ID " + doctorId + " tidak ditemukan atau bukan dokter.", "Info", JOptionPane.INFORMATION_MESSAGE);
                adminPanel.clearUpdateDoctorForm(); // Reset form jika tidak ditemukan
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(adminPanel, "ID dokter harus berupa angka!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Method Baru: Update Dokter ---
    private void updateDoctor() {
        String idStr = adminPanel.getSearchDoctorId().trim(); // Gunakan ID dari field pencarian
        String username = adminPanel.getTxtUpdateUsername().getText().trim();
        String fullname = adminPanel.getTxtUpdateFullname().getText().trim();
        MedicalSpecialty selectedSpecialty = (MedicalSpecialty) adminPanel.getComboUpdateSpecialty().getSelectedItem();
        String consultationFeeStr = adminPanel.getTxtUpdateConsultationFee().getText().trim();

        if (idStr.isEmpty() || username.isEmpty() || fullname.isEmpty() || selectedSpecialty == null || consultationFeeStr.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Silakan cari dokter terlebih dahulu dan pastikan semua field di form update terisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int doctorId = Integer.parseInt(idStr);
            double consultationFee = Double.parseDouble(consultationFeeStr);
            if (consultationFee < 0) {
                JOptionPane.showMessageDialog(adminPanel, "Biaya jasa tidak boleh negatif!");
                return;
            }

            // Buat objek User baru dengan data yang diperbarui
            User updatedDoctor = new User(doctorId, username, "", fullname, UserRole.DOCTOR, selectedSpecialty.getId(), false, consultationFee); // Kosongkan password, gunakan ID dokter yang ditemukan

            if (userDAO.updateUser(updatedDoctor)) { // Gunakan method updateUser yang baru
                JOptionPane.showMessageDialog(adminPanel, "Data dokter berhasil diperbarui!");
                adminPanel.clearUpdateDoctorForm(); // Bersihkan form setelah update
                loadAllUsers(); // Refresh tabel user
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal memperbarui data dokter. Mungkin dokter tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(adminPanel, "ID dokter dan Biaya jasa harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }
}
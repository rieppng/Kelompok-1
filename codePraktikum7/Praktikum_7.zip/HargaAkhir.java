package com.mycompany.praktikum_7;

public interface HargaAkhir {
    double hitungHarga();
}

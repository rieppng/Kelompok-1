package com.mycompany.praktikum_7;

public class BarangElektronik extends Produk {
    private int garansi;

    public BarangElektronik(String nama, int harga, int garansi) {
        super(nama, harga); // memanggil konstruktor superclass
        this.garansi = garansi;
    }
    public void tampilkanGaransi(){
        System.out.println("Garansi : "+ garansi + " bulan");
    }
    @Override
    public void tampilkanInfo(){
        System.out.println("Nama Produk : "+ nama);
        System.out.println("Harga : "+ harga);
        System.out.println("Garansi : "+ garansi + " bulan");
    }
    @Override
    public double hitungPajak() {
        return harga * 0.01;
    }
    @Override
    public double hitungHarga() {
        return harga * 1.01;
    }
}

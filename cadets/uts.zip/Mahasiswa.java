package com.mycompany.uts;

public class Mahasiswa {
    String nama;
    String nim;
    String prodi;
    int tahun;

    enum PRODI { TEKNIK_ELEKTRO, TEKNIK_INFORMATIKA}

    //constructor
    public Mahasiswa() {
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.tahun = tahun;
    }
    //method overloading tanpa parameter
    void tampilkanBiodataSingkat() {
        System.out.println("Nama: " + nama);
        System.out.println("Nim: " + nim);
    }
    //method overloading dengan parameter
    void tampilkanBiodataLengkap(String nama, String nim, String prodi, int tahun) {
        System.out.println("Nama: " + nama);
        System.out.println("Nim: " + nim);
        System.out.println("Prodi: " + prodi);
        System.out.println("Tahun: " + tahun);
    }

    }

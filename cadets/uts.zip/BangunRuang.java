package com.mycompany.uts;

public class BangunRuang {

}

package com.mycompany.uts;
/*
author @nasywa
 */
import java.util.Scanner;

public class StudentApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char pilihan, pilihan2;

        do {
            System.out.println("===Student App===");
            System.out.println("1. Tampilkan Biodata");
            System.out.println("2. Hitung Umur Akademik");
            System.out.println("3. Keluar");

            switch (pilihan) {
                case 1: //menampilkan pilihan biodata
                    do {
                        System.out.println("Masukkan nama: ");
                        String nama = input.nextLine();
                        System.out.println("Masukkan NIM: ");
                        String nim = input.nextLine();
                        System.out.println("Masukkan Program Studi: ");
                        String prodi = input.nextLine();
                        System.out.println("Masukkan Tahun masuk: ");
                        int tahun = input.nextInt();

                        System.out.print("Isi biodata lagi? (y/t): ");
                        pilihan2 = input.next().charAt(0);
                    } while (pilihan2 == 'y' || pilihan2 == 'Y');
                case 2://menampilkan hitung umur akademik
                    do {
                        System.out.println("Masukkan tahun masuk: ");
                        int tahunMasuk = input.nextInt();
                        int umurAkademik = 2025 - tahunMasuk;
                        System.out.println("Umur akademik: " + umurAkademik);
                        System.out.print("Hitung lagi? (y/t): ");
                        pilihan2 = input.next().charAt(0);
                    } while (pilihan2 == 'y' || pilihan2 == 'Y');
                case 3:
                    System.out.println("TerimaKasih");
                default:
                    System.out.println("Pilihan tidak tersedia, silahkan input kembali");
            }
        }while (pilihan!= '3');
    }
}

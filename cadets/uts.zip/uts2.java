package com.mycompany.uts;

import java.util.Scanner;

public class uts2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char pilihan, pilihan2;
        do {
            System.out.println("===VOLUME DAN LUAS PERMUKAAN BANGUN RUANG===");
            System.out.print("1. Kubus");
            System.out.print("2. Bola");
            System.out.print("3. Limas Persegi");
            System.out.print("4. Rekap Perhitungan");
            System.out.print("5. Keluar");

            switch (pilihan) {
                case 1://menampilkan volume dan LP kubus
                    do {
                        System.out.print("Masukkan sisi: ");
                        double sisi = input.nextDouble();
                        input.nextLine();
                        double volume = (sisi * sisi * sisi);
                        double luasPermukaan = 6 * (sisi * sisi);
                        System.out.println("Volume Kubus: " + volume + " Luas Permukaan Kubus: " + luasPermukaan);
                        System.out.print("Hitung ulang? (y/t): ");
                        pilihan2 = input.next().charAt(0);
                    }while (pilihan2 == 'y'|| pilihan2 == 'Y');
                case 2:
                    do {
                        System.out.print("Masukkan jari-jari: ");
                        double jari = input.nextDouble();
                        input.nextLine();
                        final double PI = 3.14;
                        double volume = 4 / 3 * (PI * jari * jari * jari);
                        double luasPermukaan = 4 * (PI * jari * jari);
                        System.out.println("Volume Bola: " + volume + " Luas Permukaan Bola: " + luasPermukaan);
                        System.out.print("Hitung ulang? (y/t): ");
                        pilihan2 = input.next().charAt(0);
                    }while (pilihan2 == 'y'|| pilihan2 == 'Y');
                case 3:
                    do {
                        System.out.print("Masukkan sisi ");
                        double sisi = input.nextDouble();
                        input.nextLine();
                        System.out.print("Masukkan tinggi: ");
                        double tinggi = input.nextDouble();
                        input.nextLine();
                        double luasAlas = (sisi * sisi);
                        double volume = 1 / 3 * (luasAlas * tinggi);
                        double luasPermukaan = luasAlas + 4 * (1/2*sisi*tinggi);
                        System.out.println("Volume Bola: " + volume + " Luas Permukaan Bola: " + luasPermukaan);
                        System.out.print("Hitung ulang? (y/t): ");
                        pilihan2 = input.next().charAt(0);
                    }while (pilihan2 == 'y'|| pilihan2 == 'Y');
                case 4:
                    System.out.println("Hasil Rekap Perhitungan:");
                case 5:
                    System.out.println("TerimaKasih");
                default:
                    System.out.println("Pilihan tidak tersedia, silahkan input kembali");
            }
        }while (pilihan!= '5');



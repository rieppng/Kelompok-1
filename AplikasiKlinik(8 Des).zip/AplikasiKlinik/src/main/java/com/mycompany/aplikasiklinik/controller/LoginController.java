// File: com/mycompany/aplikasiklinik/controller/LoginController.java (diupdate)
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.LoginView;
import com.mycompany.aplikasiklinik.view.MainDashboard;

import javax.swing.JOptionPane;

public class LoginController {
    private final LoginView view;
    private final UserDAO userDAO;

    public LoginController(LoginView view) {
        this.view = view;
        this.userDAO = new UserDAO();
        this.view.getBtnLogin().addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = view.getUsernameInput();
        String password = view.getPasswordInput();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Username dan Password tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = userDAO.login(username, password);

        if (user != null) {
            SessionManager.getInstance().setCurrentUser(user);

            // --- PERUBAHAN: Update status aktif di database saat login ---
            if (user.getRole() == UserRole.DOCTOR) {
                // Coba update status sebelum set session (opsional, bisa juga setelah)
                boolean statusUpdated = userDAO.updateUserActiveStatus(user.getId(), true); // Set aktif
                if (!statusUpdated) {
                    JOptionPane.showMessageDialog(view, "Gagal memperbarui status login.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Batalkan login jika update gagal
                }
            }

            view.dispose();
            MainDashboard dashboard = new MainDashboard();

            // Logika Logout - DIPERBARUI
            dashboard.getBtnLogout().addActionListener(e -> {
                User currentUser = SessionManager.getInstance().getCurrentUser();

                // --- PERUBAHAN: Update status aktif di database saat logout dokter ---
                if (currentUser != null && currentUser.getRole() == UserRole.DOCTOR) {
                    userDAO.updateUserActiveStatus(currentUser.getId(), false); // Set tidak aktif
                }

                // Reset status pasien IN_CONSULTATION milik dokter yang logout
                if (currentUser != null && "DOCTOR".equals(currentUser.getRole().name())) {
                    AppointmentDAO appointmentDAO = new AppointmentDAO();
                    appointmentDAO.resetDoctorConsultationStatus(currentUser.getId());
                }

                SessionManager.getInstance().setCurrentUser(null);
                dashboard.dispose();

                LoginView newLoginView = new LoginView();
                new LoginController(newLoginView);
                newLoginView.setVisible(true);
            });

            // Inisialisasi Controller untuk setiap panel di Dashboard
            new AdminController(dashboard, dashboard.getAdminPanel(), userDAO);
            new ReceptionistController(dashboard.getReceptionistPanel());
            new InventoryController(dashboard.getInventoryPanel());

            // Kirim userDAO dan ID dokter ke DoctorController
            if ("DOCTOR".equals(user.getRole().name())) {
                new DoctorController(dashboard.getDoctorPanel(), userDAO, user.getId()); // Kirim DAO dan ID dokter
            }

            new CashierController(dashboard.getCashierPanel());
            new ServiceFeeController(dashboard.getServiceFeePanel(), dashboard);

            dashboard.setVisible(true);
            dashboard.showPanel(user.getRole().name());
        } else {
            JOptionPane.showMessageDialog(view, "Username atau Password salah!", "Login Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }
}
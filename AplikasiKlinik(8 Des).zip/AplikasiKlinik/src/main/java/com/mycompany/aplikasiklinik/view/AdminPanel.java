// File: com/mycompany/aplikasiklinik/view/AdminPanel.java (diupdate)
package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty; // Import entitas baru
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Kelas AdminPanel menyediakan antarmuka pengguna berbasis GUI
 * untuk manajemen pengguna (CRUD) dan navigasi ke fitur administrasi lainnya
 * dalam aplikasi klinik.
 */
public class AdminPanel extends JPanel {

    // --- Komponen Asli ---
    private final JTextField txtNewUsername = new JTextField(15);
    private final JTextField txtNewPassword = new JTextField(15);
    private final JTextField txtFullname = new JTextField(20);
    private final JComboBox<String> comboRole = new JComboBox<>(new String[]{"RECEPTIONIST", "DOCTOR", "PHARMACIST", "CASHIER", "SUPERADMIN"}); // Hapus SUPERADMIN dari sini

    private final JButton btnAddUser = new JButton("Tambah User");
    private final JButton btnNavFeeManagement = new JButton("Kelola Biaya Layanan");

    private final JTable tableUsers = new JTable();
    private DefaultTableModel userTableModel;

    // --- Komponen Baru: CRUD Poli ---
    private final JTextField txtSpecialtyName = new JTextField(20);
    private final JTable tableSpecialties = new JTable();
    private DefaultTableModel specialtyTableModel;
    private final JButton btnAddSpecialty = new JButton("Tambah Poli");
    private final JButton btnUpdateSpecialty = new JButton("Update Poli");
    private final JButton btnDeleteSpecialty = new JButton("Hapus Poli");
    

    // --- Komponen Baru: Tambah Dokter ---
    private final JTextField txtDoctorUsername = new JTextField(15);
    private final JTextField txtDoctorPassword = new JTextField(15);
    private final JTextField txtDoctorFullname = new JTextField(20);
    private final JComboBox<MedicalSpecialty> comboDoctorSpecialty = new JComboBox<>(); // Gunakan objek MedicalSpecialty
    private final JButton btnAddDoctor = new JButton("Tambah Dokter");

    public AdminPanel() {
        setLayout(new BorderLayout());
        initializeComponents();
        setupLayout();
    }

    private void initializeComponents() {
        // Inisialisasi model tabel user
        userTableModel = new DefaultTableModel(new Object[]{"ID", "Username", "Nama", "Role", "Aktif"}, 0) { // Tambahkan kolom Aktif
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableUsers.setModel(userTableModel);

        // Inisialisasi model tabel poli
        specialtyTableModel = new DefaultTableModel(new Object[]{"ID", "Nama Poli"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableSpecialties.setModel(specialtyTableModel);
    }

    private void setupLayout() {
        // Panel Utama (Tabbed)
        JTabbedPane tabbedPane = new JTabbedPane();

        // --- Tab 1: Manajemen User (Asli) ---
        JPanel userPanel = new JPanel(new BorderLayout());
        JPanel userFormPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        userFormPanel.setBorder(BorderFactory.createTitledBorder("Tambah Staff Baru"));
        userFormPanel.add(new JLabel("Username:")); userFormPanel.add(txtNewUsername);
        userFormPanel.add(new JLabel("Password:")); userFormPanel.add(txtNewPassword);
        userFormPanel.add(new JLabel("Nama Lengkap:")); userFormPanel.add(txtFullname);
        userFormPanel.add(new JLabel("Role:")); userFormPanel.add(comboRole);
        userFormPanel.add(new JLabel("")); userFormPanel.add(btnAddUser);
        userPanel.add(userFormPanel, BorderLayout.NORTH);
        userPanel.add(new JScrollPane(tableUsers), BorderLayout.CENTER);
        tabbedPane.addTab("Manajemen User", userPanel);

        // --- Tab 2: Manajemen Poli ---
        JPanel specialtyPanel = new JPanel(new BorderLayout());
        JPanel specialtyFormPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        specialtyFormPanel.setBorder(BorderFactory.createTitledBorder("Tambah/Update Poli"));
        specialtyFormPanel.add(new JLabel("Nama Poli:")); specialtyFormPanel.add(txtSpecialtyName);
        JPanel specialtyButtonPanel = new JPanel();
        specialtyButtonPanel.add(btnAddSpecialty);
        specialtyButtonPanel.add(btnUpdateSpecialty);
        specialtyButtonPanel.add(btnDeleteSpecialty);
        specialtyFormPanel.add(new JLabel("")); specialtyFormPanel.add(specialtyButtonPanel);
        specialtyPanel.add(specialtyFormPanel, BorderLayout.NORTH);
        specialtyPanel.add(new JScrollPane(tableSpecialties), BorderLayout.CENTER);
        tabbedPane.addTab("Manajemen Poli", specialtyPanel);

        // --- Tab 3: Tambah Dokter ---
        JPanel addDoctorPanel = new JPanel(new BorderLayout());
        JPanel addDoctorFormPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        addDoctorFormPanel.setBorder(BorderFactory.createTitledBorder("Tambah Dokter Baru"));
        addDoctorFormPanel.add(new JLabel("Username:")); addDoctorFormPanel.add(txtDoctorUsername);
        addDoctorFormPanel.add(new JLabel("Password:")); addDoctorFormPanel.add(txtDoctorPassword);
        addDoctorFormPanel.add(new JLabel("Nama Lengkap:")); addDoctorFormPanel.add(txtDoctorFullname);
        addDoctorFormPanel.add(new JLabel("Poli:")); addDoctorFormPanel.add(comboDoctorSpecialty);
        addDoctorFormPanel.add(new JLabel("")); addDoctorFormPanel.add(btnAddDoctor);
        addDoctorPanel.add(addDoctorFormPanel, BorderLayout.NORTH);
        tabbedPane.addTab("Tambah Dokter", addDoctorPanel);

        // Panel Navigasi (Utara)
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        navPanel.setBorder(BorderFactory.createTitledBorder("Navigasi Admin"));
        navPanel.add(btnNavFeeManagement);
        add(navPanel, BorderLayout.NORTH);

        add(tabbedPane, BorderLayout.CENTER);
    }

    // --- Getter untuk komponen asli ---
    public String getUsername() { return txtNewUsername.getText(); }
    public String getPassword() { return txtNewPassword.getText(); }
    public String getFullname() { return txtFullname.getText(); }
    public String getSelectedRole() { return (String) comboRole.getSelectedItem(); }
    public JButton getBtnAddUser() { return btnAddUser; }
    public JButton getBtnNavFeeManagement() { return btnNavFeeManagement; }
    public DefaultTableModel getUserTableModel() { return userTableModel; }

    // --- Getter untuk komponen CRUD Poli ---
    public String getSpecialtyNameInput() { return txtSpecialtyName.getText(); }
    public JTable getTableSpecialties() { return tableSpecialties; }
    public DefaultTableModel getSpecialtyTableModel() { return specialtyTableModel; }
    public JButton getBtnAddSpecialty() { return btnAddSpecialty; }
    public JButton getBtnUpdateSpecialty() { return btnUpdateSpecialty; }
    public JButton getBtnDeleteSpecialty() { return btnDeleteSpecialty; }
    public JTextField getTxtSpecialtyName() { return txtSpecialtyName; } 

    // --- Getter untuk komponen Tambah Dokter ---
    public String getDoctorUsername() { return txtDoctorUsername.getText(); }
    public String getDoctorPassword() { return txtDoctorPassword.getText(); }
    public String getDoctorFullname() { return txtDoctorFullname.getText(); }
    public MedicalSpecialty getSelectedDoctorSpecialty() { return (MedicalSpecialty) comboDoctorSpecialty.getSelectedItem(); } // Ambil objek
    public JButton getBtnAddDoctor() { return btnAddDoctor; }

    // --- Getter untuk mengisi combo box dokter ---
    public JComboBox<MedicalSpecialty> getComboDoctorSpecialty() { return comboDoctorSpecialty; }

    public void clearForm() {
        txtNewUsername.setText("");
        txtNewPassword.setText("");
        txtFullname.setText("");
    }

    public void clearSpecialtyForm() {
        txtSpecialtyName.setText("");
        tableSpecialties.clearSelection();
        btnUpdateSpecialty.setEnabled(false);
        btnDeleteSpecialty.setEnabled(false);
    }

    public void clearAddDoctorForm() {
        txtDoctorUsername.setText("");
        txtDoctorPassword.setText("");
        txtDoctorFullname.setText("");
        comboDoctorSpecialty.setSelectedIndex(-1);
    }
}
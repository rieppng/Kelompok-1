/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalSpecialtyDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty;
import com.mycompany.aplikasiklinik.view.ReceptionistPanel;

import java.awt.Component;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date; // Import Date
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class ReceptionistController {
    private final ReceptionistPanel receptionistPanel;
    private final UserDAO userDAO;
    private final PatientDAO patientDAO;
    private final AppointmentDAO appointmentDAO;
    private final MedicalSpecialtyDAO specialtyDAO; 

    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 6000;

    public ReceptionistController(ReceptionistPanel receptionistPanel) {
        this.receptionistPanel = receptionistPanel;
        this.userDAO = new UserDAO();
        this.patientDAO = new PatientDAO();
        this.appointmentDAO = new AppointmentDAO();
        this.specialtyDAO = new MedicalSpecialtyDAO();

        // Custom Renderer
        receptionistPanel.getComboActiveDoctor().setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof User) {
                    User doctor = (User) value;
                    setText(doctor.getFullName()); 
                }
                return this;
            }
        });

        loadSpecialtiesList(); 
        loadQueueList();

        receptionistPanel.getBtnAddToQueue().addActionListener(e -> handleAddToQueue());
        receptionistPanel.getComboSpecialty().addActionListener(e -> loadActiveDoctorsForSelectedSpecialty());
        receptionistPanel.getBtnRefreshDoctorList().addActionListener(e -> loadActiveDoctorsForSelectedSpecialty());
        
        // --- Listener Tombol Cari NIK ---
        receptionistPanel.getBtnSearchNik().addActionListener(e -> handleSearchByNik());
        
        startAutoRefresh();
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> loadQueueList());
        refreshTimer.start();
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    private void loadSpecialtiesList() {
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        for (MedicalSpecialty specialty : specialties) {
            model.addElement(specialty);
        }
        receptionistPanel.getComboSpecialty().setModel(model);
        receptionistPanel.getComboActiveDoctor().setModel(new DefaultComboBoxModel<>());
    }

    private void loadActiveDoctorsForSelectedSpecialty() {
        MedicalSpecialty selectedSpecialty = (MedicalSpecialty) receptionistPanel.getComboSpecialty().getSelectedItem();
        if (selectedSpecialty == null) {
            receptionistPanel.getComboActiveDoctor().setModel(new DefaultComboBoxModel<>());
            return;
        }

        List<User> activeDoctorsInSpecialty = userDAO.getActiveDoctorsBySpecialtyId(selectedSpecialty.getId());

        DefaultComboBoxModel<User> model = new DefaultComboBoxModel<>();
        for (User doctor : activeDoctorsInSpecialty) {
            model.addElement(doctor);
        }

        receptionistPanel.getComboActiveDoctor().setModel(model);
    }

    private void loadQueueList() {
        List<Appointment> waitingList = appointmentDAO.getAppointmentsByDate(LocalDate.now());

        receptionistPanel.getQueueModel().setRowCount(0);

        for (Appointment app : waitingList) {
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            User doctor = userDAO.getUserById(app.getDoctorId());

            String patientName = (patient != null) ? patient.getName() : "Pasien Error";
            String doctorName = (doctor != null) ? doctor.getFullName() : "Dokter Error"; 

            receptionistPanel.getQueueModel().addRow(new Object[]{
                app.getQueueNumber(),
                patientName,
                doctorName,
                app.getStatus()
            });
        }
    }
    
    // --- METHOD BARU: Logika Pencarian NIK ---
    private void handleSearchByNik() {
        String nik = receptionistPanel.getNik().trim();
        if (nik.isEmpty()) {
            JOptionPane.showMessageDialog(receptionistPanel, "Masukkan NIK terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Patient existingPatient = patientDAO.getPatientByNik(nik);
        
        if (existingPatient != null) {
            // Data ditemukan, isi form otomatis
            receptionistPanel.getTxtName().setText(existingPatient.getName());
            receptionistPanel.getTxtAddress().setText(existingPatient.getAddress());
            receptionistPanel.getTxtPhone().setText(existingPatient.getPhoneNumber());
            receptionistPanel.setGender(existingPatient.getGender());
            receptionistPanel.getDateChooserDob().setDate(java.sql.Date.valueOf(existingPatient.getBirthDate()));
            
            // Simpan ID pasien lama di komponen hidden untuk referensi nanti
            receptionistPanel.setExistingPatientId(existingPatient.getId());
            
            JOptionPane.showMessageDialog(receptionistPanel, "Data Pasien Lama Ditemukan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Data tidak ditemukan
            receptionistPanel.setExistingPatientId(0); // Reset ID
            // Opsional: Clear form selain NIK
            // receptionistPanel.getTxtName().setText(""); 
            JOptionPane.showMessageDialog(receptionistPanel, "Data Pasien tidak ditemukan. Silakan isi form manual.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void handleAddToQueue() {
        String doctorIdStr = receptionistPanel.getSelectedDoctorId();
        if (doctorIdStr == null) {
             JOptionPane.showMessageDialog(receptionistPanel, "Pilih dokter aktif dari daftar!", "Peringatan", JOptionPane.WARNING_MESSAGE);
             return;
        }

        String name = receptionistPanel.getPatientName().trim();
        String nik = receptionistPanel.getNik().trim();
        LocalDate birthDate = receptionistPanel.getDob();
        String phone = receptionistPanel.getPhone().trim();
        String address = receptionistPanel.getAddress().trim();
        String weightStr = receptionistPanel.getWeight().trim();
        String heightStr = receptionistPanel.getPatientHeight().trim();
        String bloodPressure = receptionistPanel.getBloodPressure().trim(); 
        String gender = receptionistPanel.getSelectedGender();
        
        int doctorId = Integer.parseInt(doctorIdStr);

        if (name.isEmpty() || nik.isEmpty() || phone.isEmpty() || address.isEmpty() ||
            weightStr.isEmpty() || heightStr.isEmpty() || birthDate == null || gender == null) {

            JOptionPane.showMessageDialog(receptionistPanel, "Semua kolom (termasuk Gender) wajib diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double weight = Double.parseDouble(weightStr);
            double height = Double.parseDouble(heightStr);
            
            int patientIdToUse = 0;
            int existingId = receptionistPanel.getExistingPatientId();
            
            // Cek apakah NIK ini sudah ada di database (Validasi Duplikasi Manual)
            Patient checkDuplicate = patientDAO.getPatientByNik(nik);
            
            if (existingId > 0) {
                // Skenario 1: Resepsionis sudah klik "Cari" dan data ditemukan
                // Pastikan NIK di form masih sama dengan NIK pasien lama
                if (checkDuplicate != null && checkDuplicate.getId() == existingId) {
                    patientIdToUse = existingId;
                } else {
                    // Jika user mengubah NIK setelah search, anggap sebagai pasien baru atau error
                    // Di sini kita anggap error agar konsisten
                    JOptionPane.showMessageDialog(receptionistPanel, "NIK tidak sesuai dengan data pencarian awal. Silakan cari ulang.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                // Skenario 2: Resepsionis input manual (Pasien Baru)
                // VALIDASI NIK DUPLIKAT
                if (checkDuplicate != null) {
                    // Jika NIK ditemukan tapi existingId masih 0 (belum di-load ke form), tolak
                    JOptionPane.showMessageDialog(receptionistPanel, 
                        "NIK " + nik + " sudah terdaftar atas nama " + checkDuplicate.getName() + ".\n" +
                        "Silakan gunakan tombol 'Cari' untuk memuat data pasien lama.", 
                        "Duplikasi Data", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                // Jika lolos, buat pasien baru
                Patient newPatient = new Patient(0, name, nik, birthDate, gender, address, phone);
                patientIdToUse = patientDAO.addPatient(newPatient);
            }

            if (patientIdToUse > 0) {
                Appointment newAppt = new Appointment();
                newAppt.setPatientId(patientIdToUse);
                newAppt.setDoctorId(doctorId);
                newAppt.setDate(LocalDate.now());
                newAppt.setWeight(weight);
                newAppt.setHeight(height);
                newAppt.setBloodPressure(bloodPressure);
                newAppt.setStatus("WAITING");

                int queueNumber = appointmentDAO.getNextQueueNumber(doctorId, LocalDate.now());
                newAppt.setQueueNumber(queueNumber);

                if (appointmentDAO.addAppointment(newAppt)) {
                    JOptionPane.showMessageDialog(receptionistPanel,
                            "Pasien " + name + " terdaftar! No. Antrian: " + queueNumber);

                    receptionistPanel.clearForm();
                    loadQueueList(); 
                } else {
                    JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan antrian.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(receptionistPanel, "Gagal memproses data pasien.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(receptionistPanel, "Berat dan Tinggi harus berupa angka!", "Error Input", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan pasien/antrian: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
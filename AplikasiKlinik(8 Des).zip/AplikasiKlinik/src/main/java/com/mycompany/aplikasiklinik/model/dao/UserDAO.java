// File: com/mycompany/aplikasiklinik/model/dao/UserDAO.java (diupdate)
package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty; // Import entitas baru

public class UserDAO {
    // Fitur Login (diupdate)
    public User login(String username, String password) {
        String sql = "SELECT u.id, u.username, u.password, u.full_name, u.role, u.medical_specialty_id, u.is_active FROM users u WHERE u.username = ? AND u.password = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("full_name"),
                    UserRole.valueOf(rs.getString("role")),
                    rs.getInt("medical_specialty_id"),
                    rs.getBoolean("is_active") // Ambil status aktif
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Fitur Superadmin: Tambah Staff (diupdate)
    public boolean addUser(User user) {
        String sql = "INSERT INTO users (username, password, full_name, role, medical_specialty_id, is_active) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getFullName());
            stmt.setString(4, user.getRole().name());
            stmt.setInt(5, user.getMedicalSpecialtyId());
            stmt.setBoolean(6, user.isActive()); // Simpan status aktif

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Mendapatkan List Dokter untuk Dropdown Resepsionis (diupdate)
    public List<User> getAllDoctors() {
        List<User> doctors = new ArrayList<>();
        String sql = "SELECT u.id, u.username, u.full_name, u.medical_specialty_id, u.is_active FROM users u WHERE u.role = 'DOCTOR'";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()) {
                User doctor = new User();
                doctor.setId(rs.getInt("id"));
                doctor.setUsername(rs.getString("username"));
                doctor.setFullName(rs.getString("full_name"));
                doctor.setMedicalSpecialtyId(rs.getInt("medical_specialty_id"));
                doctor.setRole(UserRole.DOCTOR);
                doctor.setActive(rs.getBoolean("is_active")); // Set status aktif
                doctors.add(doctor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctors;
    }

    public List<User> getDoctors() {
        // Hanya ambil user dengan role 'DOCTOR'
        String sql = "SELECT id, username, full_name, is_active FROM users WHERE role = 'DOCTOR'"; // Tambahkan is_active
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            List<User> doctors = new ArrayList<>();
            while(rs.next()) {
                doctors.add(new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    "", // Password diabaikan
                    rs.getString("full_name"),
                    UserRole.DOCTOR
                    // Tidak set isActive di sini karena constructor tidak menyertakannya
                ));
            }
            return doctors;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>(); // Kembalikan list kosong jika error
    }

    // Tambahkan method ini di dalam class UserDAO
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT id, username, full_name, role, is_active FROM users"; // Tambahkan is_active
        try (Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()) {
                list.add(new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    "***", // Sembunyikan password
                    rs.getString("full_name"),
                    UserRole.valueOf(rs.getString("role")),
                    0, // medicalSpecialtyId di sini bisa diisi jika diperlukan
                    rs.getBoolean("is_active") // Ambil status aktif
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // METHOD YANG HILANG: Digunakan untuk mendapatkan nama dokter/user berdasarkan ID (diupdate)
    public User getUserById(int id) {
        String sql = "SELECT u.id, u.username, u.full_name, u.role, u.medical_specialty_id, u.is_active FROM users u WHERE u.id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setFullName(rs.getString("full_name"));
                user.setRole(UserRole.valueOf(rs.getString("role")));
                user.setMedicalSpecialtyId(rs.getInt("medical_specialty_id"));
                user.setActive(rs.getBoolean("is_active")); // Set status aktif
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- METHOD BARU: Update status aktif user ---
    public boolean updateUserActiveStatus(int userId, boolean isActive) {
        String sql = "UPDATE users SET is_active = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBoolean(1, isActive); // true untuk aktif, false untuk tidak aktif
            stmt.setInt(2, userId);       // ID user yang statusnya diupdate

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- METHOD BARU: Ambil dokter aktif berdasarkan ID Poli ---
    public List<User> getActiveDoctorsBySpecialtyId(int specialtyId) {
        // Query ini sekarang mengambil dokter aktif dari database
        String sql = "SELECT u.id, u.username, u.full_name, u.medical_specialty_id, u.is_active FROM users u WHERE u.role = 'DOCTOR' AND u.medical_specialty_id = ? AND u.is_active = TRUE"; // Filter aktif
        List<User> doctors = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, specialtyId);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                User doctor = new User();
                doctor.setId(rs.getInt("id"));
                doctor.setUsername(rs.getString("username"));
                doctor.setFullName(rs.getString("full_name"));
                doctor.setMedicalSpecialtyId(rs.getInt("medical_specialty_id"));
                doctor.setRole(UserRole.DOCTOR);
                doctor.setActive(rs.getBoolean("is_active")); // Status aktif pasti true karena filter query
                doctors.add(doctor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctors;
    }
}
// File: com/mycompany/aplikasiklinik/model/entity/User.java (diupdate)
package com.mycompany.aplikasiklinik.model.entity;

import java.util.Objects;

public class User {
    private int id;
    private String username;
    private String password;
    private String fullName;
    private UserRole role;
    private int medicalSpecialtyId;
    private MedicalSpecialty medicalSpecialty;
    // --- TAMBAHAN: Field untuk status aktif ---
    private boolean isActive;

    public User() {}

    public User(int id, String username, String password, String fullName, UserRole role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }

    public User(String username, String password, String fullName, UserRole role) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }

    // Constructor baru dengan isActive
    public User(int id, String username, String password, String fullName, UserRole role, int medicalSpecialtyId, boolean isActive) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
        this.medicalSpecialtyId = medicalSpecialtyId;
        this.isActive = isActive;
    }

    // Constructor tanpa ID, dengan isActive
    public User(String username, String password, String fullName, UserRole role, int medicalSpecialtyId, boolean isActive) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
        this.medicalSpecialtyId = medicalSpecialtyId;
        this.isActive = isActive;
    }

    // Getters and Setters (lama)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public UserRole getRole() { return role; }
    public void setRole(UserRole role) { this.role = role; }

    // Getter dan Setter untuk ID Poli
    public int getMedicalSpecialtyId() { return medicalSpecialtyId; }
    public void setMedicalSpecialtyId(int medicalSpecialtyId) { this.medicalSpecialtyId = medicalSpecialtyId; }

    // Getter dan Setter untuk Objek Poli
    public MedicalSpecialty getMedicalSpecialty() { return medicalSpecialty; }
    public void setMedicalSpecialty(MedicalSpecialty medicalSpecialty) { this.medicalSpecialty = medicalSpecialty; }

    // --- Getter dan Setter untuk isActive ---
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", role=" + role +
                ", isActive=" + isActive + // Tambahkan field ini
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id == user.id && Objects.equals(username, user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, username);
    }
}
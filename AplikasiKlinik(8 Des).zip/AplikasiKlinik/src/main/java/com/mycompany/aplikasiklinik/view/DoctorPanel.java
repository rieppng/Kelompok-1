package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DoctorPanel extends JPanel {
    // --- LAYOUT MANAGERS ---
    private final CardLayout leftCardLayout = new CardLayout();
    private final JPanel leftMainPanel = new JPanel(leftCardLayout); // Container untuk Kiri

    // --- KOMPONEN PANEL KIRI 1: ANTRIAN (QUEUE) ---
    private final JPanel pnlQueue = new JPanel(new BorderLayout());
    private final JTable tableWaitingList = new JTable();
    private DefaultTableModel waitingListModel;
    private final JButton btnStartConsult = new JButton("Mulai Periksa");

    // --- KOMPONEN PANEL KIRI 2: INFO PASIEN (INFO) ---
    private final JPanel pnlPatientInfo = new JPanel(new GridBagLayout());
    // Label untuk menampilkan data (Non-editable)
    private final JLabel lblInfoName = new JLabel("-");
    private final JLabel lblInfoNik = new JLabel("-");
    private final JLabel lblInfoGender = new JLabel("-");
    private final JLabel lblInfoDob = new JLabel("-");
    private final JLabel lblInfoPhone = new JLabel("-");
    private final JTextArea txtInfoAddress = new JTextArea(3, 20);
    // Vital Signs
    private final JLabel lblInfoWeight = new JLabel("-");
    private final JLabel lblInfoHeight = new JLabel("-");
    private final JLabel lblInfoBloodPressure = new JLabel("-");
    
    // Tombol Batalkan / Kembali (Opsional, jika dokter salah pilih)
    // private final JButton btnCancelConsult = new JButton("Batal / Kembali ke Antrian"); 

    // --- KOMPONEN PANEL KANAN: PEMERIKSAAN ---
    private final JTextArea txtSymptoms = new JTextArea(3, 20);
    private final JTextArea txtDiagnosis = new JTextArea(3, 20);
    private final JTextArea txtTreatment = new JTextArea(3, 20);
    private final JComboBox<ServiceFee> comboTreatmentService = new JComboBox<>(); 
    private final JTable tablePrescription = new JTable(); 
    private DefaultTableModel prescriptionModel;
    
    private final JButton btnRemoveSelectedPrescription = new JButton("Hapus Item Dipilih");
    private final JButton btnSaveRecord = new JButton("Simpan Rekam Medis");
    private final JButton btnAddMedication = new JButton("Tambah Obat");

    public DoctorPanel() {
        setLayout(new GridLayout(1, 2)); // Split Kiri - Kanan utama

        // ====================================================================
        // 1. SETUP PANEL KIRI (CARD LAYOUT: QUEUE vs INFO)
        // ====================================================================
        
        // --- Card 1: Queue Panel ---
        pnlQueue.setBorder(BorderFactory.createTitledBorder("Daftar Tunggu Pasien"));
        waitingListModel = new DefaultTableModel(new Object[]{"No", "Nama Pasien", "Status"}, 0);
        tableWaitingList.setModel(waitingListModel);
        pnlQueue.add(new JScrollPane(tableWaitingList), BorderLayout.CENTER);
        pnlQueue.add(btnStartConsult, BorderLayout.SOUTH);

        // --- Card 2: Patient Info Panel ---
        pnlPatientInfo.setBorder(BorderFactory.createTitledBorder("Informasi Pasien"));
        setupPatientInfoLayout(); // Helper method untuk tata letak label

        // Masukkan kedua panel ke Container Kiri
        leftMainPanel.add(pnlQueue, "QUEUE");
        leftMainPanel.add(pnlPatientInfo, "INFO");

        // Tambahkan Container Kiri ke Layar Utama
        add(leftMainPanel);

        // ====================================================================
        // 2. SETUP PANEL KANAN (PEMERIKSAAN - Tetap Sama)
        // ====================================================================
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Form Pemeriksaan"));
        
        // Panel Input Diagnosa
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Data Medis"));
        inputPanel.add(new JLabel("Keluhan/Gejala:")); inputPanel.add(new JScrollPane(txtSymptoms));
        inputPanel.add(new JLabel("Diagnosa:")); inputPanel.add(new JScrollPane(txtDiagnosis));
        inputPanel.add(new JLabel("Tindakan (Ket):")); inputPanel.add(new JScrollPane(txtTreatment));
        inputPanel.add(new JLabel("Pilih Layanan:")); inputPanel.add(comboTreatmentService);

        rightPanel.add(inputPanel, BorderLayout.NORTH);

        // Panel Tabel Resep
        JPanel prescriptionPanel = new JPanel(new BorderLayout());
        prescriptionPanel.setBorder(BorderFactory.createTitledBorder("Resep & Tindakan"));
        prescriptionModel = new DefaultTableModel(new Object[]{"Jenis", "Nama", "Qty", "Harga", "Subtotal", "Aturan Pakai"}, 0);
        tablePrescription.setModel(prescriptionModel);
        prescriptionPanel.add(new JScrollPane(tablePrescription), BorderLayout.CENTER);

        JPanel prescriptionButtonPanel = new JPanel(new FlowLayout());
        prescriptionButtonPanel.add(btnRemoveSelectedPrescription);
        prescriptionPanel.add(prescriptionButtonPanel, BorderLayout.SOUTH);

        rightPanel.add(prescriptionPanel, BorderLayout.CENTER); 

        // Panel Tombol Bawah
        JPanel mainActionPanel = new JPanel(new FlowLayout());
        mainActionPanel.add(btnAddMedication);
        mainActionPanel.add(btnSaveRecord);
        rightPanel.add(mainActionPanel, BorderLayout.SOUTH); 

        add(rightPanel);
        
        // Default View: Tampilkan Antrian
        showQueueView();
    }

    private void setupPatientInfoLayout() {
        txtInfoAddress.setEditable(false);
        txtInfoAddress.setBackground(new Color(240, 240, 240)); // Abu-abu read-only
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Baris 0: Nama
        gbc.gridx = 0; gbc.gridy = 0; pnlPatientInfo.add(new JLabel("Nama:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; 
        lblInfoName.setFont(new Font("SansSerif", Font.BOLD, 14));
        pnlPatientInfo.add(lblInfoName, gbc);

        // Baris 1: NIK & Gender
        gbc.gridx = 0; gbc.gridy = 1; pnlPatientInfo.add(new JLabel("NIK:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; pnlPatientInfo.add(lblInfoNik, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; pnlPatientInfo.add(new JLabel("Gender:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; pnlPatientInfo.add(lblInfoGender, gbc);

        // Baris 3: Tgl Lahir
        gbc.gridx = 0; gbc.gridy = 3; pnlPatientInfo.add(new JLabel("Tgl Lahir:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3; pnlPatientInfo.add(lblInfoDob, gbc);

        // Baris 4: HP
        gbc.gridx = 0; gbc.gridy = 4; pnlPatientInfo.add(new JLabel("No HP:"), gbc);
        gbc.gridx = 1; gbc.gridy = 4; pnlPatientInfo.add(lblInfoPhone, gbc);

        // Baris 5: Alamat
        gbc.gridx = 0; gbc.gridy = 5; pnlPatientInfo.add(new JLabel("Alamat:"), gbc);
        gbc.gridx = 1; gbc.gridy = 5; pnlPatientInfo.add(new JScrollPane(txtInfoAddress), gbc);

        // Separator
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2; 
        pnlPatientInfo.add(new JSeparator(), gbc);
        gbc.gridwidth = 1;

        // Vital Signs Title
        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2;
        JLabel lblVital = new JLabel("Tanda Vital (Saat Pendaftaran)");
        lblVital.setFont(new Font("SansSerif", Font.BOLD, 12));
        pnlPatientInfo.add(lblVital, gbc);
        gbc.gridwidth = 1;

        // Baris 8: Berat & Tinggi
        gbc.gridx = 0; gbc.gridy = 8; pnlPatientInfo.add(new JLabel("Berat (kg):"), gbc);
        gbc.gridx = 1; gbc.gridy = 8; pnlPatientInfo.add(lblInfoWeight, gbc);

        gbc.gridx = 0; gbc.gridy = 9; pnlPatientInfo.add(new JLabel("Tinggi (cm):"), gbc);
        gbc.gridx = 1; gbc.gridy = 9; pnlPatientInfo.add(lblInfoHeight, gbc);

        gbc.gridx = 0; gbc.gridy = 10; pnlPatientInfo.add(new JLabel("Tensi:"), gbc);
        gbc.gridx = 1; gbc.gridy = 10; pnlPatientInfo.add(lblInfoBloodPressure, gbc);
        
        // Spacer kosong di bawah agar layout naik ke atas
        gbc.gridy = 11; gbc.weighty = 1.0; // Mengisi sisa ruang vertikal
        pnlPatientInfo.add(new JLabel(), gbc);
    }

    // --- METHOD UNTUK NAVIGASI KARTU ---
    public void showQueueView() {
        leftCardLayout.show(leftMainPanel, "QUEUE");
    }

    public void showPatientInfoView() {
        leftCardLayout.show(leftMainPanel, "INFO");
    }

    // --- SETTERS UNTUK INFO PASIEN ---
    public void setPatientInfo(String name, String nik, String gender, String dob, String phone, String address, String weight, String height, String bp) {
        lblInfoName.setText(name);
        lblInfoNik.setText(nik);
        lblInfoGender.setText(gender.equals("L") ? "Laki-laki" : "Perempuan");
        lblInfoDob.setText(dob);
        lblInfoPhone.setText(phone);
        txtInfoAddress.setText(address);
        lblInfoWeight.setText(weight);
        lblInfoHeight.setText(height);
        lblInfoBloodPressure.setText(bp == null ? "-" : bp);
    }

    // Getters
    public JTable getTableWaitingList() { return tableWaitingList; }
    public DefaultTableModel getWaitingListModel() { return waitingListModel; }
    public JButton getBtnStartConsult() { return btnStartConsult; }

    public String getSymptoms() { return txtSymptoms.getText(); }
    public String getDiagnosis() { return txtDiagnosis.getText(); }
    public String getTreatment() { return txtTreatment.getText(); }

    public JComboBox<ServiceFee> getComboTreatmentService() { return comboTreatmentService; }
    public JButton getBtnRemoveSelectedPrescription() { return btnRemoveSelectedPrescription; }
    public JButton getBtnAddMedication() { return btnAddMedication; }
    public DefaultTableModel getPrescriptionModel() { return prescriptionModel; }
    public JButton getBtnSaveRecord() { return btnSaveRecord; }

    public void clearForm() {
        txtSymptoms.setText("");
        txtDiagnosis.setText("");
        txtTreatment.setText("");
        prescriptionModel.setRowCount(0);
        comboTreatmentService.setSelectedIndex(-1); 
    }

    public JTextArea getTxtSymptoms() { return txtSymptoms; }
    public JTextArea getTxtDiagnosis() { return txtDiagnosis; }
    public JTextArea getTxtTreatment() { return txtTreatment; }
    public JTable getTablePrescription() { return tablePrescription; }
}
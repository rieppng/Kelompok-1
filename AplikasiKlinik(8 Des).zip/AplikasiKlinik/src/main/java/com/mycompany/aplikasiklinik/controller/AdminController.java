/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalSpecialtyDAO; // Import DAO baru
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty; // Import entitas baru
import com.mycompany.aplikasiklinik.view.AdminPanel;
import com.mycompany.aplikasiklinik.view.MainDashboard;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

public class AdminController {
    private MainDashboard dashboard;
    private AdminPanel adminPanel;
    private UserDAO userDAO;
    private MedicalSpecialtyDAO specialtyDAO; // DAO baru

    public AdminController(MainDashboard dashboard, AdminPanel adminPanel, UserDAO userDAO) {
        this.dashboard = dashboard;
        this.adminPanel = adminPanel;
        this.userDAO = userDAO;
        this.specialtyDAO = new MedicalSpecialtyDAO(); // Inisialisasi

        // Load data awal
        loadAllUsers();
        loadAllSpecialties(); // Load data poli
        loadSpecialtiesToDoctorCombo(); // Load data ke combo box dokter

        // Hubungkan aksi tombol
        this.adminPanel.getBtnAddUser().addActionListener(e -> addUser());
        this.adminPanel.getBtnNavFeeManagement().addActionListener(e -> navigateToFeeManagement());

        // --- Tambahkan listener untuk CRUD Poli ---
        this.adminPanel.getBtnAddSpecialty().addActionListener(e -> addSpecialty());
        this.adminPanel.getBtnUpdateSpecialty().addActionListener(e -> updateSpecialty());
        this.adminPanel.getBtnDeleteSpecialty().addActionListener(e -> deleteSpecialty());
        // Tambahkan listener untuk pemilihan baris di tabel poli
        this.adminPanel.getTableSpecialties().getSelectionModel().addListSelectionListener(this::specialtyTableSelectionChanged);

        // --- Tambahkan listener untuk Tambah Dokter ---
        this.adminPanel.getBtnAddDoctor().addActionListener(e -> addDoctor());
    }

    private void navigateToFeeManagement() {
        dashboard.getCardLayout().show(dashboard.getMainPanel(), "FEE_MANAGEMENT");
    }

    // --- Method untuk Manajemen User (lama) ---
    private void addUser() {
        try {
            String username = adminPanel.getUsername();
            String password = adminPanel.getPassword();
            String fullname = adminPanel.getFullname();
            String roleName = adminPanel.getSelectedRole();

            if (username.isEmpty() || password.isEmpty() || fullname.isEmpty()) {
                JOptionPane.showMessageDialog(adminPanel, "Semua field harus diisi!");
                return;
            }

            if (roleName.equals("SUPERADMIN")) {
                JOptionPane.showMessageDialog(adminPanel, "Role SUPERADMIN tidak dapat ditambahkan melalui menu ini!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UserRole role = UserRole.valueOf(roleName);
            // medical_specialty_id di-set 0 untuk non-dokter, isActive false
            User newUser = new User(username, password, fullname, role, 0, false);

            if (userDAO.addUser(newUser)) {
                JOptionPane.showMessageDialog(adminPanel, "User berhasil ditambahkan!");
                adminPanel.clearForm();
                loadAllUsers();
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan user. Mungkin username sudah ada.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(adminPanel, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadAllUsers() {
        DefaultTableModel model = adminPanel.getUserTableModel();
        model.setRowCount(0);

        List<User> users = userDAO.getAllUsers();
        for (User user : users) {
            model.addRow(new Object[]{
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.getRole().toString(),
                user.isActive() ? "Ya" : "Tidak" // Tampilkan status aktif
            });
        }
    }

    // --- Method untuk CRUD Poli ---
    private void addSpecialty() {
        String name = adminPanel.getSpecialtyNameInput().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Nama poli tidak boleh kosong!");
            return;
        }

        MedicalSpecialty newSpecialty = new MedicalSpecialty(name);
        if (specialtyDAO.addSpecialty(newSpecialty)) {
            JOptionPane.showMessageDialog(adminPanel, "Poli berhasil ditambahkan!");
            adminPanel.clearSpecialtyForm();
            loadAllSpecialties();
            loadSpecialtiesToDoctorCombo(); // Refresh combo box dokter
        } else {
            JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan poli.");
        }
    }

    private void updateSpecialty() {
        int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(adminPanel, "Pilih poli dari tabel untuk diupdate.");
            return;
        }

        int id = (int) adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0); // Ambil ID dari tabel
        String name = adminPanel.getSpecialtyNameInput().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Nama poli tidak boleh kosong!");
            return;
        }

        MedicalSpecialty updatedSpecialty = new MedicalSpecialty(id, name);
        if (specialtyDAO.updateSpecialty(updatedSpecialty)) {
            JOptionPane.showMessageDialog(adminPanel, "Poli berhasil diperbarui!");
            adminPanel.clearSpecialtyForm();
            loadAllSpecialties();
            loadSpecialtiesToDoctorCombo(); // Refresh combo box dokter
        } else {
            JOptionPane.showMessageDialog(adminPanel, "Gagal memperbarui poli.");
        }
    }

    private void deleteSpecialty() {
        int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(adminPanel, "Pilih poli dari tabel untuk dihapus.");
            return;
        }

        int id = (int) adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0); // Ambil ID dari tabel
        int confirm = JOptionPane.showConfirmDialog(adminPanel, "Yakin hapus poli dengan ID " + id + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (specialtyDAO.deleteSpecialty(id)) {
                JOptionPane.showMessageDialog(adminPanel, "Poli berhasil dihapus!");
                adminPanel.clearSpecialtyForm();
                loadAllSpecialties();
                loadSpecialtiesToDoctorCombo(); // Refresh combo box dokter
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menghapus poli. Mungkin ada dokter yang terdaftar di poli ini.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadAllSpecialties() {
        DefaultTableModel model = adminPanel.getSpecialtyTableModel();
        model.setRowCount(0);

        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) {
            model.addRow(new Object[]{specialty.getId(), specialty.getName()});
        }
    }

    private void specialtyTableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && adminPanel.getTableSpecialties().getSelectedRow() != -1) {
            int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
            String id = adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0).toString();
            String name = adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 1).toString();

            adminPanel.getTxtSpecialtyName().setText(name);
            adminPanel.getBtnUpdateSpecialty().setEnabled(true);
            adminPanel.getBtnDeleteSpecialty().setEnabled(true);
        } else if (!e.getValueIsAdjusting() && adminPanel.getTableSpecialties().getSelectedRow() == -1){
             adminPanel.getBtnUpdateSpecialty().setEnabled(false);
             adminPanel.getBtnDeleteSpecialty().setEnabled(false);
        }
    }

    // --- Method untuk mengisi combo box di form tambah dokter ---
    private void loadSpecialtiesToDoctorCombo() {
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) {
            model.addElement(specialty); // Tambahkan objek MedicalSpecialty
        }
        adminPanel.getComboDoctorSpecialty().setModel(model);
    }

    // --- Method untuk Tambah Dokter ---
    private void addDoctor() {
        String username = adminPanel.getDoctorUsername().trim();
        String password = adminPanel.getDoctorPassword().trim();
        String fullname = adminPanel.getDoctorFullname().trim();
        MedicalSpecialty selectedSpecialty = adminPanel.getSelectedDoctorSpecialty(); // Ambil objek

        if (username.isEmpty() || password.isEmpty() || fullname.isEmpty() || selectedSpecialty == null) {
            JOptionPane.showMessageDialog(adminPanel, "Semua field untuk tambah dokter harus diisi!");
            return;
        }

        // Pastikan role adalah DOCTOR
        UserRole role = UserRole.DOCTOR;
        // Gunakan constructor yang menerima medical_specialty_id dan isActive
        User newDoctor = new User(username, password, fullname, role, selectedSpecialty.getId(), false); // Default tidak aktif saat dibuat

        if (userDAO.addUser(newDoctor)) {
            JOptionPane.showMessageDialog(adminPanel, "Dokter berhasil ditambahkan!");
            adminPanel.clearAddDoctorForm();
            loadAllUsers(); // Refresh tabel user
        } else {
            JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan dokter. Mungkin username sudah ada.");
        }
    }
}
package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty;
import com.mycompany.aplikasiklinik.model.entity.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import com.toedter.calendar.JDateChooser;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class ReceptionistPanel extends JPanel {

    // --- Komponen Atas: Pemilihan Poli dan Dokter ---
    private final JComboBox<MedicalSpecialty> comboSpecialty = new JComboBox<>();
    private final JComboBox<User> comboActiveDoctor = new JComboBox<>(); 
    private final JButton btnRefreshDoctorList = new JButton("Refresh Dokter");

    // --- Komponen Tengah: Form dan Tabel ---
    // --- Komponen Form Pasien ---
    private final JTextField txtName = new JTextField(15);
    private final JTextField txtNik = new JTextField(15);
    
    // --- BARU: Tombol Cari NIK ---
    private final JButton btnSearchNik = new JButton("Cari");
    // ----------------------------
    
    private final JDateChooser dateChooserDob = new JDateChooser();
    
    // Radio Button Gender
    private final JRadioButton rbMale = new JRadioButton("Laki-laki");
    private final JRadioButton rbFemale = new JRadioButton("Perempuan");
    private final ButtonGroup genderGroup = new ButtonGroup();
    
    private final JTextArea txtAddress = new JTextArea(3, 20); 
    private final JTextField txtPhone = new JTextField(15);
    private final JTextField txtWeight = new JTextField(5);
    private final JTextField txtHeight = new JTextField(5);
    private final JTextField txtBloodPressure = new JTextField(10); 
    private final JButton btnAddToQueue = new JButton("Daftarkan & Masuk Antrian");
    
    // Label ID Pasien (Tersembunyi/Hidden) untuk menyimpan ID jika pasien lama ditemukan
    private final JLabel lblExistingPatientId = new JLabel("0"); 

    // --- Komponen Tabel Antrian ---
    private final JTable tableQueue = new JTable();
    private DefaultTableModel queueTableModel;

    public ReceptionistPanel() {
        setLayout(new BorderLayout());

        // --- PANEL ATAS ---
        JPanel topSelectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); 
        topSelectionPanel.setBorder(BorderFactory.createTitledBorder("Pilih Poli & Dokter"));

        topSelectionPanel.add(new JLabel("Poli:"));
        topSelectionPanel.add(comboSpecialty);
        topSelectionPanel.add(new JLabel("Dokter:"));
        topSelectionPanel.add(comboActiveDoctor);
        topSelectionPanel.add(btnRefreshDoctorList);

        add(topSelectionPanel, BorderLayout.NORTH);

        // --- PANEL TENGAH ---
        JSplitPane centerSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        centerSplitPane.setDividerLocation(0.5); 
        centerSplitPane.setResizeWeight(0.5); 

        // --- PANEL KIRI: Form ---
        JPanel formPanel = new JPanel(new BorderLayout()); 
        formPanel.setBorder(BorderFactory.createTitledBorder("Form Pendaftaran Pasien"));

        JPanel inputFieldsPanel = new JPanel(new GridLayout(0, 2, 5, 5)); 
        inputFieldsPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); 

        // --- Layout Input NIK dengan Tombol Cari ---
        JPanel nikPanel = new JPanel(new BorderLayout(5, 0));
        nikPanel.add(txtNik, BorderLayout.CENTER);
        nikPanel.add(btnSearchNik, BorderLayout.EAST);
        
        inputFieldsPanel.add(new JLabel("NIK/ID:")); inputFieldsPanel.add(nikPanel); // Ganti txtNik dengan nikPanel
        inputFieldsPanel.add(new JLabel("Nama Pasien:")); inputFieldsPanel.add(txtName);
        
        genderGroup.add(rbMale);
        genderGroup.add(rbFemale);
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        genderPanel.add(rbMale);
        genderPanel.add(rbFemale);
        
        inputFieldsPanel.add(new JLabel("Jenis Kelamin:")); inputFieldsPanel.add(genderPanel);
        
        inputFieldsPanel.add(new JLabel("Tanggal Lahir:")); inputFieldsPanel.add(dateChooserDob);
        inputFieldsPanel.add(new JLabel("Alamat:")); inputFieldsPanel.add(new JScrollPane(txtAddress)); 
        inputFieldsPanel.add(new JLabel("No HP:")); inputFieldsPanel.add(txtPhone);
        inputFieldsPanel.add(new JLabel("Berat (kg):")); inputFieldsPanel.add(txtWeight);
        inputFieldsPanel.add(new JLabel("Tinggi (cm):")); inputFieldsPanel.add(txtHeight);
        inputFieldsPanel.add(new JLabel("Tekanan Darah:")); inputFieldsPanel.add(txtBloodPressure);

        // Sembunyikan Label ID (Hanya untuk logic)
        lblExistingPatientId.setVisible(false);
        inputFieldsPanel.add(lblExistingPatientId); 

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); 
        buttonPanel.add(btnAddToQueue);

        formPanel.add(inputFieldsPanel, BorderLayout.CENTER); 
        formPanel.add(buttonPanel, BorderLayout.SOUTH); 

        // --- PANEL KANAN: Tabel ---
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Daftar Antrian"));

        queueTableModel = new DefaultTableModel(new Object[]{"No Antrian", "Nama Pasien", "Dokter", "Status"}, 0);
        tableQueue.setModel(queueTableModel);

        tablePanel.add(new JScrollPane(tableQueue), BorderLayout.CENTER); 

        centerSplitPane.setLeftComponent(formPanel);
        centerSplitPane.setRightComponent(tablePanel);

        add(centerSplitPane, BorderLayout.CENTER);
    }

    // --- Getter ---
    public JComboBox<MedicalSpecialty> getComboSpecialty() { return comboSpecialty; }
    public JComboBox<User> getComboActiveDoctor() { return comboActiveDoctor; }
    public JButton getBtnRefreshDoctorList() { return btnRefreshDoctorList; }
    
    // --- BARU: Getter Tombol Cari ---
    public JButton getBtnSearchNik() { return btnSearchNik; }

    public String getBloodPressure() { return txtBloodPressure.getText(); }
    
    public String getSelectedGender() {
        if (rbMale.isSelected()) return "L";
        if (rbFemale.isSelected()) return "P";
        return null; 
    }
    
    // Setter untuk mengisi form otomatis (Dipakai saat NIK ditemukan)
    public void setGender(String gender) {
        if ("L".equalsIgnoreCase(gender)) rbMale.setSelected(true);
        else if ("P".equalsIgnoreCase(gender)) rbFemale.setSelected(true);
        else genderGroup.clearSelection();
    }

    public String getPatientName() { return txtName.getText(); }
    public String getNik() { return txtNik.getText(); }
    public LocalDate getDob() {
        Date selectedDate = dateChooserDob.getDate();
        if (selectedDate == null) { return null; }
        return selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    public String getAddress() { return txtAddress.getText(); }
    public String getPhone() { return txtPhone.getText(); }
    public String getSelectedDoctorId() {
        User selectedDoctor = (User) comboActiveDoctor.getSelectedItem();
        if (selectedDoctor != null) {
            return String.valueOf(selectedDoctor.getId());
        }
        return null;
    }
    public String getWeight() { return txtWeight.getText(); }
    public String getPatientHeight() { return txtHeight.getText(); }
    public JButton getBtnAddToQueue() { return btnAddToQueue; }

    public DefaultTableModel getQueueModel() { return queueTableModel; }

    public JTextField getTxtName() { return txtName; }
    public JTextField getTxtNik() { return txtNik; }
    public JDateChooser getDateChooserDob() { return dateChooserDob; }
    public JTextArea getTxtAddress() { return txtAddress; }
    public JTextField getTxtPhone() { return txtPhone; }
    public JTextField getTxtWeight() { return txtWeight; }
    public JTextField getTxtHeight() { return txtHeight; }
    public JTextField getTxtBloodPressure() { return txtBloodPressure; }
    
    // Getter/Setter untuk Existing Patient ID
    public int getExistingPatientId() {
        try {
            return Integer.parseInt(lblExistingPatientId.getText());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    public void setExistingPatientId(int id) {
        lblExistingPatientId.setText(String.valueOf(id));
    }

    public void clearForm() {
        txtName.setText("");
        txtNik.setText("");
        genderGroup.clearSelection(); 
        dateChooserDob.setDate(null);
        txtAddress.setText("");
        txtPhone.setText("");
        txtWeight.setText("");
        txtHeight.setText("");
        txtBloodPressure.setText("");
        lblExistingPatientId.setText("0"); // Reset ID pasien lama
        comboActiveDoctor.setSelectedIndex(-1);
    }
}
package com.mycompany.praktikum_4;

public class quiz {
    public static void main(String[] args) {
        String nama = "Nasywa Razhan Deethia";
        int umur = 20;
        System.out.println("Nama saya " + nama);
        System.out.println("Umur saya " + umur);

        enum Warna {
            MERAH, HIJAU, BIRU;
        }
        System.out.println("saya suka warna " + Warna.MERAH +" " + Warna.HIJAU + " " + Warna.BIRU);

        final int maxSks = 24;
        System.out.println("Maksimal sks adalah " + maxSks);
        final int minSks = 24;
        System.out.println("Minimal sks adalah " + minSks);






        }
    }


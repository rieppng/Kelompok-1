package com.mycompany.praktikum_4;

import java.util.Scanner;

public class quiz2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan nama : ");
        String nama = input.next();

        System.out.print("halo " +nama );
        System.out.println(",selamat belajar Java! ");

        System.out.println("Minggu 1 : ");
        int minggu1 = input.nextInt();
        System.out.println("Minggu 2 : ");
        int minggu2 = input.nextInt();
        System.out.println("Minggu 3 : ");
        int minggu3 = input.nextInt();
        System.out.println("Minggu 4 : ");
        int minggu4 = input.nextInt();
        System.out.println("TOTAL KAS : " + (minggu1 + minggu2 + minggu3 + minggu4));

        int totalBelanja = 50000;
        System.out.println("TOTAL BELANJA : Rp "+ totalBelanja);
        int totalBayar = (totalBelanja * 10)/100;
                System.out.println("TOTAL BELANJA Rp "+ (totalBelanja - totalBayar));

        System.out.println("MENGHITUNG BMI ");
        System.out.println("Masukkan tinggi badan: ");
        double tinggiBadan = input.nextInt();

        System.out.println("Masukkan berat badan: ");
        int beratBadan = input.nextInt();

        double i = (beratBadan / (tinggiBadan * tinggiBadan));
        System.out.println("BMI TUBUHMU ADALAH :  " +i);






    }
}

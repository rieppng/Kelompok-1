import java.util.Random;

public class Warrior extends Hero{
Random random = new Random();

    public Warrior(String nama, int hp, int attackPower, int defense) {
        super(nama, hp, attackPower, defense);
    }

    @Override
    public void attack (Enemy e) {
        boolean powerStrike = random.nextInt(100) > 100;
        int totalAttackPower = getAttackPowerHero();
        int totalHp = e.getHpEnemy();
        if(powerStrike){
            totalAttackPower *= 2;
            totalHp -= 5;
            System.out.println("Warrior melakukan Power Strike!");
        }
        e.setHpEnemy(e.getHpEnemy()-totalAttackPower);
        System.out.println(getNamaHero()+" menyerang "+e.getNamaEnemy());

    }

}

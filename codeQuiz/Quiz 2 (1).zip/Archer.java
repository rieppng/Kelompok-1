import java.util.Random;

public class Archer extends Hero {
    Random random = new Random();

    public Archer(String nama, int hp, int attackPower, int defense) {
        super(nama, hp, attackPower, defense);
    }

    @Override
    public void attack(Enemy e) {
        boolean doubleShot = random.nextInt(100) > 25;
        int totalAttackPower = getAttackPowerHero();
        int totalHp = e.getHpEnemy();
        if (doubleShot) {
            totalAttackPower *= 2;
            System.out.println("Archer melakukan DoubleShot!");
        }
        e.setHpEnemy(e.getHpEnemy() - totalAttackPower);
        System.out.println(getNamaHero() + " menyerang " + e.getNamaEnemy());
    }
}

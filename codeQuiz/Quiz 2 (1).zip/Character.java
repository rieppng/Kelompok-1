abstract class Character{
    private String nama;
    private int hp;
    private int attackPower;
    private int defense;

    public Character(String nama, int hp, int attackPower, int defense) {
        this.nama = nama;
        this.hp = hp;
        this.attackPower = attackPower;
        this.defense = defense;
    }
    public String getNamaHero(){
        return this.nama;
    }
    public void setNamaHero(String nama){
        this.nama =nama;
    }
    public int getHpHero(){
        return this.hp;
    }
    public void setHpHero(int hp){
        this.hp =hp;
    }
    public int getAttackPowerHero(){
        return this.attackPower;
    }
    public void setAttackPowerHero(){
        this.attackPower = attackPower;
    }
    public int getDefenseHero(){
        return this.defense;
    }
    public void setDefenseHero(){
        this.defense=defense;
    }

    public String getNamaEnemy(){
        return nama;
    }
    public void setNamaEnemy(){
        this.nama=nama;
    }
    public int getHpEnemy(){
        return this.hp;
    }
    public void setHpEnemy(int hp){
        this.hp = 100;
    }
    public int getAttackPowerEnemy(){
        return this.attackPower;
    }
    public void setAttackPowerEnemy(){
        this.attackPower = attackPower;
    }
    public int getDefenseEnemy(){
        return this.defense;
    }
    public void setDefenseEnemy(){
        this.defense = defense;
    }

}

public class Enemy extends Character {

    public Enemy(String nama, int hp, int attackPower, int defense) {
        super(nama, hp, attackPower, defense);
    }

    public void attack(Hero h) {
        h.setHpEnemy(h.getHpEnemy() - getAttackPowerEnemy());
        System.out.println(getNamaHero() + " menyerang " + h.getNamaEnemy() +
                " dengan attackpower " + getAttackPowerHero());
    }
    public boolean isAlive(){
        return getHpEnemy() >0;
    }
}

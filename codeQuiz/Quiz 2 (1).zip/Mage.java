import java.util.Random;

public class Mage extends Hero {
    Random random = new Random();

    public Mage(String nama, int hp, int attackPower, int defense) {
        super(nama, hp, attackPower, defense);
    }

    @Override
    public void attack(Enemy e) {
        boolean fireball = random.nextInt(100) > 70;
        int totalAttackPower = getAttackPowerHero();
        int totalHp = getHpHero();
        if (fireball) {
            System.out.println("Mage melakukan Fireball!");
        } else {
            System.out.println("Mage gagal melakukan Fireball!");
        }
        e.setHpEnemy(e.getHpEnemy() - totalAttackPower);
        System.out.println(getNamaHero() + " menyerang " + e.getNamaEnemy());
    }
}
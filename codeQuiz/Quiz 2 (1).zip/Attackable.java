public interface Attackable {
    int takeDamage();
    int attack();
}

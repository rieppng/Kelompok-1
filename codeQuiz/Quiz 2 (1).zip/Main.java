import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Warrior warrior = new Warrior("warrior", 100, 50, 25);
        Mage mage = new Mage("mage", 100, 75, 50);
        Archer archer = new Archer("archer", 100, 25, 75);
        Enemy enemy1 = new Enemy("Goblin", 100, 45, 50);
        Enemy enemy2 = new Enemy("Orc", 100, 25, 75);
        Enemy enemy3 = new Enemy("Dragon", 100, 75, 25);
        Scanner input = new Scanner(System.in);
        char opsi, opsiCase;

        do {
            System.out.println("===WELCOME===");
            System.out.println("1. Warrior");
            System.out.println("2. Mage");
            System.out.println("3. Archer");
            System.out.println("______________________________________");
            System.out.print("Choose your Hero: ");
            opsi = input.next().charAt(0);
            switch (opsi) {
                case '1':
                    System.out.println("=== PERTARUNGAN DIMULAI ===");
                    warrior.attack(enemy1);
                    while (enemy1.isAlive() && warrior.isAlive()) {
                        if (!enemy1.isAlive()) {
                            System.out.println(enemy1.getNamaEnemy() + " telah kalah!");
                            break;
                        }
                        enemy1.attack(warrior);
                        if (!warrior.isAlive()) {
                            System.out.println(warrior.getNamaHero() + " telah kalah!");
                            break;
                        }
                        System.out.println("=== PERTARUNGAN BERAKHIR ===");
                        if (enemy1.isAlive()) {
                            System.out.println("PEMENANG: " + enemy1.getNamaEnemy());
                            System.out.println("KALAH: " + warrior.getNamaHero());
                        } else {
                            System.out.println("PEMENANG: " + enemy1.getNamaEnemy());
                            System.out.println("KALAH: " + warrior.getNamaHero());

                        }
                    }

            }

        }while (opsi != '3') ;
    }
}
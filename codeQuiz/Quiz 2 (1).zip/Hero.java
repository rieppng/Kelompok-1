public class Hero extends Character {

    public Hero(String nama, int hp, int attackPower, int defense){
        super(nama,hp,attackPower,defense);
    }
    public void attack (Enemy e){
        e.setHpEnemy(e.getHpEnemy()-getAttackPowerHero());
        System.out.println(getNamaHero()+" menyerang "+e.getNamaEnemy()+
                " dengan attackpower " + getAttackPowerHero());

    }
    public boolean isAlive(){
        return getHpHero() >0;
    }
}

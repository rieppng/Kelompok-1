import java.util.ArrayList;

public class DemoHRD {
    public static void main(String[] args) {
        Karyawan [] karyawan = new Karyawan[2];
        KaryawanKontrak karyawan1= new KaryawanKontrak("Nasywa","1234",20000, 30 );
        KaryawanTetap karyawan2 = new KaryawanTetap("Razhan", "1234",3000000 );

        ArrayList<IDapatGaji> karyawanList = new ArrayList();
        karyawanList.add(karyawan1);
        karyawanList.add(karyawan2);

        for(IDapatGaji info : karyawanList) {
            info.tampilkanSlipGaji();
        }
    }
}

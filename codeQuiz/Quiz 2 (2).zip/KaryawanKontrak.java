public class KaryawanKontrak extends Karyawan implements IDapatGaji{
    private double upahHarian;
    private int jumlahHariMasuk;

    public KaryawanKontrak(String nama, String nip, double upahHarian, int jumlahHariMasuk) {
        super(nama,nip);
        this.upahHarian = upahHarian;
        this.jumlahHariMasuk = jumlahHariMasuk;
    }
    public double getUpahHarian() {
        return upahHarian;
    }
    public void setUpahHarian(double upahHarian) {
        this.upahHarian = upahHarian;
    }
    public int getJumlahHariMasuk() {
        return jumlahHariMasuk;
    }
    public void setJumlahHariMasuk(int jumlahHariMasuk) {
        this.jumlahHariMasuk = jumlahHariMasuk;
    }
    @Override
    public void tampilkanSlipGaji(){
        System.out.println("INFO KARYAWAN");
        System.out.println("Nama : "+getNama());
        System.out.println("NIP : "+getnip());
        System.out.println("Status : Karyawan Kontrak");
        System.out.println("Total Gaji : "+getUpahHarian()*jumlahHariMasuk);
    }
}

public interface IDapatGaji {
    abstract public void tampilkanSlipGaji();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// File: com/mycompany/aplikasiklinik/controller/LoginController.java (FIX: Reset status nyangkut saat login)
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.LoginView;
import com.mycompany.aplikasiklinik.view.MainDashboard;

import javax.swing.JOptionPane;

public class LoginController {
    private final LoginView view;
    private final UserDAO userDAO;

    public LoginController(LoginView view) {
        this.view = view;
        this.userDAO = new UserDAO();
        this.view.getBtnLogin().addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = view.getUsernameInput();
        String password = view.getPasswordInput();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Username dan Password tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = userDAO.login(username, password);

        if (user != null) {
            SessionManager.getInstance().setCurrentUser(user);

            if (user.getRole() == UserRole.DOCTOR) {
                // 1. Update status aktif di database saat login
                boolean statusUpdated = userDAO.updateUserActiveStatus(user.getId(), true); 
                if (!statusUpdated) {
                    JOptionPane.showMessageDialog(view, "Gagal memperbarui status login.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; 
                }
                
                // --- PERBAIKAN PENTING: RESET STATUS PASIEN NYANGKUT SAAT LOGIN ---
                // Jika aplikasi sebelumnya crash/closed paksa saat 'IN_CONSULTATION',
                // pasien akan terjebak. Kita reset kembali ke 'WAITING' saat dokter login ulang.
                AppointmentDAO appDAO = new AppointmentDAO();
                appDAO.resetDoctorConsultationStatus(user.getId());
                // ------------------------------------------------------------------
            }

            view.dispose();
            MainDashboard dashboard = new MainDashboard();

            // Logika Logout
            dashboard.getBtnLogout().addActionListener(e -> {
                User currentUser = SessionManager.getInstance().getCurrentUser();

                if (currentUser != null && currentUser.getRole() == UserRole.DOCTOR) {
                    // Set tidak aktif saat logout normal
                    userDAO.updateUserActiveStatus(currentUser.getId(), false); 
                    
                    // Reset status pasien jika logout saat sedang memeriksa
                    AppointmentDAO appointmentDAO = new AppointmentDAO();
                    appointmentDAO.resetDoctorConsultationStatus(currentUser.getId());
                }

                SessionManager.getInstance().setCurrentUser(null);
                dashboard.dispose();

                LoginView newLoginView = new LoginView();
                new LoginController(newLoginView);
                newLoginView.setVisible(true);
            });

            // Inisialisasi Controller
            new AdminController(dashboard, dashboard.getAdminPanel(), userDAO);
            new ReceptionistController(dashboard.getReceptionistPanel());
            new InventoryController(dashboard.getInventoryPanel());

            if ("DOCTOR".equals(user.getRole().name())) {
                new DoctorController(dashboard.getDoctorPanel(), userDAO, user.getId()); 
            }

            new CashierController(dashboard.getCashierPanel());
            
            dashboard.setVisible(true);
            dashboard.showPanel(user.getRole().name());
        } else {
            JOptionPane.showMessageDialog(view, "Username atau Password salah!", "Login Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }
}
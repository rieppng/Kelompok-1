package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;

public class InventoryPanel extends JPanel {
    private final JTextField txtMedName = new JTextField();
    private final JComboBox<String> comboCategory = new JComboBox<>(new String[]{"Tablet", "Sirup", "Kapsul", "Salep", "Injeksi"});
    private final JSpinner spinStock = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
    private final JTextField txtPrice = new JTextField();
    
    private final JButton btnAddMed = new JButton("Tambah Obat");
    private final JButton btnUpdateMed = new JButton("Update Obat");
    private final JButton btnDeleteMed = new JButton("Hapus Obat");
    private final JButton btnProcessPrescription = new JButton("Proses Resep Masuk");

    private final JTable tableInventory = new JTable();
    private DefaultTableModel inventoryModel;
    
    private final JTable tableIncomingPrescription = new JTable();
    private DefaultTableModel incomingPrescriptionModel;
    
    public InventoryPanel() {
        setLayout(new BorderLayout());
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setResizeWeight(0.5); 
        
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Form Data Obat"));
        inputPanel.add(new JLabel("Nama Obat:")); inputPanel.add(txtMedName);
        inputPanel.add(new JLabel("Kategori:")); inputPanel.add(comboCategory);
        inputPanel.add(new JLabel("Stok:")); inputPanel.add(spinStock);
        inputPanel.add(new JLabel("Harga:")); inputPanel.add(txtPrice);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnAddMed); buttonPanel.add(btnUpdateMed); buttonPanel.add(btnDeleteMed);
        inputPanel.add(new JLabel("Aksi:")); inputPanel.add(buttonPanel); 
        
        topPanel.add(inputPanel, BorderLayout.NORTH);
        
        JPanel inventoryTablePanel = new JPanel(new BorderLayout());
        inventoryTablePanel.setBorder(BorderFactory.createTitledBorder("Daftar Inventaris Obat"));
        
        inventoryModel = new DefaultTableModel(new Object[]{"ID", "Nama", "Kategori", "Stok", "Harga"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tableInventory.setModel(inventoryModel);
        tableInventory.getTableHeader().setReorderingAllowed(false);
        
        // SET LEBAR KOLOM INVENTARIS
        TableColumnModel cmInv = tableInventory.getColumnModel();
        cmInv.getColumn(0).setPreferredWidth(30); // ID
        cmInv.getColumn(0).setMaxWidth(50);
        cmInv.getColumn(1).setPreferredWidth(200); // Nama
        cmInv.getColumn(2).setPreferredWidth(100); // Kategori
        cmInv.getColumn(3).setPreferredWidth(50); // Stok
        cmInv.getColumn(4).setPreferredWidth(80); // Harga
        
        inventoryTablePanel.add(new JScrollPane(tableInventory), BorderLayout.CENTER); 
        topPanel.add(inventoryTablePanel, BorderLayout.CENTER);
        
        JPanel incomingPrescriptionPanel = new JPanel(new BorderLayout());
        incomingPrescriptionPanel.setBorder(BorderFactory.createTitledBorder("Antrian Resep Masuk (Menunggu Proses)"));
        
        incomingPrescriptionModel = new DefaultTableModel(new Object[]{"ID Item", "Nama Obat", "Jumlah", "Aturan Pakai", "Nama Pasien", "ID Rekam Medis"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tableIncomingPrescription.setModel(incomingPrescriptionModel);
        tableIncomingPrescription.getTableHeader().setReorderingAllowed(false);
        
        // SET LEBAR KOLOM RESEP MASUK
        TableColumnModel cmInc = tableIncomingPrescription.getColumnModel();
        cmInc.getColumn(0).setPreferredWidth(50); // ID Item
        cmInc.getColumn(1).setPreferredWidth(150); // Nama Obat
        cmInc.getColumn(2).setPreferredWidth(50); // Jumlah
        cmInc.getColumn(3).setPreferredWidth(200); // Aturan Pakai
        cmInc.getColumn(4).setPreferredWidth(150); // Nama Pasien
        
        // Hide Column ID Rekam Medis (Optional) or make it very small
        cmInc.getColumn(5).setPreferredWidth(0); 
        cmInc.getColumn(5).setMinWidth(0);
        cmInc.getColumn(5).setMaxWidth(0);
        
        incomingPrescriptionPanel.add(new JScrollPane(tableIncomingPrescription), BorderLayout.CENTER);
        
        JPanel bottomButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomButtonPanel.add(btnProcessPrescription);
        incomingPrescriptionPanel.add(bottomButtonPanel, BorderLayout.SOUTH);
        
        splitPane.setTopComponent(topPanel);
        splitPane.setBottomComponent(incomingPrescriptionPanel);
        add(splitPane, BorderLayout.CENTER);

        btnUpdateMed.setEnabled(false); btnDeleteMed.setEnabled(false);
    }

    // Getters
    public String getMedName() { return txtMedName.getText(); }
    public String getCategory() { return (String) comboCategory.getSelectedItem(); }
    public int getStock() { return (int) spinStock.getValue(); }
    public String getPrice() { return txtPrice.getText(); }
    public JTextField getTxtMedName() { return txtMedName; }
    public JComboBox<String> getComboCategory() { return comboCategory; }
    public JSpinner getSpinStock() { return spinStock; }
    public JTextField getTxtPrice() { return txtPrice; }
    public JButton getBtnAddMed() { return btnAddMed; }
    public JButton getBtnUpdateMed() { return btnUpdateMed; }
    public JButton getBtnDeleteMed() { return btnDeleteMed; }
    public JButton getBtnProcessPrescription() { return btnProcessPrescription; }
    public JTable getTableInventory() { return tableInventory; }
    public DefaultTableModel getInventoryModel() { return inventoryModel; }
    public JTable getTableIncomingPrescription() { return tableIncomingPrescription; }
    public DefaultTableModel getIncomingPrescriptionModel() { return incomingPrescriptionModel; }
    public void clearForm() {
        txtMedName.setText(""); comboCategory.setSelectedIndex(0);
        spinStock.setValue(0); txtPrice.setText("");
        tableInventory.clearSelection(); btnUpdateMed.setEnabled(false); btnDeleteMed.setEnabled(false);
    }
}
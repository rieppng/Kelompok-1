/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalSpecialtyDAO;
import com.mycompany.aplikasiklinik.model.dao.ServiceFeeDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalRecordDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty;
import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecordHistory;
import com.mycompany.aplikasiklinik.view.AdminPanel;
import com.mycompany.aplikasiklinik.view.MainDashboard;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Font;

public class AdminController {
    private MainDashboard dashboard;
    private AdminPanel adminPanel;
    private UserDAO userDAO;
    private MedicalSpecialtyDAO specialtyDAO;
    private ServiceFeeDAO serviceFeeDAO;
    private MedicalRecordDAO medicalRecordDAO;

    public AdminController(MainDashboard dashboard, AdminPanel adminPanel, UserDAO userDAO) {
        this.dashboard = dashboard;
        this.adminPanel = adminPanel;
        this.userDAO = userDAO;
        this.specialtyDAO = new MedicalSpecialtyDAO();
        this.serviceFeeDAO = new ServiceFeeDAO();
        this.medicalRecordDAO = new MedicalRecordDAO();

        // --- LOAD DATA AWAL ---
        loadAllUsers();
        loadAllSpecialties();
        loadAllServiceFees(); 
        loadSpecialtiesToDoctorCombo();
        loadSpecialtiesToUpdateDoctorCombo();
        loadMedicalRecordHistory(); 

        // --- EVENT LISTENER: MANAJEMEN STAFF ---
        this.adminPanel.getBtnAddUser().addActionListener(e -> addUser());

        // --- EVENT LISTENER: MANAJEMEN POLI ---
        this.adminPanel.getBtnAddSpecialty().addActionListener(e -> addSpecialty());
        this.adminPanel.getBtnUpdateSpecialty().addActionListener(e -> updateSpecialty());
        this.adminPanel.getBtnDeleteSpecialty().addActionListener(e -> deleteSpecialty());
        this.adminPanel.getTableSpecialties().getSelectionModel().addListSelectionListener(this::specialtyTableSelectionChanged);

        // --- EVENT LISTENER: BIAYA LAYANAN ---
        this.adminPanel.getBtnAddFee().addActionListener(e -> addServiceFee());
        this.adminPanel.getBtnUpdateFee().addActionListener(e -> updateServiceFee());
        this.adminPanel.getBtnDeleteFee().addActionListener(e -> deleteServiceFee());
        this.adminPanel.getTableServiceFees().getSelectionModel().addListSelectionListener(this::serviceFeeTableSelectionChanged);

        // --- EVENT LISTENER: DOKTER ---
        this.adminPanel.getBtnAddDoctor().addActionListener(e -> addDoctor());
        this.adminPanel.getBtnSearchDoctor().addActionListener(e -> searchDoctorToUpdate());
        this.adminPanel.getBtnUpdateDoctor().addActionListener(e -> updateDoctor());
        
        // --- EVENT LISTENER: RIWAYAT MEDIS ---
        this.adminPanel.getBtnRefreshMedicalRecords().addActionListener(e -> loadMedicalRecordHistory());
        this.adminPanel.getBtnDetailMedicalRecord().addActionListener(e -> showMedicalRecordDetail());
    }

    // ========================================================================
    // 1. LOGIKA MANAJEMEN STAFF
    // ========================================================================
    private void addUser() {
        try {
            String username = adminPanel.getUsername();
            String password = adminPanel.getPassword();
            String fullname = adminPanel.getFullname();
            String roleName = adminPanel.getSelectedRole();

            if (username.isEmpty() || password.isEmpty() || fullname.isEmpty()) {
                JOptionPane.showMessageDialog(adminPanel, "Semua field harus diisi!");
                return;
            }

            if (roleName.equals("SUPERADMIN")) {
                JOptionPane.showMessageDialog(adminPanel, "Role SUPERADMIN tidak dapat ditambahkan melalui menu ini!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UserRole role = UserRole.valueOf(roleName);
            User newUser = new User(username, password, fullname, role, 0, false, 0.0);

            if (userDAO.addUser(newUser)) {
                JOptionPane.showMessageDialog(adminPanel, "User berhasil ditambahkan!");
                adminPanel.clearForm();
                loadAllUsers();
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan user. Mungkin username sudah ada.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(adminPanel, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadAllUsers() {
        DefaultTableModel model = adminPanel.getUserTableModel();
        model.setRowCount(0);
        List<User> users = userDAO.getAllUsers();
        for (User user : users) {
            model.addRow(new Object[]{
                user.getId(), 
                user.getUsername(), 
                user.getFullName(),
                user.getRole().toString(), 
                user.isActive() ? "Ya" : "Tidak", 
                user.getConsultationFee()
            });
        }
    }

    // ========================================================================
    // 2. LOGIKA MANAJEMEN POLI
    // ========================================================================
    private void addSpecialty() {
        String name = adminPanel.getSpecialtyNameInput().trim();
        if (name.isEmpty()) { JOptionPane.showMessageDialog(adminPanel, "Nama poli tidak boleh kosong!"); return; }
        MedicalSpecialty newSpecialty = new MedicalSpecialty(name);
        if (specialtyDAO.addSpecialty(newSpecialty)) {
            JOptionPane.showMessageDialog(adminPanel, "Poli berhasil ditambahkan!");
            adminPanel.clearSpecialtyForm();
            loadAllSpecialties();
            loadSpecialtiesToDoctorCombo();
            loadSpecialtiesToUpdateDoctorCombo();
        } else { JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan poli."); }
    }

    private void updateSpecialty() {
        int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
        if (selectedRow == -1) return;
        int id = (int) adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0);
        String name = adminPanel.getSpecialtyNameInput().trim();
        if (name.isEmpty()) { JOptionPane.showMessageDialog(adminPanel, "Nama poli tidak boleh kosong!"); return; }
        
        MedicalSpecialty updatedSpecialty = new MedicalSpecialty(id, name);
        if (specialtyDAO.updateSpecialty(updatedSpecialty)) {
            JOptionPane.showMessageDialog(adminPanel, "Poli berhasil diperbarui!");
            adminPanel.clearSpecialtyForm();
            loadAllSpecialties();
            loadSpecialtiesToDoctorCombo();
            loadSpecialtiesToUpdateDoctorCombo();
        } else { JOptionPane.showMessageDialog(adminPanel, "Gagal memperbarui poli."); }
    }

    private void deleteSpecialty() {
        int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
        if (selectedRow == -1) return;
        int id = (int) adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(adminPanel, "Yakin hapus poli ini?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (specialtyDAO.deleteSpecialty(id)) {
                JOptionPane.showMessageDialog(adminPanel, "Poli berhasil dihapus!");
                adminPanel.clearSpecialtyForm();
                loadAllSpecialties();
                loadSpecialtiesToDoctorCombo();
                loadSpecialtiesToUpdateDoctorCombo();
            } else { JOptionPane.showMessageDialog(adminPanel, "Gagal menghapus poli. Mungkin sedang digunakan oleh dokter."); }
        }
    }

    private void loadAllSpecialties() {
        DefaultTableModel model = adminPanel.getSpecialtyTableModel();
        model.setRowCount(0);
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) { model.addRow(new Object[]{specialty.getId(), specialty.getName()}); }
    }

    private void specialtyTableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && adminPanel.getTableSpecialties().getSelectedRow() != -1) {
            int selectedRow = adminPanel.getTableSpecialties().getSelectedRow();
            String name = adminPanel.getSpecialtyTableModel().getValueAt(selectedRow, 1).toString();
            adminPanel.getTxtSpecialtyName().setText(name);
            adminPanel.getBtnUpdateSpecialty().setEnabled(true);
            adminPanel.getBtnDeleteSpecialty().setEnabled(true);
        } else if (!e.getValueIsAdjusting() && adminPanel.getTableSpecialties().getSelectedRow() == -1){
             adminPanel.getBtnUpdateSpecialty().setEnabled(false);
             adminPanel.getBtnDeleteSpecialty().setEnabled(false);
        }
    }

    // ========================================================================
    // 3. LOGIKA BIAYA LAYANAN
    // ========================================================================
    private void addServiceFee() {
        String name = adminPanel.getFeeNameInput().trim();
        String priceStr = adminPanel.getFeePriceInput().trim();
        if (name.isEmpty() || priceStr.isEmpty()) { JOptionPane.showMessageDialog(adminPanel, "Nama dan Harga harus diisi!"); return; }
        try {
            double price = Double.parseDouble(priceStr);
            if (price < 0) { JOptionPane.showMessageDialog(adminPanel, "Harga tidak boleh negatif!"); return; }
            ServiceFee newFee = new ServiceFee(0, name, price);
            if (serviceFeeDAO.addServiceFee(newFee)) {
                JOptionPane.showMessageDialog(adminPanel, "Layanan berhasil ditambahkan!");
                adminPanel.clearFeeForm(); loadAllServiceFees();
            } else { JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan layanan."); }
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(adminPanel, "Harga harus berupa angka valid!"); }
    }

    private void updateServiceFee() {
        int selectedRow = adminPanel.getTableServiceFees().getSelectedRow();
        if (selectedRow == -1) return;
        int id = (int) adminPanel.getFeeTableModel().getValueAt(selectedRow, 0);
        String name = adminPanel.getFeeNameInput().trim();
        String priceStr = adminPanel.getFeePriceInput().trim();
        if (name.isEmpty() || priceStr.isEmpty()) { JOptionPane.showMessageDialog(adminPanel, "Nama dan Harga harus diisi!"); return; }
        try {
            double price = Double.parseDouble(priceStr);
            ServiceFee updatedFee = new ServiceFee(id, name, price);
            if (serviceFeeDAO.updateServiceFee(updatedFee)) {
                JOptionPane.showMessageDialog(adminPanel, "Layanan berhasil diperbarui!");
                adminPanel.clearFeeForm(); loadAllServiceFees();
            } else { JOptionPane.showMessageDialog(adminPanel, "Gagal memperbarui layanan."); }
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(adminPanel, "Harga harus berupa angka valid!"); }
    }

    private void deleteServiceFee() {
        int selectedRow = adminPanel.getTableServiceFees().getSelectedRow();
        if (selectedRow == -1) return;
        int id = (int) adminPanel.getFeeTableModel().getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(adminPanel, "Yakin hapus layanan ini?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (serviceFeeDAO.deleteServiceFee(id)) {
                JOptionPane.showMessageDialog(adminPanel, "Layanan berhasil dihapus!");
                adminPanel.clearFeeForm(); loadAllServiceFees();
            } else { JOptionPane.showMessageDialog(adminPanel, "Gagal menghapus layanan."); }
        }
    }

    private void loadAllServiceFees() {
        DefaultTableModel model = adminPanel.getFeeTableModel();
        model.setRowCount(0);
        List<ServiceFee> fees = serviceFeeDAO.getAllServiceFees();
        for (ServiceFee fee : fees) { model.addRow(new Object[]{fee.getId(), fee.getName(), fee.getPrice()}); }
    }

    private void serviceFeeTableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && adminPanel.getTableServiceFees().getSelectedRow() != -1) {
            int selectedRow = adminPanel.getTableServiceFees().getSelectedRow();
            String name = adminPanel.getFeeTableModel().getValueAt(selectedRow, 1).toString();
            String price = adminPanel.getFeeTableModel().getValueAt(selectedRow, 2).toString();
            adminPanel.getTxtFeeName().setText(name);
            adminPanel.getTxtFeePrice().setText(price);
            adminPanel.getBtnUpdateFee().setEnabled(true);
            adminPanel.getBtnDeleteFee().setEnabled(true);
        } else if (!e.getValueIsAdjusting() && adminPanel.getTableServiceFees().getSelectedRow() == -1){
             adminPanel.getBtnUpdateFee().setEnabled(false);
             adminPanel.getBtnDeleteFee().setEnabled(false);
        }
    }

    // ========================================================================
    // 4. LOGIKA MANAJEMEN DOKTER
    // ========================================================================
    private void loadSpecialtiesToDoctorCombo() {
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) { model.addElement(specialty); }
        adminPanel.getComboDoctorSpecialty().setModel(model);
    }
    
    private void loadSpecialtiesToUpdateDoctorCombo() {
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        for (MedicalSpecialty specialty : specialties) { model.addElement(specialty); }
        adminPanel.getComboUpdateSpecialty().setModel(model);
    }
    
    private void addDoctor() {
        String username = adminPanel.getDoctorUsername().trim();
        String password = adminPanel.getDoctorPassword().trim();
        String fullname = adminPanel.getDoctorFullname().trim();
        MedicalSpecialty selectedSpecialty = adminPanel.getSelectedDoctorSpecialty();
        String consultationFeeStr = adminPanel.getDoctorConsultationFee().trim();

        if (username.isEmpty() || password.isEmpty() || fullname.isEmpty() || selectedSpecialty == null || consultationFeeStr.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Semua field untuk tambah dokter harus diisi!");
            return;
        }

        try {
            double consultationFee = Double.parseDouble(consultationFeeStr);
            if (consultationFee < 0) { JOptionPane.showMessageDialog(adminPanel, "Biaya jasa tidak boleh negatif!"); return; }

            User newDoctor = new User(username, password, fullname, UserRole.DOCTOR, selectedSpecialty.getId(), false, consultationFee);

            if (userDAO.addUser(newDoctor)) {
                JOptionPane.showMessageDialog(adminPanel, "Dokter berhasil ditambahkan!");
                adminPanel.clearAddDoctorForm();
                loadAllUsers();
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan dokter. Username mungkin sudah ada.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(adminPanel, "Biaya jasa harus angka valid!");
        }
    }
    
    private void searchDoctorToUpdate() {
        String usernameToSearch = adminPanel.getSearchDoctorId().trim(); 
        if (usernameToSearch.isEmpty()) { 
            JOptionPane.showMessageDialog(adminPanel, "Masukkan Username dokter!"); 
            return; 
        }

        User doctor = userDAO.getUserByUsername(usernameToSearch);

        if (doctor != null && doctor.getRole() == UserRole.DOCTOR) {
            adminPanel.getTxtUpdateUsername().setText(doctor.getUsername());
            adminPanel.getTxtUpdateFullname().setText(doctor.getFullName());
            
            MedicalSpecialty specialty = specialtyDAO.getSpecialtyById(doctor.getMedicalSpecialtyId());
            if (specialty != null) { adminPanel.getComboUpdateSpecialty().setSelectedItem(specialty); }
            else { adminPanel.getComboUpdateSpecialty().setSelectedIndex(-1); }
            
            adminPanel.getTxtUpdateConsultationFee().setText(String.valueOf(doctor.getConsultationFee()));
        } else {
            JOptionPane.showMessageDialog(adminPanel, "Dokter dengan username tersebut tidak ditemukan.", "Info", JOptionPane.INFORMATION_MESSAGE);
            adminPanel.clearUpdateDoctorForm();
        }
    }
    
    private void updateDoctor() {
        String searchKeyUsername = adminPanel.getSearchDoctorId().trim();
        String newUsername = adminPanel.getTxtUpdateUsername().getText().trim();
        String newFullname = adminPanel.getTxtUpdateFullname().getText().trim();
        MedicalSpecialty selectedSpecialty = (MedicalSpecialty) adminPanel.getComboUpdateSpecialty().getSelectedItem();
        String consultationFeeStr = adminPanel.getTxtUpdateConsultationFee().getText().trim();

        if (searchKeyUsername.isEmpty() || newUsername.isEmpty() || newFullname.isEmpty() || selectedSpecialty == null || consultationFeeStr.isEmpty()) {
            JOptionPane.showMessageDialog(adminPanel, "Data belum lengkap! Pastikan sudah mencari dokter terlebih dahulu."); 
            return;
        }

        try {
            User originalDoctor = userDAO.getUserByUsername(searchKeyUsername);
            if (originalDoctor == null) { 
                JOptionPane.showMessageDialog(adminPanel, "Dokter asal tidak ditemukan! Silakan cari ulang."); 
                return; 
            }
            
            double consultationFee = Double.parseDouble(consultationFeeStr);
            if (consultationFee < 0) { JOptionPane.showMessageDialog(adminPanel, "Biaya jasa tidak boleh negatif!"); return; }

            User updatedDoctor = new User(
                originalDoctor.getId(), 
                newUsername, 
                "", 
                newFullname, 
                UserRole.DOCTOR, 
                selectedSpecialty.getId(), 
                false, 
                consultationFee
            );

            if (userDAO.updateUser(updatedDoctor)) {
                JOptionPane.showMessageDialog(adminPanel, "Data dokter berhasil diperbarui!");
                adminPanel.clearUpdateDoctorForm();
                loadAllUsers(); 
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal memperbarui data dokter.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(adminPanel, "Biaya jasa harus angka!");
        }
    }

    // ========================================================================
    // 5. LOGIKA RIWAYAT MEDIS (MEDICAL RECORD HISTORY)
    // ========================================================================
    private void loadMedicalRecordHistory() {
        DefaultTableModel model = adminPanel.getMedicalRecordTableModel();
        model.setRowCount(0); // Kosongkan tabel
        
        List<MedicalRecordHistory> historyList = medicalRecordDAO.getAllHistory();
        
        for (MedicalRecordHistory rec : historyList) {
            model.addRow(new Object[]{
                rec.getId(),
                rec.getDate().toString(),
                rec.getPatientName(),
                rec.getDoctorName(),
                rec.getPoliName(),
                rec.getDiagnosis(),
                rec.getTreatment()
            });
        }
    }

    private void showMedicalRecordDetail() {
        int selectedRow = adminPanel.getTableMedicalRecords().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(adminPanel, "Pilih baris rekam medis terlebih dahulu.");
            return;
        }

        DefaultTableModel model = adminPanel.getMedicalRecordTableModel();
        int medicalRecordId = (int) model.getValueAt(selectedRow, 0); 
        String date = (String) model.getValueAt(selectedRow, 1);
        String patientName = (String) model.getValueAt(selectedRow, 2);
        String doctorName = (String) model.getValueAt(selectedRow, 3);
        String diagnosis = (String) model.getValueAt(selectedRow, 5);
        String treatment = (String) model.getValueAt(selectedRow, 6);

        int appointmentId = medicalRecordDAO.getAppointmentIdByMedicalRecord(medicalRecordId);
        String prescriptionList = medicalRecordDAO.getPrescriptionDetails(medicalRecordId);
        String serviceList = medicalRecordDAO.getServiceDetails(appointmentId);
        String vitalSigns = medicalRecordDAO.getPatientVitals(appointmentId);

        JTextArea txtDetail = new JTextArea(20, 50);
        txtDetail.setEditable(false);
        txtDetail.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        StringBuilder sb = new StringBuilder();
        sb.append("===== DETAIL REKAM MEDIS =====\n");
        sb.append("ID RM      : ").append(medicalRecordId).append("\n");
        sb.append("Tanggal    : ").append(date).append("\n");
        sb.append("Pasien     : ").append(patientName).append("\n");
        sb.append("Dokter     : ").append(doctorName).append("\n");
        sb.append("------------------------------\n");
        sb.append("DATA FISIK :\n").append(vitalSigns).append("\n");
        sb.append("------------------------------\n");
        sb.append("DIAGNOSA   :\n").append(diagnosis).append("\n\n");
        sb.append("TINDAKAN   :\n").append(treatment).append("\n");
        sb.append("------------------------------\n");
        sb.append("RESEP OBAT :\n").append(prescriptionList).append("\n");
        sb.append("LAYANAN LAIN:\n").append(serviceList).append("\n");
        
        txtDetail.setText(sb.toString());
        txtDetail.setCaretPosition(0); 

        JOptionPane.showMessageDialog(adminPanel, new JScrollPane(txtDetail), 
                "Detail Rekam Medis - " + patientName, JOptionPane.PLAIN_MESSAGE);
    }
}
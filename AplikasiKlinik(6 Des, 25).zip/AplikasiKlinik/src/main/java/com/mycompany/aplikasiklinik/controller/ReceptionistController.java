/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.view.ReceptionistPanel;

import java.time.LocalDate;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.DefaultListCellRenderer;
import java.awt.Component;

/**
 *
 * @author LENOVO
 */
public class ReceptionistController {
    private final ReceptionistPanel receptionistPanel;
    private final UserDAO userDAO;
    private final PatientDAO patientDAO;
    private final AppointmentDAO appointmentDAO;

    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 6000; // Refresh setiap 6 detik

    public ReceptionistController(ReceptionistPanel receptionistPanel) {
        this.receptionistPanel = receptionistPanel;
        this.userDAO = new UserDAO();
        this.patientDAO = new PatientDAO();
        this.appointmentDAO = new AppointmentDAO();
        
        loadDoctorList(); 
        loadQueueList(); // Panggil saat inisialisasi untuk mengisi tabel
        
        receptionistPanel.getBtnAddToQueue().addActionListener(e -> handleAddToQueue());
        startAutoRefresh();
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> {
            loadQueueList(); 
        });
        refreshTimer.start();
    }
    
    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    private void loadDoctorList() {
        List<User> doctors = userDAO.getDoctors();
        DefaultComboBoxModel<User> model = new DefaultComboBoxModel<>();
        for (User doctor : doctors) {
            model.addElement(doctor);
        }
        receptionistPanel.getComboDoctor().setModel(model);

        // Kita atur "Renderer" (Cara tampilan) dari ComboBox ini
        receptionistPanel.getComboDoctor().setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                // Panggil method aslinya dulu agar warna seleksi/background tetap benar
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                
                // Cek apakah value-nya adalah objek User
                if (value instanceof User) {
                    User doctor = (User) value;
                    // UBAH TEKS YANG DITAMPILKAN JADI NAMA LENGKAP SAJA
                    setText(doctor.getFullName()); 
                }
                
                return this;
            }
        });
    }

    private void loadQueueList() {
        // Mendapatkan semua antrian yang belum selesai hari ini
        List<Appointment> waitingList = appointmentDAO.getAppointmentsByDate(LocalDate.now());
        
        receptionistPanel.getQueueModel().setRowCount(0);

        for (Appointment app : waitingList) {
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            User doctor = userDAO.getUserById(app.getDoctorId()); 
            
            String patientName = (patient != null) ? patient.getName() : "Pasien Error";
            String doctorName = (doctor != null) ? doctor.getFullName() : "Dokter Error";
            
            receptionistPanel.getQueueModel().addRow(new Object[]{
                app.getQueueNumber(),
                patientName,
                doctorName,
                app.getStatus()
            });
        }
    }

    private void handleAddToQueue() {
        String name = receptionistPanel.getPatientName();
        String nik = receptionistPanel.getNik();
        LocalDate birthDate = receptionistPanel.getDob(); 
        String phone = receptionistPanel.getPhone();
        String address = receptionistPanel.getAddress();
        String weightStr = receptionistPanel.getWeight();
        String heightStr = receptionistPanel.getPatientHeight();
        User selectedDoctor = receptionistPanel.getSelectedDoctor(); 

        if (name.isEmpty() || nik.isEmpty() || phone.isEmpty() || address.isEmpty() || 
            weightStr.isEmpty() || heightStr.isEmpty() || birthDate == null || selectedDoctor == null) {
            
            JOptionPane.showMessageDialog(receptionistPanel, "Semua kolom wajib diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            double weight = Double.parseDouble(weightStr);
            double height = Double.parseDouble(heightStr);
            
            // 1. SIMPAN PASIEN
            Patient newPatient = new Patient();
            newPatient.setName(name);
            newPatient.setNik(nik);
            newPatient.setBirthDate(birthDate);
            newPatient.setGender("P"); // Placeholder
            newPatient.setPhoneNumber(phone);
            newPatient.setAddress(address);
            
            int newPatientId = patientDAO.addPatient(newPatient); 
            
            if (newPatientId > 0) {
                
                // 2. BUAT & SIMPAN APPOINTMENT
                Appointment newAppt = new Appointment();
                newAppt.setPatientId(newPatientId);
                newAppt.setDoctorId(selectedDoctor.getId());
                newAppt.setDate(LocalDate.now()); 
                newAppt.setWeight(weight);
                newAppt.setHeight(height);
                newAppt.setStatus("WAITING");
                
                int queueNumber = appointmentDAO.getNextQueueNumber(selectedDoctor.getId(), LocalDate.now());
                newAppt.setQueueNumber(queueNumber);
                
                if (appointmentDAO.addAppointment(newAppt)) {
                    JOptionPane.showMessageDialog(receptionistPanel, 
                        "Pasien " + name + " terdaftar! No. Antrian: " + queueNumber);
                    
                    receptionistPanel.clearForm();
                    loadQueueList(); // MUAT ULANG TABEL
                } else {
                    JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan antrian.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(receptionistPanel, "Gagal menyimpan data pasien.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (NumberFormatException e) {
             JOptionPane.showMessageDialog(receptionistPanel, "Berat dan Tinggi harus berupa angka!", "Error Input", JOptionPane.ERROR_MESSAGE);
        }
    }
}

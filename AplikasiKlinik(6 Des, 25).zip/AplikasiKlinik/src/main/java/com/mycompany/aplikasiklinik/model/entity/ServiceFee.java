/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

/**
 *
 * @author LENOVO
 */
public class ServiceFee {
    private int id; // ID unik untuk Service Fee (misal: 1 untuk 'Konsultasi')
    private String name; // Nama layanan (misal: "Biaya Konsultasi Dokter")
    private double price; // Harga layanan

    public ServiceFee() {}

    public ServiceFee(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " (Rp " + price + ")";
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class ServiceFeeDAO {
    public List<ServiceFee> getAllServiceFees() {
        List<ServiceFee> fees = new ArrayList<>();
        String sql = "SELECT id, name, price FROM service_fees"; // Ganti nama tabel sesuai dengan skema Anda
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                fees.add(new ServiceFee(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Gunakan logger di production
        }
        return fees;
    }

    public ServiceFee getServiceFeeById(int id) {
        String sql = "SELECT id, name, price FROM service_fees WHERE id = ?"; // Ganti nama tabel
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new ServiceFee(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Gunakan logger di production
        }
        return null;
    }

    public boolean updateServiceFee(ServiceFee fee) {
        String sql = "UPDATE service_fees SET name = ?, price = ? WHERE id = ?"; // Ganti nama tabel
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, fee.getName());
            stmt.setDouble(2, fee.getPrice());
            stmt.setInt(3, fee.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Gunakan logger di production
            return false;
        }
    }

    // Method baru untuk INSERT
    public boolean addServiceFee(ServiceFee fee) {
        String sql = "INSERT INTO service_fees (name, price) VALUES (?, ?)"; // Ganti nama tabel
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, fee.getName());
            stmt.setDouble(2, fee.getPrice());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Gunakan logger di production
            return false;
        }
    }

    // Method baru untuk DELETE
    public boolean deleteServiceFee(int id) {
        String sql = "DELETE FROM service_fees WHERE id = ?"; // Ganti nama tabel
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Gunakan logger di production
            return false;
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.view.AdminPanel;
import com.mycompany.aplikasiklinik.view.MainDashboard;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LENOVO
 */
public class AdminController {
    private MainDashboard dashboard; // Simpan referensi dashboard
    private AdminPanel adminPanel;
    private UserDAO userDAO;

    // Modifikasi constructor untuk menerima MainDashboard
    public AdminController(MainDashboard dashboard, AdminPanel adminPanel, UserDAO userDAO) {
        this.dashboard = dashboard; // Simpan referensi
        this.adminPanel = adminPanel;
        this.userDAO = userDAO;
        // this.dashboard = dashboard; // Hapus baris ini karena sudah disimpan di atas

        // Hubungkan aksi tombol
        this.adminPanel.getBtnAddUser().addActionListener(e -> addUser());
        this.adminPanel.getBtnNavFeeManagement().addActionListener(e -> navigateToFeeManagement());
        // Hapus baris ini karena tombolnya sudah dihapus dari panel
        // this.adminPanel.getBtnNavInventory().addActionListener(e -> navigateToInventory());

        // Load data awal
        loadAllUsers();
    }

    private void navigateToFeeManagement() {
        dashboard.getCardLayout().show(dashboard.getMainPanel(), "FEE_MANAGEMENT");
    }

    // Hapus method navigateToInventory karena tombolnya sudah dihapus
    /*
    private void navigateToInventory() {
        // "PHARMACIST" adalah nama card untuk InventoryPanel di MainDashboard
        dashboard.getCardLayout().show(dashboard.getMainPanel(), "PHARMACIST");
    }
    */

    private void addUser() {
        try {
            String username = adminPanel.getUsername();
            String password = adminPanel.getPassword();
            String fullname = adminPanel.getFullname();
            String roleName = adminPanel.getSelectedRole(); // String dari JComboBox
            
            if (username.isEmpty() || password.isEmpty() || fullname.isEmpty()) {
                JOptionPane.showMessageDialog(adminPanel, "Semua field harus diisi!");
                return;
            }
            
            // Validasi role tidak sama dengan SUPERADMIN
            if (roleName.equals("SUPERADMIN")) {
                JOptionPane.showMessageDialog(adminPanel, "Role SUPERADMIN tidak dapat ditambahkan melalui menu ini!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UserRole role = UserRole.valueOf(roleName);
            
            // Catatan: Password hashing harus dilakukan di sini sebelum disimpan
            User newUser = new User(username, password, fullname, role);
            
            if (userDAO.addUser(newUser)) {
                JOptionPane.showMessageDialog(adminPanel, "User berhasil ditambahkan!");
                adminPanel.clearForm();
                loadAllUsers(); // Refresh tabel
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan user. Mungkin username sudah ada.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(adminPanel, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void loadAllUsers() {
        DefaultTableModel model = adminPanel.getUserTableModel();
        model.setRowCount(0); // Clear tabel lama
        
        List<User> users = userDAO.getAllUsers();
        for (User user : users) {
            model.addRow(new Object[]{
                user.getId(), 
                user.getUsername(), 
                user.getFullName(), 
                user.getRole().toString() // Menggunakan toString() dari UserRole
            });
        }
    }
}
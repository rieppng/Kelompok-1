// File: com/mycompany/aplikasiklinik/model/entity/AppointmentService.java
package com.mycompany.aplikasiklinik.model.entity;

public class AppointmentService {
    private int id;
    private int appointmentId;
    private int serviceFeeId; // Merujuk ke service_fees
    private int quantity;
    private double priceAtTime; // Harga layanan saat diberikan

    public AppointmentService() {}

    public AppointmentService(int appointmentId, int serviceFeeId, int quantity, double priceAtTime) {
        this.appointmentId = appointmentId;
        this.serviceFeeId = serviceFeeId;
        this.quantity = quantity;
        this.priceAtTime = priceAtTime;
    }

    // Getter dan Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    public int getServiceFeeId() { return serviceFeeId; }
    public void setServiceFeeId(int serviceFeeId) { this.serviceFeeId = serviceFeeId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPriceAtTime() { return priceAtTime; }
    public void setPriceAtTime(double priceAtTime) { this.priceAtTime = priceAtTime; }

    // Helper untuk subtotal
    public double getSubTotal() { return quantity * priceAtTime; }
}
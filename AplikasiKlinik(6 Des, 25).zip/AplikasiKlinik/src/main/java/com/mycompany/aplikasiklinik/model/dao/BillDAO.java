// File: com/mycompany/aplikasiklinik/model/dao/BillDAO.java
package com.mycompany.aplikasiklinik.model.dao;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class BillDAO {

    // Method untuk membuat bill baru berdasarkan objek Bill yang sudah memiliki totalMedicationCost, totalServiceCost, dll.
    public boolean createBill(Bill bill) {
        String sql = "INSERT INTO bills (appointment_id, total_medication_cost, total_service_cost, consultation_fee, total_amount, is_paid) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bill.getAppointmentId());
            stmt.setDouble(2, bill.getTotalMedicationCost());
            stmt.setDouble(3, bill.getTotalServiceCost()); // Tambahkan field baru
            stmt.setDouble(4, bill.getConsultationFee());
            stmt.setDouble(5, bill.getTotalAmount()); // Simpan total yang dihitung otomatis
            stmt.setBoolean(6, bill.isPaid()); // Default false saat dibuat

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method untuk menandai bill sebagai sudah dibayar
    public boolean markAsPaid(int billId) {
        String sql = "UPDATE bills SET is_paid = true, payment_date = NOW() WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, billId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method untuk mendapatkan bill berdasarkan appointment_id
    public Bill getBillByAppointmentId(int appointmentId) {
        String sql = "SELECT * FROM bills WHERE appointment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, appointmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // bill.setTotalAmount(rs.getDouble("total_amount")); // Baca dari DB
                bill.setPaid(rs.getBoolean("is_paid"));
                // Perhatikan: payment_date bisa null jika is_paid false
                if (rs.getTimestamp("payment_date") != null) {
                    bill.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                }
                return bill;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method untuk CashierController: mengambil semua bill yang belum dibayar
    public List<Bill> getUnpaidBills() {
        String sql = "SELECT id, appointment_id, total_medication_cost, total_service_cost, consultation_fee, total_amount FROM bills WHERE is_paid = 0";
        List<Bill> bills = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             java.sql.Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost")); // Tambahkan
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // bill.setTotalAmount(rs.getDouble("total_amount")); // Baca total dari DB
                bill.setPaid(false); // Karena query hanya ambil yang is_paid = 0
                bills.add(bill);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bills;
    }

    // Method opsional: mendapatkan bill berdasarkan ID bill
    public Bill getBillById(int id) {
        String sql = "SELECT * FROM bills WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("id"));
                bill.setAppointmentId(rs.getInt("appointment_id"));
                bill.setTotalMedicationCost(rs.getDouble("total_medication_cost"));
                bill.setTotalServiceCost(rs.getDouble("total_service_cost"));
                bill.setConsultationFee(rs.getDouble("consultation_fee"));
                // bill.setTotalAmount(rs.getDouble("total_amount"));
                bill.setPaid(rs.getBoolean("is_paid"));
                if (rs.getTimestamp("payment_date") != null) {
                    bill.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                }
                return bill;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
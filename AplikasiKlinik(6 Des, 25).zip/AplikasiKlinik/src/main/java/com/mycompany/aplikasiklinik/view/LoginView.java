/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.view;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author LENOVO
 */
public class LoginView extends JFrame {
    // Komponen UI
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnCancel;

    public LoginView() {
        // Setup Frame Dasar
        setTitle("Login Sistem Klinik");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false); // Agar ukuran tetap

        // Inisialisasi Komponen
        txtUsername = new JTextField(20);
        txtPassword = new JPasswordField(20);
        btnLogin = new JButton("Login");
        btnCancel = new JButton("Keluar");

        // Styling Tombol (Opsional)
        btnLogin.setBackground(new Color(0, 102, 204)); // Warna Biru
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("Arial", Font.BOLD, 12));

        // Layout Management (Menggunakan GridBagLayout agar rapi di tengah)
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Margin
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding antar komponen

        // --- Header Judul ---
        JLabel lblTitle = new JLabel("KLINIK SEHAT");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitle.setForeground(Color.DARK_GRAY);
        
        gbc.gridx = 0; 
        gbc.gridy = 0; 
        gbc.gridwidth = 2; // Gabungkan 2 kolom
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(lblTitle, gbc);

        // --- Label & Input Username ---
        gbc.gridwidth = 1; 
        gbc.gridy = 1; 
        gbc.gridx = 0; 
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        mainPanel.add(txtUsername, gbc);

        // --- Label & Input Password ---
        gbc.gridy = 2; 
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        mainPanel.add(txtPassword, gbc);

        // --- Panel Tombol ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(btnCancel);
        buttonPanel.add(btnLogin);

        gbc.gridy = 3; 
        gbc.gridx = 0; 
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(buttonPanel, gbc);

        // Masukkan Panel ke Frame
        add(mainPanel);
        pack(); // Sesuaikan ukuran frame dengan isi
        setLocationRelativeTo(null); // Muncul di tengah layar
        
        // Aksi Tombol Cancel (Langsung di View untuk simple logic)
        btnCancel.addActionListener(e -> System.exit(0));
    }

    // --- GETTERS (Jembatan untuk Controller) ---
    // Controller memanggil method ini untuk mengambil data, bukan akses komponen langsung.

    public String getUsernameInput() {
        return txtUsername.getText();
    }

    public String getPasswordInput() {
        // getPassword mengembalikan char[], harus diubah ke String
        return new String(txtPassword.getPassword());
    }

    public JButton getBtnLogin() {
        return btnLogin;
    }

    // Method Helper untuk menampilkan pesan (Dialog)
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

import java.time.LocalDate;

/**
 *
 * @author LENOVO
 */
public class Patient {
    private int id;
    private String name;
    private String nik; // Nomor KTP/Identitas
    private LocalDate birthDate;
    private String gender; // "L" atau "P"
    private String address;
    private String phoneNumber;

    public Patient() {}

    public Patient(int id, String name, String nik, LocalDate birthDate, String gender, String address, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.nik = nik;
        this.birthDate = birthDate;
        this.gender = gender;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getNik() { return nik; }
    public void setNik(String nik) { this.nik = nik; }

    public LocalDate getBirthDate() { return birthDate; }
    public void setBirthDate(LocalDate birthDate) { this.birthDate = birthDate; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    @Override
    public String toString() {
        return name + " (" + nik + ")";
    }
}

package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class InventoryPanel extends JPanel {
    // Input Fields
    private final JTextField txtMedName = new JTextField();
    private final JComboBox<String> comboCategory = new JComboBox<>(new String[]{"Tablet", "Sirup", "Kapsul", "Salep", "Injeksi"});
    private final JSpinner spinStock = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
    private final JTextField txtPrice = new JTextField();
    
    // Action Buttons
    private final JButton btnAddMed = new JButton("Tambah Obat");
    private final JButton btnUpdateMed = new JButton("Update Obat");
    private final JButton btnDeleteMed = new JButton("Hapus Obat");
    private final JButton btnProcessPrescription = new JButton("Proses Resep Masuk");

    // Table Inventaris
    private final JTable tableInventory = new JTable();
    private DefaultTableModel inventoryModel;
    
    // --- BARU: Tabel Resep Masuk ---
    private final JTable tableIncomingPrescription = new JTable();
    private DefaultTableModel incomingPrescriptionModel;
    
    public InventoryPanel() {
        setLayout(new BorderLayout());
        
        // --- CONTAINER UTAMA (Split Pane) ---
        // Membagi layar menjadi atas (Inventaris) dan bawah (Resep Masuk)
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setResizeWeight(0.5); // Bagi rata
        
        // --- BAGIAN ATAS: CRUD Obat (NORTH) ---
        JPanel topPanel = new JPanel(new BorderLayout());
        
        // Panel Form Input
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Form Data Obat"));

        inputPanel.add(new JLabel("Nama Obat:")); inputPanel.add(txtMedName);
        inputPanel.add(new JLabel("Kategori:")); inputPanel.add(comboCategory);
        inputPanel.add(new JLabel("Stok:")); inputPanel.add(spinStock);
        inputPanel.add(new JLabel("Harga:")); inputPanel.add(txtPrice);
        
        // Panel untuk tombol aksi CRUD
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnAddMed);
        buttonPanel.add(btnUpdateMed);
        buttonPanel.add(btnDeleteMed);
        inputPanel.add(new JLabel("Aksi:")); inputPanel.add(buttonPanel); 
        
        topPanel.add(inputPanel, BorderLayout.NORTH);
        
        // Panel Tabel Inventori
        JPanel inventoryTablePanel = new JPanel(new BorderLayout());
        inventoryTablePanel.setBorder(BorderFactory.createTitledBorder("Daftar Inventaris Obat"));
        inventoryModel = new DefaultTableModel(new Object[]{"ID", "Nama", "Kategori", "Stok", "Harga"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tableInventory.setModel(inventoryModel);
        inventoryTablePanel.add(new JScrollPane(tableInventory), BorderLayout.CENTER); 

        topPanel.add(inventoryTablePanel, BorderLayout.CENTER);
        
        // --- BAGIAN BAWAH: RESEP MASUK (CENTER) ---
        JPanel incomingPrescriptionPanel = new JPanel(new BorderLayout());
        incomingPrescriptionPanel.setBorder(BorderFactory.createTitledBorder("Antrian Resep Masuk (Menunggu Proses)"));
        
        // Definisikan model untuk tabel resep masuk
        // Kolom ditambah agar Apoteker bisa melihat detail
        incomingPrescriptionModel = new DefaultTableModel(new Object[]{"ID Item", "Nama Obat", "Jumlah", "Aturan Pakai", "ID Rekam Medis"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tableIncomingPrescription.setModel(incomingPrescriptionModel);
        
        incomingPrescriptionPanel.add(new JScrollPane(tableIncomingPrescription), BorderLayout.CENTER);
        
        // Panel Tombol Proses Resep
        JPanel bottomButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomButtonPanel.add(btnProcessPrescription);
        incomingPrescriptionPanel.add(bottomButtonPanel, BorderLayout.SOUTH);
        
        // --- GABUNGKAN KE SPLIT PANE ---
        splitPane.setTopComponent(topPanel);
        splitPane.setBottomComponent(incomingPrescriptionPanel);

        add(splitPane, BorderLayout.CENTER);

        // Disable tombol Update dan Delete secara default
        btnUpdateMed.setEnabled(false);
        btnDeleteMed.setEnabled(false);
    }

    // --- GETTERS UNTUK CONTROLLER ---
    
    // Getters Nilai Input
    public String getMedName() { return txtMedName.getText(); }
    public String getCategory() { return (String) comboCategory.getSelectedItem(); }
    public int getStock() { return (int) spinStock.getValue(); }
    public String getPrice() { return txtPrice.getText(); }

    // Getters Komponen Input
    public JTextField getTxtMedName() { return txtMedName; }
    public JComboBox<String> getComboCategory() { return comboCategory; }
    public JSpinner getSpinStock() { return spinStock; }
    public JTextField getTxtPrice() { return txtPrice; }

    // Getters Tombol
    public JButton getBtnAddMed() { return btnAddMed; }
    public JButton getBtnUpdateMed() { return btnUpdateMed; }
    public JButton getBtnDeleteMed() { return btnDeleteMed; }
    public JButton getBtnProcessPrescription() { return btnProcessPrescription; }

    // Getters Tabel Inventaris
    public JTable getTableInventory() { return tableInventory; }
    public DefaultTableModel getInventoryModel() { return inventoryModel; }
    
    // --- BARU: Getters untuk Tabel Resep Masuk ---
    public JTable getTableIncomingPrescription() { return tableIncomingPrescription; }
    public DefaultTableModel getIncomingPrescriptionModel() { return incomingPrescriptionModel; }

    public void clearForm() {
        txtMedName.setText("");
        comboCategory.setSelectedIndex(0);
        spinStock.setValue(0);
        txtPrice.setText("");
        
        // Reset selection dan disable tombol update/delete
        tableInventory.clearSelection();
        btnUpdateMed.setEnabled(false);
        btnDeleteMed.setEnabled(false);
    }
}
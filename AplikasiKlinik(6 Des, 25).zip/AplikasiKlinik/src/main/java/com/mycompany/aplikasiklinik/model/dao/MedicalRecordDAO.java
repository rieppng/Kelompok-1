/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecord;

/**
 *
 * @author LENOVO
 */
public class MedicalRecordDAO {
    // Method ini mengembalikan ID record yang baru dibuat (untuk keperluan resep)
    public int addMedicalRecord(MedicalRecord mr) {
        String sql = "INSERT INTO medical_records (appointment_id, symptoms, diagnosis, treatment, consultation_fee) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
             
            stmt.setInt(1, mr.getAppointmentId());
            stmt.setString(2, mr.getSymptoms());
            stmt.setString(3, mr.getDiagnosis());
            stmt.setString(4, mr.getTreatment());
            stmt.setDouble(5, mr.getConsultationFee());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // Mengembalikan ID
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}

package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import com.toedter.calendar.JDateChooser; // Pastikan library ini diimport
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class ReceptionistPanel extends JPanel {

    // --- Komponen Input ---
    private final JTextField txtName = new JTextField(15);
    private final JTextField txtNik = new JTextField(15);
    private final JDateChooser dateChooserDob = new JDateChooser(); // Menggunakan JDateChooser
    private final JTextArea txtAddress = new JTextArea(3, 20);
    private final JTextField txtPhone = new JTextField(15);
    private final JComboBox<User> comboDoctor = new JComboBox<>(); // Menyimpan objek User
    private final JTextField txtWeight = new JTextField(5);
    private final JTextField txtHeight = new JTextField(5);
    private final JButton btnAddToQueue = new JButton("Daftarkan & Masuk Antrian");

    // --- Tabel Antrian ---
    private final JTable tableQueue = new JTable();
    private DefaultTableModel queueTableModel;

    public ReceptionistPanel() {
        setLayout(new BorderLayout());

        // --- PANEL FORM INPUT (Bagian Kiri) ---
        // Gunakan GridLayout untuk pasangan label-field
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5)); // 0 baris berarti fleksibel, 2 kolom
        formPanel.setBorder(BorderFactory.createTitledBorder("Pendaftaran Pasien Baru"));
        formPanel.setPreferredSize(new Dimension(350, 0)); // Atur lebar tetap jika diperlukan

        // Tambahkan pasangan label-field ke formPanel
        formPanel.add(new JLabel("Nama Pasien:")); formPanel.add(txtName);
        formPanel.add(new JLabel("NIK/ID:")); formPanel.add(txtNik);
        formPanel.add(new JLabel("Tanggal Lahir:")); formPanel.add(dateChooserDob); // Gunakan JDateChooser
        formPanel.add(new JLabel("Alamat:")); formPanel.add(new JScrollPane(txtAddress)); // Bungkus JTextArea
        formPanel.add(new JLabel("No HP:")); formPanel.add(txtPhone);
        formPanel.add(new JLabel("Pilih Dokter:")); formPanel.add(comboDoctor);
        formPanel.add(new JLabel("Berat (kg):")); formPanel.add(txtWeight);
        formPanel.add(new JLabel("Tinggi (cm):")); formPanel.add(txtHeight);
        // Baris terakhir: Gunakan JLabel kosong untuk label dan tempatkan tombol di field
        formPanel.add(new JLabel()); // Placeholder untuk label kosong
        formPanel.add(btnAddToQueue); // Tempatkan tombol di sini

        // Tambahkan formPanel ke bagian kiri dari panel utama
        add(formPanel, BorderLayout.WEST);

        // --- PANEL TABEL ANTRIAN (Bagian Tengah/Center) ---
        queueTableModel = new DefaultTableModel(new Object[]{"No Antrian", "Nama Pasien", "Dokter", "Status"}, 0);
        tableQueue.setModel(queueTableModel);
        add(new JScrollPane(tableQueue), BorderLayout.CENTER); // Tambahkan tabel ke center
    }

    // --- Getter untuk Controller ---

    public String getPatientName() { return txtName.getText(); }
    public String getNik() { return txtNik.getText(); }

    // Getter untuk tanggal lahir (mengonversi dari java.util.Date ke java.time.LocalDate)
    public LocalDate getDob() {
        Date selectedDate = dateChooserDob.getDate();
        if (selectedDate == null) {
            return null; // Penting untuk validasi di Controller
        }
        return selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public String getAddress() { return txtAddress.getText(); }
    public String getPhone() { return txtPhone.getText(); }
    public User getSelectedDoctor() { return (User) comboDoctor.getSelectedItem(); } // Mengembalikan objek User
    public String getWeight() { return txtWeight.getText(); }
    public String getPatientHeight() { return txtHeight.getText(); }

    public JButton getBtnAddToQueue() { return btnAddToQueue; }
    public JComboBox<User> getComboDoctor() { return comboDoctor; } // Getter untuk mengisi combo
    public DefaultTableModel getQueueModel() { return queueTableModel; }

    public void clearForm() {
        txtName.setText("");
        txtNik.setText("");
        dateChooserDob.setDate(null); // Clear JDateChooser
        txtAddress.setText("");
        txtPhone.setText("");
        txtWeight.setText("");
        txtHeight.setText("");
        comboDoctor.setSelectedIndex(-1); // Reset combo
    }
}
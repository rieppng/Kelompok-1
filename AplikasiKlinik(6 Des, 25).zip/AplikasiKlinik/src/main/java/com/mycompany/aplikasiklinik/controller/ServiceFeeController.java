package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.ServiceFeeDAO;
import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import com.mycompany.aplikasiklinik.view.ServiceFeePanel;
import com.mycompany.aplikasiklinik.view.MainDashboard; // Import MainDashboard
import javax.swing.JOptionPane;

public class ServiceFeeController {

    private final ServiceFeePanel view;
    private final ServiceFeeDAO dao;
    private final MainDashboard dashboard; // Tambahkan referensi dashboard

    // Modifikasi constructor untuk menerima MainDashboard
    public ServiceFeeController(ServiceFeePanel view, MainDashboard dashboard) {
        this.view = view;
        this.dao = new ServiceFeeDAO();
        this.dashboard = dashboard; // Simpan referensi

        // Muat data awal
        loadServiceFees();

        // Hubungkan event listener ke tombol
        view.getBtnAddFee().addActionListener(e -> handleAdd());
        view.getBtnUpdateFee().addActionListener(e -> handleUpdate());
        view.getBtnDeleteFee().addActionListener(e -> handleDelete());
        // Hubungkan tombol kembali
        view.getBtnBackToAdmin().addActionListener(e -> dashboard.getCardLayout().show(dashboard.getMainPanel(), "ADMIN"));
    }

    private void loadServiceFees() {
        // Ambil data dari DAO
        var fees = dao.getAllServiceFees();
        var model = view.getFeeTableModel();

        // Kosongkan tabel
        model.setRowCount(0);

        // Isi tabel dengan data baru
        for (ServiceFee fee : fees) {
            model.addRow(new Object[]{fee.getId(), fee.getName(), fee.getPrice()});
        }
    }

    private void handleAdd() {
        String name = view.getFeeNameInput().trim();
        String priceStr = view.getFeePriceInput().trim();

        if (name.isEmpty() || priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Nama dan Harga tidak boleh kosong!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double price = Double.parseDouble(priceStr);
            if (price < 0) {
                JOptionPane.showMessageDialog(view, "Harga tidak boleh negatif!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
                return;
            }

            ServiceFee newFee = new ServiceFee(0, name, price); // ID 0 karena akan di-generate DB

            if (dao.addServiceFee(newFee)) {
                JOptionPane.showMessageDialog(view, "Layanan berhasil ditambahkan!");
                view.clearForm();
                loadServiceFees(); // Refresh tabel
            } else {
                JOptionPane.showMessageDialog(view, "Gagal menambahkan layanan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(view, "Harga harus berupa angka yang valid!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleUpdate() {
        int id = view.getSelectedFeeId();
        String name = view.getFeeNameInput().trim();
        String priceStr = view.getFeePriceInput().trim();

        if (id <= 0 || name.isEmpty() || priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Pilih layanan dari tabel dan isi semua field!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double price = Double.parseDouble(priceStr);
            if (price < 0) {
                JOptionPane.showMessageDialog(view, "Harga tidak boleh negatif!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
                return;
            }

            ServiceFee updatedFee = new ServiceFee(id, name, price);

            if (dao.updateServiceFee(updatedFee)) {
                JOptionPane.showMessageDialog(view, "Layanan berhasil diperbarui!");
                view.clearForm();
                loadServiceFees(); // Refresh tabel
            } else {
                JOptionPane.showMessageDialog(view, "Gagal memperbarui layanan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(view, "Harga harus berupa angka yang valid!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleDelete() {
        int id = view.getSelectedFeeId();

        if (id <= 0) {
            JOptionPane.showMessageDialog(view, "Pilih layanan dari tabel untuk dihapus!", "Validasi Input", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            view,
            "Yakin ingin menghapus layanan dengan ID " + id + "?",
            "Konfirmasi Hapus",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.deleteServiceFee(id)) {
                JOptionPane.showMessageDialog(view, "Layanan berhasil dihapus!");
                view.clearForm();
                loadServiceFees(); // Refresh tabel
            } else {
                JOptionPane.showMessageDialog(view, "Gagal menghapus layanan. Mungkin layanan ini sedang digunakan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
package com.mycompany.aplikasiklinik.model.entity;

/**** @author LENOVO*/
public class PrescriptionItem {
    private int id;
    private int medicalRecordId; // ID rekam medis
    private int appointmentId; // ID antrian
    private int medicationId; // ID obat
    private int quantity; // Jumlah obat
    private String instructions; // Aturan pakai
    private double priceAtTime; // Harga saat resep dibuat
    private String status; // Status: PENDING, PROCESSED, CANCELLED

    // Konstruktor default (untuk pembuatan objek baru)
    public PrescriptionItem() {
        this.status = "PENDING"; // Default status
    }

    // Konstruktor untuk membuat objek dari data database (termasuk medical_record_id)
    public PrescriptionItem(int id, int medicalRecordId, int appointmentId, int medicationId, int quantity, String instructions, double priceAtTime) {
        this.id = id;
        this.medicalRecordId = medicalRecordId;
        this.appointmentId = appointmentId;
        this.medicationId = medicationId;
        this.quantity = quantity;
        this.instructions = instructions;
        this.priceAtTime = priceAtTime;
        this.status = "PENDING"; // Default status
    }

    // Konstruktor tambahan untuk kompatibilitas (jika diperlukan)
    public PrescriptionItem(int id, int appointmentId, int medicationId, int quantity, String instructions, double priceAtTime) {
        this(id, 0, appointmentId, medicationId, quantity, instructions, priceAtTime); // Set medicalRecordId = 0 (default)
    }

    // Getter dan Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMedicalRecordId() {
        return medicalRecordId;
    }

    public void setMedicalRecordId(int medicalRecordId) {
        this.medicalRecordId = medicalRecordId;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public int getMedicationId() {
        return medicationId;
    }

    public void setMedicationId(int medicationId) {
        this.medicationId = medicationId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public double getPriceAtTime() {
        return priceAtTime;
    }

    public void setPriceAtTime(double priceAtTime) {
        this.priceAtTime = priceAtTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Method helper untuk menghitung subtotal
    public double getSubTotal() {
        return quantity * priceAtTime;
    }
}
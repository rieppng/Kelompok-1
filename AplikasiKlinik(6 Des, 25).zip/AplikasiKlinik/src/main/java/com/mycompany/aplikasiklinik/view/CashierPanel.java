package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class CashierPanel extends JPanel {
    // Left: Unpaid Bills
    private JTable tableUnpaidBills = new JTable();
    private DefaultTableModel unpaidModel;
    private JButton btnRefresh = new JButton("Refresh Data");

    // Right: Detail
    private JTextArea txtBillDetails = new JTextArea();
    private JLabel lblTotalAmount = new JLabel("Total: Rp 0", SwingConstants.CENTER);
    private JButton btnPay = new JButton("Proses Pembayaran");
    private JButton btnPrintReceipt = new JButton("Cetak Kwitansi");

    public CashierPanel() {
        setLayout(new GridLayout(1, 2)); // Split Kiri Kanan

        // --- LEFT SIDE ---
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBorder(BorderFactory.createTitledBorder("Tagihan Belum Lunas"));
        
        unpaidModel = new DefaultTableModel(new Object[]{"ID Tagihan", "Pasien", "Total Biaya"}, 0);
        tableUnpaidBills.setModel(unpaidModel);
        
        leftPanel.add(new JScrollPane(tableUnpaidBills), BorderLayout.CENTER);
        leftPanel.add(btnRefresh, BorderLayout.SOUTH);

        // --- RIGHT SIDE ---
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Rincian & Pembayaran"));
        
        txtBillDetails.setEditable(false);
        lblTotalAmount.setFont(new Font("Arial", Font.BOLD, 24));
        
        JPanel actionPanel = new JPanel(new GridLayout(2, 1));
        actionPanel.add(btnPay);
        actionPanel.add(btnPrintReceipt);

        rightPanel.add(new JScrollPane(txtBillDetails), BorderLayout.CENTER);
        rightPanel.add(lblTotalAmount, BorderLayout.NORTH);
        rightPanel.add(actionPanel, BorderLayout.SOUTH);

        add(leftPanel);
        add(rightPanel);
    }

    // Getters
    public JTable getTableUnpaidBills() { return tableUnpaidBills; }
    public DefaultTableModel getUnpaidModel() { return unpaidModel; }
    public JButton getBtnRefresh() { return btnRefresh; }
    
    public JTextArea getTxtBillDetails() { return txtBillDetails; }
    public void setTotalLabel(double amount) { lblTotalAmount.setText("Total: Rp " + amount); }
    
    public JButton getBtnPay() { return btnPay; }
    public JButton getBtnPrintReceipt() { return btnPrintReceipt; }
}
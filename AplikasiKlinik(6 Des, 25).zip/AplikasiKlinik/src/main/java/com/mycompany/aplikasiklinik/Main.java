/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aplikasiklinik;

import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.mycompany.aplikasiklinik.controller.ReceptionistController;
import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.view.LoginView;
import com.mycompany.aplikasiklinik.controller.LoginController;

/**
 *
 * @author LENOVO
 */
public class Main {

    public static void main(String[] args) {
        // 1. Cek Koneksi Database dengan try-catch
        try {
            DatabaseConnection.getConnection();
            System.out.println("Koneksi Database Awal Berhasil!");
        } catch (SQLException e) {
            // Jika gagal connect, tampilkan pesan error dan matikan aplikasi
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Gagal terhubung ke Database:\n" + e.getMessage(), "Error Database", JOptionPane.ERROR_MESSAGE);
            return; // Stop aplikasi jika DB tidak jalan
        }

        // 2. Jalankan Aplikasi GUI
        SwingUtilities.invokeLater(() -> {
            LoginView loginView = new LoginView();
            
            // Hubungkan View ke Controller
            new LoginController(loginView);
            
            loginView.setVisible(true);
        });
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

/**
 *
 * @author LENOVO
 */
public class MedicalRecord {
    private int id;
    private int appointmentId; // Terhubung ke Appointment spesifik
    
    // Hasil Analisa Dokter
    private String symptoms;   // Gejala yang dikeluhkan
    private String diagnosis;  // Penyakit yang didiagnosa
    private String treatment;  // Tindakan yang diberikan
    
    // Biaya jasa dokter (Service fee)
    private double consultationFee;

    public MedicalRecord() {}

    public MedicalRecord(int id, int appointmentId, String symptoms, String diagnosis, String treatment, double consultationFee) {
        this.id = id;
        this.appointmentId = appointmentId;
        this.symptoms = symptoms;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.consultationFee = consultationFee;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }

    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }

    public String getTreatment() { return treatment; }
    public void setTreatment(String treatment) { this.treatment = treatment; }

    public double getConsultationFee() { return consultationFee; }
    public void setConsultationFee(double consultationFee) { this.consultationFee = consultationFee; }
}

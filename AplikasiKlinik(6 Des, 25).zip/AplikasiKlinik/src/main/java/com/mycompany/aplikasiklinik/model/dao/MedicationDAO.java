/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Medication;

/**
 *
 * @author LENOVO
 */
public class MedicationDAO {

    // ADD/CREATE
    public boolean addMedication(Medication med) {
        String sql = "INSERT INTO medications (name, category, stock_quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, med.getName());
            stmt.setString(2, med.getCategory());
            stmt.setInt(3, med.getStockQuantity());
            stmt.setDouble(4, med.getPrice());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // UPDATE
    public boolean updateMedication(Medication med) {
        String sql = "UPDATE medications SET name = ?, category = ?, stock_quantity = ?, price = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, med.getName());
            stmt.setString(2, med.getCategory());
            stmt.setInt(3, med.getStockQuantity());
            stmt.setDouble(4, med.getPrice());
            stmt.setInt(5, med.getId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // DELETE
    public boolean deleteMedication(int id) {
        String sql = "DELETE FROM medications WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // GET ALL
    public List<Medication> getAllMedications() {
        List<Medication> medications = new ArrayList<>();
        String sql = "SELECT id, name, category, stock_quantity, price FROM medications";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String category = rs.getString("category");
                int stockQuantity = rs.getInt("stock_quantity");
                double price = rs.getDouble("price");
                
                Medication med = new Medication(id, name, category, stockQuantity, price);
                medications.add(med);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medications;
    }
    
    // UPDATE STOCK (Untuk Apoteker)
    public boolean updateStock(int medicationId, int quantityToDeduct) {
        String sql = "UPDATE medications SET stock_quantity = stock_quantity - ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, quantityToDeduct);
            ps.setInt(2, medicationId);
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- METHOD BARU: Get Medication By ID (Supaya Apoteker tau nama obatnya) ---
    public Medication getMedicationById(int id) {
        String sql = "SELECT id, name, category, stock_quantity, price FROM medications WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Medication(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("category"),
                    rs.getInt("stock_quantity"),
                    rs.getDouble("price")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
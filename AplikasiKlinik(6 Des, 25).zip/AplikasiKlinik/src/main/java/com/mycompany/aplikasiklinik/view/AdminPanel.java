package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Kelas AdminPanel menyediakan antarmuka pengguna berbasis GUI
 * untuk manajemen pengguna (CRUD) dan navigasi ke fitur administrasi lainnya
 * dalam aplikasi klinik.
 */
public class AdminPanel extends JPanel {

    // Komponen Input
    private final JTextField txtNewUsername = new JTextField(15);
    private final JTextField txtNewPassword = new JTextField(15); // Untuk testing, gunakan JPasswordField di production
    private final JTextField txtFullname = new JTextField(20);
    private final JComboBox<String> comboRole = new JComboBox<>(new String[]{"DOCTOR", "RECEPTIONIST", "PHARMACIST", "CASHIER", "SUPERADMIN"});

    // Tombol Aksi
    private final JButton btnAddUser = new JButton("Tambah User");
    private final JButton btnNavFeeManagement = new JButton("Kelola Biaya Layanan");
    // private final JButton btnNavInventory = new JButton("Kelola Inventori & Obat"); // Hapus baris ini

    // Tabel dan Model Data Pengguna
    private final JTable tableUsers = new JTable();
    private DefaultTableModel userTableModel;

    /**
     * Konstruktor untuk menginisialisasi tampilan dan komponen-komponen AdminPanel.
     */
    public AdminPanel() {
        setLayout(new BorderLayout());
        initializeComponents();
        setupLayout();
    }

    /**
     * Menginisialisasi model data untuk tabel pengguna.
     */
    private void initializeTableModel() {
        userTableModel = new DefaultTableModel(new Object[]{"ID", "Username", "Nama", "Role"}, 0) {
            // Override isCellEditable untuk membuat tabel tidak dapat diedit langsung
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Menonaktifkan editing langsung di tabel
            }
        };
        tableUsers.setModel(userTableModel);
    }

    /**
     * Menginisialisasi semua komponen UI utama.
     */
    private void initializeComponents() {
        initializeTableModel();
    }

    /**
     * Mengatur tata letak (layout) komponen-komponen ke dalam panel utama.
     */
    private void setupLayout() {
        // Panel Navigasi (Utara)
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        navPanel.setBorder(BorderFactory.createTitledBorder("Navigasi Admin"));
        navPanel.add(btnNavFeeManagement);
        // navPanel.add(btnNavInventory); // Hapus baris ini
        add(navPanel, BorderLayout.NORTH);

        // Panel Utama untuk CRUD Pengguna (Tengah)
        JPanel userCrudPanel = new JPanel(new BorderLayout());

        // Panel Form Input (Utara dari userCrudPanel)
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Tambah Staff Baru"));
        formPanel.add(new JLabel("Username:"));
        formPanel.add(txtNewUsername);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(txtNewPassword);
        formPanel.add(new JLabel("Nama Lengkap:"));
        formPanel.add(txtFullname);
        formPanel.add(new JLabel("Role:"));
        formPanel.add(comboRole);
        formPanel.add(new JLabel("")); // Placeholder untuk penjajaran
        formPanel.add(btnAddUser);

        userCrudPanel.add(formPanel, BorderLayout.NORTH);

        // Panel Tabel (Tengah dari userCrudPanel)
        userCrudPanel.add(new JScrollPane(tableUsers), BorderLayout.CENTER);

        add(userCrudPanel, BorderLayout.CENTER);
    }

    // --- Getter Methods untuk digunakan oleh Controller ---

    /**
     * Mendapatkan nilai username dari input field.
     *
     * @return String nilai dari txtNewUsername.
     */
    public String getUsername() {
        return txtNewUsername.getText();
    }

    /**
     * Mendapatkan nilai password dari input field.
     *
     * @return String nilai dari txtNewPassword.
     */
    public String getPassword() {
        return txtNewPassword.getText();
    }

    /**
     * Mendapatkan nilai nama lengkap dari input field.
     *
     * @return String nilai dari txtFullname.
     */
    public String getFullname() {
        return txtFullname.getText();
    }

    /**
     * Mendapatkan role yang dipilih dari combobox.
     *
     * @return String role yang dipilih.
     */
    public String getSelectedRole() {
        return (String) comboRole.getSelectedItem();
    }

    /**
     * Mendapatkan referensi tombol Tambah User.
     *
     * @return JButton btnAddUser.
     */
    public JButton getBtnAddUser() {
        return btnAddUser;
    }

    /**
     * Mendapatkan referensi tombol Navigasi Kelola Biaya Layanan.
     *
     * @return JButton btnNavFeeManagement.
     */
    public JButton getBtnNavFeeManagement() {
        return btnNavFeeManagement;
    }

    // Hapus getter untuk btnNavInventory
    // public JButton getBtnNavInventory() {
    //     return btnNavInventory;
    // }

    /**
     * Mendapatkan model data dari tabel pengguna.
     *
     * @return DefaultTableModel userTableModel.
     */
    public DefaultTableModel getUserTableModel() {
        return userTableModel;
    }

    /**
     * Mengosongkan semua field input (username, password, nama).
     * Biasanya dipanggil setelah berhasil menambahkan pengguna.
     */
    public void clearForm() {
        txtNewUsername.setText("");
        txtNewPassword.setText("");
        txtFullname.setText("");
    }
}
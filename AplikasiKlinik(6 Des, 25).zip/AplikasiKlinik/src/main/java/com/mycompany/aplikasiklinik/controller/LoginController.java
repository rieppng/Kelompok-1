// ... (bagian import lainnya)
package com.mycompany.aplikasiklinik.controller;

import javax.swing.JOptionPane;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.LoginView;
import com.mycompany.aplikasiklinik.view.MainDashboard;

/**
 *
 * @author LENOVO
 */
public class LoginController {
    private final LoginView view;
    private final UserDAO userDAO;

    public LoginController(LoginView view) {
        this.view = view;
        this.userDAO = new UserDAO();
        this.view.getBtnLogin().addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = view.getUsernameInput();
        String password = view.getPasswordInput();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Username dan Password tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = userDAO.login(username, password);

        if (user != null) {
            SessionManager.getInstance().setCurrentUser(user);
            view.dispose();
            MainDashboard dashboard = new MainDashboard();

            // Logika Logout - DIPERBARUI
            dashboard.getBtnLogout().addActionListener(e -> {
                User currentUser = SessionManager.getInstance().getCurrentUser();

                // Reset status pasien IN_CONSULTATION milik dokter yang logout
                if (currentUser != null && "DOCTOR".equals(currentUser.getRole().name())) {
                    AppointmentDAO appointmentDAO = new AppointmentDAO();
                    appointmentDAO.resetDoctorConsultationStatus(currentUser.getId());
                }

                SessionManager.getInstance().setCurrentUser(null);
                dashboard.dispose();

                LoginView newLoginView = new LoginView();
                new LoginController(newLoginView);
                newLoginView.setVisible(true);
            });

            // Inisialisasi Controller untuk setiap panel di Dashboard
            // Berikan userDAO ke AdminController karena Admin yang mengelola User
            new AdminController(dashboard, dashboard.getAdminPanel(), userDAO);
            new ReceptionistController(dashboard.getReceptionistPanel());
            new InventoryController(dashboard.getInventoryPanel());

            // --- PERUBAHAN: Inisialisasi DoctorController hanya jika role adalah DOCTOR ---
            if ("DOCTOR".equals(user.getRole().name())) {
                new DoctorController(dashboard.getDoctorPanel()); // Inisialisasi DoctorController
            } else {
                // Jika bukan dokter, nonaktifkan atau sembunyikan DoctorPanel jika perlu
                // Atau cukup jangan inisialisasi controller-nya
                // Di MainDashboard, showPanel(user.getRole().name()) akan menangani navigasi
                // Jadi, cukup jangan buat DoctorController jika bukan dokter.
            }
            // --- AKHIR PERUBAHAN ---

            new CashierController(dashboard.getCashierPanel());
            new ServiceFeeController(dashboard.getServiceFeePanel(), dashboard); // ServiceFeeController tetap diinisialisasi

            dashboard.setVisible(true);
            dashboard.showPanel(user.getRole().name());
        } else {
            JOptionPane.showMessageDialog(view, "Username atau Password salah!", "Login Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }
}
package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ServiceFeePanel extends JPanel {
    private JTable tableFees = new JTable();
    private DefaultTableModel feeTableModel;

    // Komponen input
    private JTextField txtFeeName = new JTextField(20);
    private JTextField txtFeePrice = new JTextField(15);
    private JButton btnAddFee = new JButton("Tambah Layanan");
    private JButton btnUpdateFee = new JButton("Update Layanan");
    private JButton btnDeleteFee = new JButton("Hapus Layanan");
    private JLabel lblSelectedId = new JLabel(); // Hidden label untuk menyimpan ID

    // Tombol baru untuk kembali ke admin
    private JButton btnBackToAdmin = new JButton("Kembali ke Admin");

    public ServiceFeePanel() {
        setLayout(new BorderLayout());

        // Panel tombol atas
        JPanel topButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topButtonPanel.add(btnBackToAdmin); // Tambahkan tombol kembali ke atas

        // --- FORM INPUT PANEL (NORTH) ---
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("Kelola Biaya Layanan"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label dan Field Nama
        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("Nama Layanan:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; inputPanel.add(txtFeeName, gbc);

        // Label dan Field Harga
        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("Harga (Rp):"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; inputPanel.add(txtFeePrice, gbc);

        // Panel Tombol Aksi
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAddFee);
        buttonPanel.add(btnUpdateFee);
        buttonPanel.add(btnDeleteFee);
        gbc.gridx = 2; gbc.gridy = 1; inputPanel.add(buttonPanel, gbc);

        // Label tersembunyi untuk menyimpan ID
        lblSelectedId.setVisible(false);
        inputPanel.add(lblSelectedId); // Tambahkan ke panel agar bisa diakses

        // Gabungkan panel tombol atas dan input ke panel utama atas
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(topButtonPanel, BorderLayout.NORTH);
        topPanel.add(inputPanel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // --- TABLE PANEL (CENTER) ---
        feeTableModel = new DefaultTableModel(new Object[]{"ID", "Nama Layanan", "Harga (Rp)"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabel tidak bisa diedit langsung
            }
        };
        tableFees.setModel(feeTableModel);

        // Listener untuk mengisi form saat baris dipilih
        tableFees.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tableFees.getSelectedRow() != -1) {
                int selectedRow = tableFees.getSelectedRow();
                String id = feeTableModel.getValueAt(selectedRow, 0).toString();
                String name = feeTableModel.getValueAt(selectedRow, 1).toString();
                String priceStr = feeTableModel.getValueAt(selectedRow, 2).toString();

                lblSelectedId.setText(id);
                txtFeeName.setText(name);
                txtFeePrice.setText(priceStr);
                btnUpdateFee.setEnabled(true);
                btnDeleteFee.setEnabled(true);
            }
        });

        add(new JScrollPane(tableFees), BorderLayout.CENTER);

        // Disable tombol update dan delete secara default
        btnUpdateFee.setEnabled(false);
        btnDeleteFee.setEnabled(false);
    }

    // --- GETTERS UNTUK CONTROLLER ---
    public int getSelectedFeeId() {
        try {
            return Integer.parseInt(lblSelectedId.getText());
        } catch (NumberFormatException e) {
            return -1; // Atau handle error lainnya
        }
    }

    public String getFeeNameInput() { return txtFeeName.getText(); }
    public String getFeePriceInput() { return txtFeePrice.getText(); }

    public JButton getBtnAddFee() { return btnAddFee; }
    public JButton getBtnUpdateFee() { return btnUpdateFee; }
    public JButton getBtnDeleteFee() { return btnDeleteFee; }

    // Getter untuk tombol kembali ke admin
    public JButton getBtnBackToAdmin() { return btnBackToAdmin; }

    public DefaultTableModel getFeeTableModel() { return feeTableModel; }
    public JTable getTableFees() { return tableFees; }

    public void clearForm() {
        txtFeeName.setText("");
        txtFeePrice.setText("");
        lblSelectedId.setText("");
        tableFees.clearSelection();
        btnUpdateFee.setEnabled(false);
        btnDeleteFee.setEnabled(false);
    }

    // Getter tambahan untuk mengakses data dari form secara langsung (opsional, tapi bisa berguna)
    public JTextField getTxtFeeName() { return txtFeeName; }
    public JTextField getTxtFeePrice() { return txtFeePrice; }
    public JLabel getLblSelectedId() { return lblSelectedId; }
}
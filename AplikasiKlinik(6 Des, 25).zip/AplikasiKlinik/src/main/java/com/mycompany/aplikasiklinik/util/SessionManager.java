/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.util;

import com.mycompany.aplikasiklinik.model.entity.User;

/**
 *
 * @author LENOVO
 */
public class SessionManager {
    private static SessionManager instance;
    private User currentUser;

    // Private constructor untuk mencegah instansiasi dari luar
    private SessionManager() {}

    // Method untuk mendapatkan satu-satunya instance
    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    // Method untuk menyimpan data user yang baru login
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    // Method untuk mendapatkan data user saat ini
    public User getCurrentUser() {
        return currentUser;
    }

    // Method untuk mengecek apakah user sudah login
    public boolean isLoggedIn() {
        return currentUser != null;
    }

    // Method untuk logout
    public void logout() {
        this.currentUser = null;
    }
}

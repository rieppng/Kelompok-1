/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

import java.util.Objects;

/**
 *
 * @author LENOVO
 */
public class User {
    private int id;
    private String username;
    private String password;
    private String fullName;
    private UserRole role;

    // 1. Constructor Kosong (Penting untuk beberapa framework/library)
    public User() {
    }

    // 2. Constructor Lengkap (Biasanya dipakai saat mengambil data dari DB)
    public User(int id, String username, String password, String fullName, UserRole role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }

    // 3. Constructor Tanpa ID (Biasanya dipakai saat mendaftar user baru sebelum masuk DB)
    public User(String username, String password, String fullName, UserRole role) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }

    // --- Getters and Setters ---

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    /**
     * Set password baru.
     * Note: Pastikan password yang dimasukkan ke sini sudah di-hash/enkripsi
     * oleh Controller/Utils sebelum disimpan.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    // --- Override Methods (Opsional tapi Good Practice) ---
    
    // Memudahkan debugging saat mencetak object User ke console
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", role=" + role +
                '}';
    }

    // Untuk perbandingan objek (misal: pengecekan di List)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id == user.id && Objects.equals(username, user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, username);
    }
}

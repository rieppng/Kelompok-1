/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author LENOVO
 */
public class DatabaseConnection {
    // Konfigurasi Database
    private static final String URL = "jdbc:mysql://localhost:3306/klinik_db";
    private static final String USER = "root";
    private static final String PASSWORD = ""; 

    // HAPUS variabel 'private static Connection connection;' 
    // Kita tidak menyimpan koneksi lagi.

    public static Connection getConnection() throws SQLException {
        try {
            // Load Driver MySQL (Penting agar Driver terdeteksi)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // SELALU buat koneksi BARU setiap kali dipanggil
            return DriverManager.getConnection(URL, USER, PASSWORD);
            
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL tidak ditemukan!", e);
        }
    }
}

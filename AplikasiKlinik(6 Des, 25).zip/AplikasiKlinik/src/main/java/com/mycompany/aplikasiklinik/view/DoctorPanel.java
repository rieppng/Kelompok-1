package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DoctorPanel extends JPanel {
    // Left Side (Queue)
    private final JTable tableWaitingList = new JTable();
    private DefaultTableModel waitingListModel;
    private final JButton btnStartConsult = new JButton("Mulai Periksa");
    
    // Right Side (Consultation) - Components
    private final JTextArea txtSymptoms = new JTextArea(3, 20);
    private final JTextArea txtDiagnosis = new JTextArea(3, 20);
    private final JTextArea txtTreatment = new JTextArea(3, 20);
    
    // ComboBox Tindakan (Tanpa Tombol Tambah lagi)
    private final JComboBox<ServiceFee> comboTreatmentService = new JComboBox<>(); 

    private final JTable tablePrescription = new JTable(); // Obat & Tindakan yg diberikan
    private DefaultTableModel prescriptionModel;
    
    private final JButton btnRemoveSelectedPrescription = new JButton("Hapus Item Dipilih");
    private final JButton btnSaveRecord = new JButton("Simpan Rekam Medis");
    private final JButton btnAddMedication = new JButton("Tambah Obat");

    public DoctorPanel() {
        setLayout(new GridLayout(1, 2)); // Split kiri kanan

        // --- LEFT: WAITING LIST ---
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBorder(BorderFactory.createTitledBorder("Daftar Tunggu Pasien"));

        waitingListModel = new DefaultTableModel(new Object[]{"Nomor Antrian", "Nama Pasien", "Status"}, 0);
        tableWaitingList.setModel(waitingListModel);

        leftPanel.add(new JScrollPane(tableWaitingList), BorderLayout.CENTER);
        leftPanel.add(btnStartConsult, BorderLayout.SOUTH);

        add(leftPanel);

        // --- RIGHT: EXAMINATION ---
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Form Pemeriksaan"));
        
        // 1. Panel untuk Form Input (Gejala, Diagnosa, dll) -> NORTH
        // Ubah GridLayout menjadi 4 baris saja (karena tombol hilang)
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        
        inputPanel.setBorder(BorderFactory.createTitledBorder("Data Pemeriksaan"));
        inputPanel.add(new JLabel("Keluhan/Gejala:")); inputPanel.add(new JScrollPane(txtSymptoms));
        inputPanel.add(new JLabel("Diagnosa:")); inputPanel.add(new JScrollPane(txtDiagnosis));
        inputPanel.add(new JLabel("Tindakan (Keterangan):")); inputPanel.add(new JScrollPane(txtTreatment));
        
        // Bagian Pilih Layanan (Tanpa Tombol)
        inputPanel.add(new JLabel("Pilih Tind. Layanan:")); inputPanel.add(comboTreatmentService);

        rightPanel.add(inputPanel, BorderLayout.NORTH);

        // 2. Panel untuk Tabel Resep dan Aksi Terkait Tabel -> CENTER
        JPanel prescriptionPanel = new JPanel(new BorderLayout());
        prescriptionPanel.setBorder(BorderFactory.createTitledBorder("Resep & Tindakan"));

        prescriptionModel = new DefaultTableModel(new Object[]{"Jenis", "Nama", "Qty", "Harga/Item", "Subtotal", "Aturan Pakai"}, 0);
        tablePrescription.setModel(prescriptionModel);
        prescriptionPanel.add(new JScrollPane(tablePrescription), BorderLayout.CENTER);

        // Panel untuk tombol aksi terkait tabel resep
        JPanel prescriptionButtonPanel = new JPanel(new FlowLayout());
        prescriptionButtonPanel.add(btnRemoveSelectedPrescription);
        prescriptionPanel.add(prescriptionButtonPanel, BorderLayout.SOUTH);

        rightPanel.add(prescriptionPanel, BorderLayout.CENTER); 

        // 3. Panel untuk Tombol Utama (Tambah Obat, Simpan) -> SOUTH
        JPanel mainActionPanel = new JPanel(new FlowLayout());
        mainActionPanel.add(btnAddMedication);
        mainActionPanel.add(btnSaveRecord);
        rightPanel.add(mainActionPanel, BorderLayout.SOUTH); 

        add(rightPanel);
    }

    // Getters
    public JTable getTableWaitingList() { return tableWaitingList; }
    public DefaultTableModel getWaitingListModel() { return waitingListModel; }
    public JButton getBtnStartConsult() { return btnStartConsult; }

    public String getSymptoms() { return txtSymptoms.getText(); }
    public String getDiagnosis() { return txtDiagnosis.getText(); }
    public String getTreatment() { return txtTreatment.getText(); }

    public JComboBox<ServiceFee> getComboTreatmentService() { return comboTreatmentService; }
    
    // HAPUS getter btnAddSelectedTreatment karena tombolnya sudah dihapus
    
    public JButton getBtnRemoveSelectedPrescription() { return btnRemoveSelectedPrescription; }
    public JButton getBtnAddMedication() { return btnAddMedication; }
    public DefaultTableModel getPrescriptionModel() { return prescriptionModel; }
    public JButton getBtnSaveRecord() { return btnSaveRecord; }

    public void clearForm() {
        txtSymptoms.setText("");
        txtDiagnosis.setText("");
        txtTreatment.setText("");
        prescriptionModel.setRowCount(0);
        comboTreatmentService.setSelectedIndex(-1); // Reset combo box
    }

    public JTextArea getTxtSymptoms() { return txtSymptoms; }
    public JTextArea getTxtDiagnosis() { return txtDiagnosis; }
    public JTextArea getTxtTreatment() { return txtTreatment; }
    public JTable getTablePrescription() { return tablePrescription; }
}
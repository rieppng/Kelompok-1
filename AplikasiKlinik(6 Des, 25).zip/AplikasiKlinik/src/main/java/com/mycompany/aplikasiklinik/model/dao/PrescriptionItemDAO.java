/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class PrescriptionItemDAO {
    /**
     * Menyimpan satu item resep baru ke database.
     * PERBAIKAN: Menambahkan kolom 'status' ke dalam query INSERT.
     */
    public boolean addPrescriptionItem(PrescriptionItem item) {
        // Query diperbarui untuk menyertakan 'status'
        String sql = "INSERT INTO prescription_items (medical_record_id, medication_id, quantity, price_at_time, instructions, status) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, item.getMedicalRecordId());
            stmt.setInt(2, item.getMedicationId());
            stmt.setInt(3, item.getQuantity());
            stmt.setDouble(4, item.getPriceAtTime());
            stmt.setString(5, item.getInstructions());
            stmt.setString(6, item.getStatus()); // Menyimpan status (PENDING)
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 1. Ambil semua resep yang statusnya PENDING
    public List<PrescriptionItem> getPendingPrescriptions() {
        List<PrescriptionItem> list = new ArrayList<>();
        String sql = "SELECT * FROM prescription_items WHERE status = 'PENDING'";
        
        try (Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                PrescriptionItem item = new PrescriptionItem();
                item.setId(rs.getInt("id"));
                item.setMedicalRecordId(rs.getInt("medical_record_id"));
                item.setMedicationId(rs.getInt("medication_id"));
                item.setQuantity(rs.getInt("quantity"));
                item.setPriceAtTime(rs.getDouble("price_at_time"));
                item.setInstructions(rs.getString("instructions"));
                item.setStatus(rs.getString("status"));
                
                list.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // 2. Update status resep (misal jadi PROCESSED)
    public boolean updateStatus(int id, String newStatus) {
        String sql = "UPDATE prescription_items SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
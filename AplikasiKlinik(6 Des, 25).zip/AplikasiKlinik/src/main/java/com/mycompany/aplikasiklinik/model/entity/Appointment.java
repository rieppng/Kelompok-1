/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

import java.time.LocalDate;

/**
 *
 * @author LENOVO
 */
public class Appointment {
    private int id;
    private int patientId;    // Foreign Key ke Patient
    private int doctorId;     // Foreign Key ke User (Role: DOCTOR)
    private LocalDate date;
    private int queueNumber;  // Nomor antrian
    
    // Vital Signs (Diisi Resepsionis saat pendaftaran)
    private double weight;
    private double height;
    private String bloodPressure; // Opsional
    
    // Status: "WAITING", "IN_CONSULTATION", "COMPLETED", "CANCELLED"
    private String status; 

    public Appointment() {}

    public Appointment(int id, int patientId, int doctorId, LocalDate date, int queueNumber, double weight, double height, String status) {
        this.id = id;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.queueNumber = queueNumber;
        this.weight = weight;
        this.height = height;
        this.status = status;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public int getQueueNumber() { return queueNumber; }
    public void setQueueNumber(int queueNumber) { this.queueNumber = queueNumber; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; }

    public String getBloodPressure() { return bloodPressure; }
    public void setBloodPressure(String bloodPressure) { this.bloodPressure = bloodPressure; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}

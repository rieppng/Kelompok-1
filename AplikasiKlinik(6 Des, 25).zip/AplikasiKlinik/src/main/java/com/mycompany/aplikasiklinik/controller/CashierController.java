/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.BillDAO;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import com.mycompany.aplikasiklinik.view.CashierPanel;
import java.util.List;
import javax.swing.Timer;

import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LENOVO
 */
public class CashierController {
    private CashierPanel cashierPanel;
    private BillDAO billDAO;
    private Bill selectedBill;
    
    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 8000; // Refresh setiap 8 detik

    public CashierController(CashierPanel cashierPanel) {
        this.cashierPanel = cashierPanel;
        this.billDAO = new BillDAO();
        
        loadUnpaidBills();
        
        this.cashierPanel.getBtnRefresh().addActionListener(e -> loadUnpaidBills());
        this.cashierPanel.getBtnPay().addActionListener(e -> processPayment());
        
        this.cashierPanel.getTableUnpaidBills().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
    
        startAutoRefresh();
    }
    
    private void startAutoRefresh() {
        // Timer yang akan memanggil loadUnpaidBills() setiap 8 detik
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> {
            loadUnpaidBills(); 
            // Opsional: Hilangkan selectedBill jika list berubah drastis
        });
        refreshTimer.start();
    }
    
    // Dipanggil saat aplikasi ditutup/logout
    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }
    
    public void loadUnpaidBills() {
        DefaultTableModel model = cashierPanel.getUnpaidModel();
        model.setRowCount(0);

        // Ambil dari BillDAO
        List<Bill> unpaidBills = billDAO.getUnpaidBills(); // Gunakan method baru

        for (Bill bill : unpaidBills) {
            // Ambil nama pasien dan dokter dari Appointment/Patient/Doctor DAO jika diperlukan untuk tampilan
            // Untuk sekarang, tampilkan ID bill dan total amount
            // Kita bisa ambil nama pasien dari AppointmentDAO dan PatientDAO
            // Appointment app = appointmentDAO.getAppointmentById(bill.getAppointmentId());
            // Patient patient = patientDAO.getPatientById(app.getPatientId());
            // String patientName = patient != null ? patient.getName() : "Unknown";

            model.addRow(new Object[]{bill.getId(), "Pasien (ID: " + bill.getAppointmentId() + ")", bill.getTotalAmount()}); // Sesuaikan tampilan
        }
    }
    
    private void tableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && cashierPanel.getTableUnpaidBills().getSelectedRow() != -1) {
            int row = cashierPanel.getTableUnpaidBills().getSelectedRow();
            int billId = (int) cashierPanel.getUnpaidModel().getValueAt(row, 0);
            
            // Asumsi: Ambil Bill dari DB
            // selectedBill = billDAO.getBillById(billId); 
            
            // Untuk demo, buat objek dummy
            selectedBill = new Bill(billId, 0, 100000.0, 50000.0, false); 
            
            String details = "ID Tagihan: " + selectedBill.getId() + 
                             "\nBiaya Konsultasi: Rp " + selectedBill.getConsultationFee() +
                             "\nBiaya Obat: Rp " + selectedBill.getTotalMedicationCost() +
                             "\n-------------------" +
                             "\nTotal: Rp " + selectedBill.getTotalAmount();
            
            cashierPanel.getTxtBillDetails().setText(details);
            cashierPanel.setTotalLabel(selectedBill.getTotalAmount());
        }
    }
    
    private void processPayment() {
        if (selectedBill == null) {
            JOptionPane.showMessageDialog(cashierPanel, "Pilih tagihan yang akan dibayar!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(cashierPanel, 
                "Proses pembayaran total Rp " + selectedBill.getTotalAmount() + "?", 
                "Konfirmasi Pembayaran", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (billDAO.markAsPaid(selectedBill.getId())) {
                JOptionPane.showMessageDialog(cashierPanel, "Pembayaran berhasil!");
                selectedBill = null;
                cashierPanel.getTxtBillDetails().setText("");
                cashierPanel.setTotalLabel(0.0);
                loadUnpaidBills(); 
            } else {
                JOptionPane.showMessageDialog(cashierPanel, "Gagal memproses pembayaran.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}

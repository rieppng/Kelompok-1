package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.MedicationDAO;
import com.mycompany.aplikasiklinik.model.entity.Medication;
import com.mycompany.aplikasiklinik.view.InventoryPanel;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import com.mycompany.aplikasiklinik.model.dao.PrescriptionItemDAO;
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;

/**
 *
 * @author LENOVO
 */
public class InventoryController {
    private final InventoryPanel inventoryPanel;
    private final MedicationDAO medicationDAO;
    private final PrescriptionItemDAO prescriptionItemDAO;
    private Medication selectedMedication; // Menyimpan obat yang dipilih dari tabel inventaris

    public InventoryController(InventoryPanel inventoryPanel) {
        this.inventoryPanel = inventoryPanel;
        this.medicationDAO = new MedicationDAO(); 
        this.prescriptionItemDAO = new PrescriptionItemDAO();

        // Muat data awal saat controller dibuat
        loadMedicationTable();
        
        // --- BARU: Muat daftar resep yang masuk (Pending) ---
        loadIncomingPrescriptionTable();
        
        // Hubungkan event listener ke tombol-tombol di panel
        this.inventoryPanel.getBtnAddMed().addActionListener(e -> addMedication());
        this.inventoryPanel.getBtnUpdateMed().addActionListener(e -> updateMedication());
        this.inventoryPanel.getBtnDeleteMed().addActionListener(e -> deleteMedication());
        this.inventoryPanel.getBtnProcessPrescription().addActionListener(e -> processIncomingPrescriptions());

        // Hubungkan event listener ke tabel untuk penanganan pemilihan baris
        this.inventoryPanel.getTableInventory().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
    }
    
    // --- BARU: Method untuk memuat detail resep masuk ke tabel bawah ---
    public void loadIncomingPrescriptionTable() {
        // Ambil model dari tabel resep masuk
        DefaultTableModel model = inventoryPanel.getIncomingPrescriptionModel(); 
        model.setRowCount(0);

        // 1. Ambil data resep yang PENDING
        List<PrescriptionItem> pendingItems = prescriptionItemDAO.getPendingPrescriptions();
        
        if (pendingItems != null) {
            for (PrescriptionItem item : pendingItems) {
                // Perlu MedicationDAO untuk mengambil nama obat berdasarkan ID
                Medication med = medicationDAO.getMedicationById(item.getMedicationId()); 
                String medicationName = (med != null) ? med.getName() : "Obat Tidak Ditemukan";
                
                model.addRow(new Object[]{
                    item.getId(),                 // ID Resep Item
                    medicationName,               // Nama Obat (Supaya Apoteker tau)
                    item.getQuantity(),           // Jumlah
                    item.getInstructions(),       // Aturan Pakai
                    item.getMedicalRecordId()     // ID Rekam Medis
                });
            }
        }
    }

    // --- Method untuk memproses resep masuk ---
    private void processIncomingPrescriptions() {
        // 1. Ambil data resep yang PENDING
        List<PrescriptionItem> pendingItems = prescriptionItemDAO.getPendingPrescriptions();
        if (pendingItems.isEmpty()) {
            JOptionPane.showMessageDialog(inventoryPanel, "Tidak ada resep baru yang perlu diproses.");
            return;
        }

        // 2. Tampilkan Konfirmasi
        int confirm = JOptionPane.showConfirmDialog(inventoryPanel,
                "Ditemukan " + pendingItems.size() + " item resep dalam antrian.\n" +
                        "Proses dan kurangi stok sekarang?",
                "Konfirmasi Apoteker", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            int successCount = 0;
            StringBuilder errorLog = new StringBuilder();

            for (PrescriptionItem item : pendingItems) {
                // 3. KURANGI STOK DI DATABASE
                boolean stockUpdated = medicationDAO.updateStock(item.getMedicationId(), item.getQuantity());
                
                if (stockUpdated) {
                    // 4. JIKA STOK BERHASIL DIKURANGI, UBAH STATUS JADI 'PROCESSED'
                    prescriptionItemDAO.updateStatus(item.getId(), "PROCESSED");
                    successCount++;
                } else {
                    errorLog.append("Gagal memproses Item ID: ").append(item.getId()).append(" (Stok mungkin kurang?)\n");
                }
            }

            // 5. Feedback ke User
            String message = successCount + " item resep berhasil diproses.";
            if (errorLog.length() > 0) {
                message += "\n\nError:\n" + errorLog.toString();
            }

            JOptionPane.showMessageDialog(inventoryPanel, message);
            
            // 6. Refresh KEDUA tabel (Inventaris agar stok berkurang, Resep Masuk agar item hilang)
            loadMedicationTable();
            loadIncomingPrescriptionTable(); 
        }
    }

    // --- Method untuk memuat data obat ke tabel ---
    private void loadMedicationTable() {
        DefaultTableModel model = inventoryPanel.getInventoryModel();
        model.setRowCount(0); // Kosongkan tabel sebelum diisi

        List<Medication> meds = medicationDAO.getAllMedications();
        if (meds != null) { 
            for (Medication med : meds) {
                model.addRow(new Object[]{
                        med.getId(),
                        med.getName(),
                        med.getCategory(),
                        med.getStockQuantity(),
                        med.getPrice()
                });
            }
        } else {
             JOptionPane.showMessageDialog(inventoryPanel, "Gagal memuat data obat dari database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- Method untuk menangani pemilihan baris di tabel ---
    private void tableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && inventoryPanel.getTableInventory().getSelectedRow() != -1) {
            int row = inventoryPanel.getTableInventory().getSelectedRow();
            DefaultTableModel model = inventoryPanel.getInventoryModel();

            int id = (int) model.getValueAt(row, 0);

            selectedMedication = new Medication(
                    id,
                    (String) model.getValueAt(row, 1), // Nama
                    (String) model.getValueAt(row, 2), // Kategori
                    (int) model.getValueAt(row, 3),    // Stok
                    (double) model.getValueAt(row, 4)  // Harga
            );
            
            // Isi form input
            inventoryPanel.getTxtMedName().setText(selectedMedication.getName());
            inventoryPanel.getComboCategory().setSelectedItem(selectedMedication.getCategory());
            inventoryPanel.getSpinStock().setValue(selectedMedication.getStockQuantity());
            inventoryPanel.getTxtPrice().setText(String.valueOf(selectedMedication.getPrice()));

            // Aktifkan tombol
            inventoryPanel.getBtnUpdateMed().setEnabled(true);
            inventoryPanel.getBtnDeleteMed().setEnabled(true);

        } else if (!e.getValueIsAdjusting() && inventoryPanel.getTableInventory().getSelectedRow() == -1) {
            inventoryPanel.getBtnUpdateMed().setEnabled(false);
            inventoryPanel.getBtnDeleteMed().setEnabled(false);
        }
    }

    // --- Method untuk menambah obat baru ---
    private void addMedication() {
        try {
            String medName = inventoryPanel.getMedName();
            String category = inventoryPanel.getCategory();
            int stock = inventoryPanel.getStock();
            double price = Double.parseDouble(inventoryPanel.getPrice());

            if (medName.isEmpty() || price <= 0) {
                JOptionPane.showMessageDialog(inventoryPanel, "Nama dan Harga harus diisi dengan benar!", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Medication newMed = new Medication(0, medName, category, stock, price);

            if (medicationDAO.addMedication(newMed)) {
                JOptionPane.showMessageDialog(inventoryPanel, "Obat berhasil ditambahkan!");
                inventoryPanel.clearForm();
                loadMedicationTable();
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal menambahkan obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inventoryPanel, "Harga harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Method untuk mengupdate data obat ---
    private void updateMedication() {
        if (selectedMedication == null) {
            JOptionPane.showMessageDialog(inventoryPanel, "Pilih obat yang ingin diupdate dari tabel.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String medName = inventoryPanel.getMedName();
            String category = inventoryPanel.getCategory();
            int stock = inventoryPanel.getStock();
            double price = Double.parseDouble(inventoryPanel.getPrice());

            Medication updatedMed = new Medication(
                    selectedMedication.getId(),
                    medName, category, stock, price
            );

            if (medicationDAO.updateMedication(updatedMed)) {
                JOptionPane.showMessageDialog(inventoryPanel, "Data obat berhasil diupdate!");
                inventoryPanel.clearForm();
                loadMedicationTable();
                selectedMedication = null;
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal mengupdate obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inventoryPanel, "Harga harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Method untuk menghapus obat ---
    private void deleteMedication() {
        if (selectedMedication == null) {
            JOptionPane.showMessageDialog(inventoryPanel, "Pilih obat yang ingin dihapus dari tabel.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(inventoryPanel, "Yakin hapus obat " + selectedMedication.getName() + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (medicationDAO.deleteMedication(selectedMedication.getId())) {
                JOptionPane.showMessageDialog(inventoryPanel, "Obat berhasil dihapus!");
                inventoryPanel.clearForm();
                loadMedicationTable();
                selectedMedication = null;
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal menghapus obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
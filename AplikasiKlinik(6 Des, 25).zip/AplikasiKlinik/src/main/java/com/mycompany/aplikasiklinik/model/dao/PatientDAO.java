/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Patient;

/**
 *
 * @author LENOVO
 */
public class PatientDAO {
    // Mengembalikan ID Pasien yang baru dibuat
    public int addPatient(Patient p) {
        String sql = "INSERT INTO patients (name, nik, birth_date, gender, address, phone_number) VALUES (?, ?, ?, ?, ?, ?)";
        int generatedId = 0;

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, p.getName());
            stmt.setString(2, p.getNik());
            stmt.setDate(3, java.sql.Date.valueOf(p.getBirthDate()));
            stmt.setString(4, p.getGender());
            stmt.setString(5, p.getAddress());
            stmt.setString(6, p.getPhoneNumber());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedId = rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Penting untuk debugging
            // Jangan hanya mengembalikan 0, tapi log error atau lempar exception
            // Tergantung pendekatan error handling Anda
        }
        return generatedId;
    }
    
    // Diperlukan Controller untuk menampilkan nama Pasien di antrian
    public Patient getPatientById(int id) {
        String sql = "SELECT * FROM patients WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Patient p = new Patient();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setNik(rs.getString("nik"));
                p.setBirthDate(rs.getDate("birth_date").toLocalDate());
                p.setGender(rs.getString("gender"));
                p.setAddress(rs.getString("address"));
                p.setPhoneNumber(rs.getString("phone_number"));
                return p;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ... (getAllPatients methods)
    public List<Patient> getAllPatients() { /* ... */ return new ArrayList<>(); }
}

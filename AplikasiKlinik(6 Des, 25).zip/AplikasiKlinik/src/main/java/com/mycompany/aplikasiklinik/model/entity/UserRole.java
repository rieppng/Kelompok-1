/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

/**
 *
 * @author LENOVO
 */
public enum UserRole {
    SUPERADMIN("Super Admin"),
    RECEPTIONIST("Resepsionis"),
    DOCTOR("Dokter"),
    PHARMACIST("Apoteker"),
    CASHIER("Kasir");

    private final String displayName;

    UserRole(String displayName) {
        this.displayName = displayName;
    }

    // Method untuk mendapatkan nama yang enak dibaca di GUI
    @Override
    public String toString() {
        return displayName;
    }
}

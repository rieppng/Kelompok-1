/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktiikum_9;

/**
 *
 * @author nasywa
 */
public class Praktiikum_9 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

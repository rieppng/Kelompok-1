package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.MedicationDAO;
import com.mycompany.aplikasiklinik.model.entity.Medication;
import com.mycompany.aplikasiklinik.view.InventoryPanel;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import com.mycompany.aplikasiklinik.model.dao.PrescriptionItemDAO;
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;
import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO; // Import AppointmentDAO
import com.mycompany.aplikasiklinik.model.dao.AppointmentServiceDAO; // Import AppointmentServiceDAO (jika ingin update status pasien setelah proses semua item)

/**
 *
 * @author LENOVO
 */
public class InventoryController {
    private final InventoryPanel inventoryPanel;
    private final MedicationDAO medicationDAO;
    private final PrescriptionItemDAO prescriptionItemDAO;
    private final AppointmentDAO appointmentDAO; // Tambahkan AppointmentDAO
    // private final AppointmentServiceDAO appointmentServiceDAO; // Mungkin tidak perlu jika hanya update status dari appointment_id
    private Medication selectedMedication; // Menyimpan obat yang dipilih dari tabel inventaris

    public InventoryController(InventoryPanel inventoryPanel) {
        this.inventoryPanel = inventoryPanel;
        this.medicationDAO = new MedicationDAO(); 
        this.prescriptionItemDAO = new PrescriptionItemDAO();
        this.appointmentDAO = new AppointmentDAO(); // Inisialisasi

        // Muat data awal saat controller dibuat
        loadMedicationTable();
        loadIncomingPrescriptionTable(); // Panggil saat inisialisasi untuk mengisi tabel bawah
        
        // Hubungkan event listener ke tombol-tombol di panel
        this.inventoryPanel.getBtnAddMed().addActionListener(e -> addMedication());
        this.inventoryPanel.getBtnUpdateMed().addActionListener(e -> updateMedication());
        this.inventoryPanel.getBtnDeleteMed().addActionListener(e -> deleteMedication());
        this.inventoryPanel.getBtnProcessPrescription().addActionListener(e -> processIncomingPrescriptions()); // Tombol proses resep

        // Hubungkan event listener ke tabel untuk penanganan pemilihan baris
        this.inventoryPanel.getTableInventory().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
    }

    // --- METHOD UNTUK MEMUAT TABEL RESEP MASUK ---
    public void loadIncomingPrescriptionTable() {
        DefaultTableModel model = inventoryPanel.getIncomingPrescriptionModel(); // Ambil model dari tabel bawah
        model.setRowCount(0); // Kosongkan tabel

        List<PrescriptionItem> pendingItems = prescriptionItemDAO.getPendingPrescriptions(); // Ambil dari DAO (sudah diurutkan)

        if (pendingItems != null && !pendingItems.isEmpty()) {
            for (PrescriptionItem item : pendingItems) {
                // Ambil nama obat dari MedicationDAO
                Medication med = medicationDAO.getMedicationById(item.getMedicationId());
                String medicationName = (med != null) ? med.getName() : "Obat Tidak Ditemukan (ID: " + item.getMedicationId() + ")";
                // Ambil appointment_id dari PrescriptionItemDAO (bisa via medical_record_id)
                // Kita asumsikan kita bisa dapat appointment_id dari PrescriptionItem jika diperlukan untuk tampilan, tapi biasanya tidak langsung disimpan di sana
                // Jika perlu, buat method di PrescriptionItemDAO untuk ambil appointment_id dari medical_record_id
                // int appointmentId = prescriptionItemDAO.getAppointmentIdByMedicalRecordId(item.getMedicalRecordId()); // Method baru di DAO
                // String appointmentIdStr = (appointmentId != -1) ? String.valueOf(appointmentId) : "N/A";

                model.addRow(new Object[]{
                    item.getId(),
                    medicationName, // Nama Obat
                    item.getQuantity(), // Jumlah
                    item.getInstructions(), // Aturan Pakai
                    item.getMedicalRecordId() // ID Rekam Medis
                    // appointmentIdStr // Jika ingin tampilkan appointment_id juga
                });
            }
        } else {
            // Jika tidak ada resep pending, kosongkan tabel
            // Tabel sudah dikosongkan di awal method
        }
    }

    // --- METHOD UNTUK MEMPROSES RESEP ---
    private void processIncomingPrescriptions() {
        // Ambil resep dari tabel UI (sudah diurutkan oleh loadIncomingPrescriptionTable)
        DefaultTableModel incomingModel = inventoryPanel.getIncomingPrescriptionModel();
        if (incomingModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(inventoryPanel, "Tidak ada resep yang perlu diproses.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return; // Keluar jika tidak ada resep
        }

        // Ambil medical_record_id dari item pertama di tabel (karena tabel sudah diurutkan)
        int medicalRecordId = (int) incomingModel.getValueAt(0, 4); // Kolom ke-4 adalah medical_record_id

        // Ambil semua item resep untuk medical_record_id ini dari DB
        List<PrescriptionItem> itemsToProcess = prescriptionItemDAO.getPrescriptionItemsByMedicalRecordId(medicalRecordId);

        if (itemsToProcess == null || itemsToProcess.isEmpty()) {
             JOptionPane.showMessageDialog(inventoryPanel, "Error: Tidak ditemukan item resep untuk ID rekam medis " + medicalRecordId, "Error", JOptionPane.ERROR_MESSAGE);
             return; // Keluar jika tidak ditemukan item untuk ID yang diambil dari UI
        }

        int confirm = JOptionPane.showConfirmDialog(inventoryPanel,
                "Proses " + itemsToProcess.size() + " item resep dari rekam medis ID: " + medicalRecordId + "?",
                "Konfirmasi Proses", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean allSuccess = true;
            StringBuilder errorLog = new StringBuilder();

            // Iterasi setiap item dalam resep
            for (PrescriptionItem item : itemsToProcess) {
                // Ambil data obat untuk cek stok
                Medication med = medicationDAO.getMedicationById(item.getMedicationId());

                if (med == null) {
                    errorLog.append("Obat dengan ID ").append(item.getMedicationId()).append(" tidak ditemukan.\n");
                    allSuccess = false;
                    continue; // Lanjut ke item berikutnya
                }

                // Cek apakah stok cukup
                if (med.getStockQuantity() < item.getQuantity()) {
                    errorLog.append("Stok obat '").append(med.getName()).append("' tidak cukup. Tersedia: ")
                            .append(med.getStockQuantity()).append(", Dibutuhkan: ").append(item.getQuantity()).append("\n");
                    allSuccess = false;
                    continue; // Lanjut ke item berikutnya
                }

                // Kurangi stok
                boolean stockUpdated = medicationDAO.updateStock(item.getMedicationId(), item.getQuantity());
                if (!stockUpdated) {
                    errorLog.append("Gagal mengurangi stok obat '").append(med.getName()).append("'.\n");
                    allSuccess = false;
                    continue; // Lanjut ke item berikutnya
                }

                // Update status item resep menjadi PROCESSED
                boolean statusUpdated = prescriptionItemDAO.updateStatus(item.getId(), "PROCESSED");
                if (!statusUpdated) {
                    errorLog.append("Gagal mengupdate status item resep ID ").append(item.getId()).append(".\n");
                    allSuccess = false;
                    // Jika satu item gagal update status, mungkin perlu rollback stok?
                    // Untuk sederhananya, kita lanjutkan saja, tapi log errornya
                }
            }

            if (allSuccess) {
                // Jika semua item berhasil diproses, update status appointment ke IN_CASHIER
                int appointmentId = prescriptionItemDAO.getAppointmentIdByMedicalRecordId(medicalRecordId);
                if (appointmentId != -1) {
                    boolean appointmentStatusUpdated = appointmentDAO.updateStatus(appointmentId, "IN_CASHIER");
                    if (!appointmentStatusUpdated) {
                        // Log error jika update status appointment gagal
                        JOptionPane.showMessageDialog(inventoryPanel, "Item resep diproses, tetapi gagal memperbarui status pasien ke IN_CASHIER.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(inventoryPanel, "Item resep diproses, tetapi appointment ID tidak ditemukan untuk rekam medis " + medicalRecordId + ".", "Peringatan", JOptionPane.WARNING_MESSAGE);
                }

                JOptionPane.showMessageDialog(inventoryPanel, "Resep untuk rekam medis ID " + medicalRecordId + " berhasil diproses.");
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Sebagian item resep gagal diproses:\n" + errorLog.toString(), "Error", JOptionPane.ERROR_MESSAGE);
                // Mungkin perlu rollback stok jika ada yang gagal setelah update stok?
                // Untuk sederhananya, kita abaikan rollback di sini.
            }

            // Muat ulang tabel inventaris dan tabel resep masuk untuk mencerminkan perubahan
            loadMedicationTable(); // Refresh stok
            loadIncomingPrescriptionTable(); // Refresh daftar resep yang menunggu
        }
        // Jika confirm == NO_OPTION, tidak ada yang diproses, cukup keluar dari method
    }


    // --- Method untuk memuat data obat ke tabel atas ---
    private void loadMedicationTable() {
        DefaultTableModel model = inventoryPanel.getInventoryModel();
        model.setRowCount(0); // Kosongkan tabel sebelum diisi

        List<Medication> meds = medicationDAO.getAllMedications();
        if (meds != null) { 
            for (Medication med : meds) {
                model.addRow(new Object[]{
                        med.getId(),
                        med.getName(),
                        med.getCategory(),
                        med.getStockQuantity(),
                        med.getPrice()
                });
            }
        } else {
             JOptionPane.showMessageDialog(inventoryPanel, "Gagal memuat data obat dari database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- Method untuk menangani pemilihan baris di tabel atas (inventaris) ---
    private void tableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && inventoryPanel.getTableInventory().getSelectedRow() != -1) {
            int row = inventoryPanel.getTableInventory().getSelectedRow();
            DefaultTableModel model = inventoryPanel.getInventoryModel();

            int id = (int) model.getValueAt(row, 0);

            selectedMedication = new Medication(
                    id,
                    (String) model.getValueAt(row, 1), // Nama
                    (String) model.getValueAt(row, 2), // Kategori
                    (int) model.getValueAt(row, 3),    // Stok
                    (double) model.getValueAt(row, 4)  // Harga
            );
            
            // Isi form input
            inventoryPanel.getTxtMedName().setText(selectedMedication.getName());
            inventoryPanel.getComboCategory().setSelectedItem(selectedMedication.getCategory());
            inventoryPanel.getSpinStock().setValue(selectedMedication.getStockQuantity());
            inventoryPanel.getTxtPrice().setText(String.valueOf(selectedMedication.getPrice()));

            // Aktifkan tombol
            inventoryPanel.getBtnUpdateMed().setEnabled(true);
            inventoryPanel.getBtnDeleteMed().setEnabled(true);

        } else if (!e.getValueIsAdjusting() && inventoryPanel.getTableInventory().getSelectedRow() == -1) {
            inventoryPanel.getBtnUpdateMed().setEnabled(false);
            inventoryPanel.getBtnDeleteMed().setEnabled(false);
        }
    }

    // --- Method untuk menambah obat baru ---
    private void addMedication() {
        try {
            String medName = inventoryPanel.getMedName();
            String category = inventoryPanel.getCategory();
            int stock = inventoryPanel.getStock();
            double price = Double.parseDouble(inventoryPanel.getPrice());

            if (medName.isEmpty() || price <= 0) {
                JOptionPane.showMessageDialog(inventoryPanel, "Nama dan Harga harus diisi dengan benar!", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Medication newMed = new Medication(0, medName, category, stock, price);

            if (medicationDAO.addMedication(newMed)) {
                JOptionPane.showMessageDialog(inventoryPanel, "Obat berhasil ditambahkan!");
                inventoryPanel.clearForm();
                loadMedicationTable();
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal menambahkan obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inventoryPanel, "Harga harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Method untuk mengupdate data obat ---
    private void updateMedication() {
        if (selectedMedication == null) {
            JOptionPane.showMessageDialog(inventoryPanel, "Pilih obat yang ingin diupdate dari tabel.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String medName = inventoryPanel.getMedName();
            String category = inventoryPanel.getCategory();
            int stock = inventoryPanel.getStock();
            double price = Double.parseDouble(inventoryPanel.getPrice());

            Medication updatedMed = new Medication(
                    selectedMedication.getId(),
                    medName, category, stock, price
            );

            if (medicationDAO.updateMedication(updatedMed)) {
                JOptionPane.showMessageDialog(inventoryPanel, "Data obat berhasil diupdate!");
                inventoryPanel.clearForm();
                loadMedicationTable();
                selectedMedication = null;
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal mengupdate obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inventoryPanel, "Harga harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Method untuk menghapus obat ---
    private void deleteMedication() {
        if (selectedMedication == null) {
            JOptionPane.showMessageDialog(inventoryPanel, "Pilih obat yang ingin dihapus dari tabel.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(inventoryPanel, "Yakin hapus obat " + selectedMedication.getName() + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (medicationDAO.deleteMedication(selectedMedication.getId())) {
                JOptionPane.showMessageDialog(inventoryPanel, "Obat berhasil dihapus!");
                inventoryPanel.clearForm();
                loadMedicationTable();
                selectedMedication = null;
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal menghapus obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
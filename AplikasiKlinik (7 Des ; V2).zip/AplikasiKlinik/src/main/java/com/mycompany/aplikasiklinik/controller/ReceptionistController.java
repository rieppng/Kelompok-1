/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// File: com/mycompany/aplikasiklinik/controller/ReceptionistController.java (diupdate)
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalSpecialtyDAO; // Import DAO baru
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty; // Import entitas baru
import com.mycompany.aplikasiklinik.view.ReceptionistPanel;

import java.time.LocalDate;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class ReceptionistController {
    private final ReceptionistPanel receptionistPanel;
    private final UserDAO userDAO;
    private final PatientDAO patientDAO;
    private final AppointmentDAO appointmentDAO;
    private final MedicalSpecialtyDAO specialtyDAO; // DAO baru

    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 6000;

    public ReceptionistController(ReceptionistPanel receptionistPanel) {
        this.receptionistPanel = receptionistPanel;
        this.userDAO = new UserDAO();
        this.patientDAO = new PatientDAO();
        this.appointmentDAO = new AppointmentDAO();
        this.specialtyDAO = new MedicalSpecialtyDAO(); // Inisialisasi

        loadSpecialtiesList(); // Muat daftar poli ke combo box
        loadQueueList();

        receptionistPanel.getBtnAddToQueue().addActionListener(e -> handleAddToQueue());
        // Tambahkan listener untuk refresh dokter aktif saat pilih poli
        receptionistPanel.getComboSpecialty().addActionListener(e -> loadActiveDoctorsForSelectedSpecialty());
        // Tambahkan listener untuk tombol refresh dokter
        receptionistPanel.getBtnRefreshDoctorList().addActionListener(e -> loadActiveDoctorsForSelectedSpecialty());
        startAutoRefresh();
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> loadQueueList());
        refreshTimer.start();
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    private void loadSpecialtiesList() {
        List<MedicalSpecialty> specialties = specialtyDAO.getAllSpecialties();
        DefaultComboBoxModel<MedicalSpecialty> model = new DefaultComboBoxModel<>();
        for (MedicalSpecialty specialty : specialties) {
            model.addElement(specialty);
        }
        receptionistPanel.getComboSpecialty().setModel(model);
        // Reset combo dokter aktif jika combo poli berubah
        receptionistPanel.getComboActiveDoctor().setModel(new DefaultComboBoxModel<>());
    }

    // Method untuk memuat dokter aktif berdasarkan poli yang dipilih
    private void loadActiveDoctorsForSelectedSpecialty() {
        MedicalSpecialty selectedSpecialty = (MedicalSpecialty) receptionistPanel.getComboSpecialty().getSelectedItem();
        if (selectedSpecialty == null) {
            // Jika tidak ada poli dipilih, kosongkan combo dokter
            receptionistPanel.getComboActiveDoctor().setModel(new DefaultComboBoxModel<>());
            return;
        }

        // Ambil dokter aktif dari database berdasarkan poli
        List<User> activeDoctorsInSpecialty = userDAO.getActiveDoctorsBySpecialtyId(selectedSpecialty.getId()); // Method di UserDAO sudah diupdate

        DefaultComboBoxModel<User> model = new DefaultComboBoxModel<>();
        for (User doctor : activeDoctorsInSpecialty) {
            // Karena query di DAO sudah filter yang aktif, kita tinggal tambahkan ke model
            model.addElement(doctor);
        }

        receptionistPanel.getComboActiveDoctor().setModel(model);

        // Jika tidak ada dokter aktif, beri pesan opsional
        if (model.getSize() == 0) {
            JOptionPane.showMessageDialog(receptionistPanel, "Tidak ada dokter aktif untuk poli ini saat ini.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void loadQueueList() {
        // Mendapatkan semua antrian yang belum selesai hari ini
        List<Appointment> waitingList = appointmentDAO.getAppointmentsByDate(LocalDate.now());

        receptionistPanel.getQueueModel().setRowCount(0);

        for (Appointment app : waitingList) {
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            User doctor = userDAO.getUserById(app.getDoctorId()); // Pastikan UserDAO getUserById mengembalikan objek User dengan nama lengkap

            String patientName = (patient != null) ? patient.getName() : "Pasien Error";
            String doctorName = (doctor != null) ? doctor.getFullName() : "Dokter Error"; // Gunakan getFullName

            receptionistPanel.getQueueModel().addRow(new Object[]{
                app.getQueueNumber(),
                patientName,
                doctorName,
                app.getStatus()
            });
        }
    }

    private void handleAddToQueue() {
        // Ambil ID dokter dari comboActiveDoctor
        String doctorIdStr = receptionistPanel.getSelectedDoctorId();
        if (doctorIdStr == null) { // Cek apakah dokter dipilih
             JOptionPane.showMessageDialog(receptionistPanel, "Pilih dokter aktif dari daftar!", "Peringatan", JOptionPane.WARNING_MESSAGE);
             return;
        }

        // Ambil data pasien dari panel
        String name = receptionistPanel.getPatientName().trim();
        String nik = receptionistPanel.getNik().trim();
        LocalDate birthDate = receptionistPanel.getDob();
        String phone = receptionistPanel.getPhone().trim();
        String address = receptionistPanel.getAddress().trim();
        String weightStr = receptionistPanel.getWeight().trim();
        String heightStr = receptionistPanel.getPatientHeight().trim();
        String bloodPressure = receptionistPanel.getBloodPressure().trim(); // Ambil tekanan darah
        int doctorId = Integer.parseInt(doctorIdStr); // Konversi ID dokter

        if (name.isEmpty() || nik.isEmpty() || phone.isEmpty() || address.isEmpty() ||
            weightStr.isEmpty() || heightStr.isEmpty() || birthDate == null) { // Hapus pengecekan doctorIdStr karena sudah dicek di awal

            JOptionPane.showMessageDialog(receptionistPanel, "Semua kolom wajib diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double weight = Double.parseDouble(weightStr);
            double height = Double.parseDouble(heightStr);
            // Tekanan darah bisa kosong, jadi tidak perlu di-parse

            Patient newPatient = new Patient(0, name, nik, birthDate, "L", address, phone); // Tambahkan gender

            int newPatientId = patientDAO.addPatient(newPatient);

            if (newPatientId > 0) {
                Appointment newAppt = new Appointment();
                newAppt.setPatientId(newPatientId);
                newAppt.setDoctorId(doctorId); // Gunakan ID dokter yang dipilih
                newAppt.setDate(LocalDate.now());
                newAppt.setWeight(weight);
                newAppt.setHeight(height);
                newAppt.setBloodPressure(bloodPressure); // Simpan tekanan darah
                newAppt.setStatus("WAITING");

                int queueNumber = appointmentDAO.getNextQueueNumber(doctorId, LocalDate.now()); // Gunakan ID dokter
                newAppt.setQueueNumber(queueNumber);

                if (appointmentDAO.addAppointment(newAppt)) {
                    JOptionPane.showMessageDialog(receptionistPanel,
                            "Pasien " + name + " terdaftar! No. Antrian: " + queueNumber);

                    receptionistPanel.clearForm(); // Bersihkan form setelah sukses
                    loadQueueList(); // Refresh tabel antrian
                } else {
                    JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan antrian.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(receptionistPanel, "Gagal menyimpan data pasien.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(receptionistPanel, "Berat dan Tinggi harus berupa angka!", "Error Input", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) { // Catch exception umum lainnya
            JOptionPane.showMessageDialog(receptionistPanel, "Gagal menambahkan pasien/antrian: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
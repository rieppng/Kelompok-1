package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.MedicalSpecialty; // Import entitas
import com.mycompany.aplikasiklinik.model.entity.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import com.toedter.calendar.JDateChooser;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class ReceptionistPanel extends JPanel {

    // --- Komponen Atas: Pemilihan Poli dan Dokter ---
    private final JComboBox<MedicalSpecialty> comboSpecialty = new JComboBox<>();
    private final JComboBox<User> comboActiveDoctor = new JComboBox<>(); // Hanya dokter aktif
    private final JButton btnRefreshDoctorList = new JButton("Refresh Dokter");

    // --- Komponen Tengah: Form dan Tabel ---
    // --- Komponen Form Pasien ---
    private final JTextField txtName = new JTextField(15);
    private final JTextField txtNik = new JTextField(15);
    private final JDateChooser dateChooserDob = new JDateChooser();
    private final JTextArea txtAddress = new JTextArea(3, 20); // Gunakan scroll pane
    private final JTextField txtPhone = new JTextField(15);
    private final JTextField txtWeight = new JTextField(5);
    private final JTextField txtHeight = new JTextField(5);
    private final JTextField txtBloodPressure = new JTextField(10); // Tambahkan field tekanan darah
    private final JButton btnAddToQueue = new JButton("Daftarkan & Masuk Antrian");

    // --- Komponen Tabel Antrian ---
    private final JTable tableQueue = new JTable();
    private DefaultTableModel queueTableModel;

    public ReceptionistPanel() {
        setLayout(new BorderLayout());

        // --- PANEL ATAS: Pemilihan Poli dan Dokter ---
        JPanel topSelectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Rata kiri
        topSelectionPanel.setBorder(BorderFactory.createTitledBorder("Pilih Poli & Dokter"));

        topSelectionPanel.add(new JLabel("Poli:"));
        topSelectionPanel.add(comboSpecialty);
        topSelectionPanel.add(new JLabel("Dokter:"));
        topSelectionPanel.add(comboActiveDoctor);
        topSelectionPanel.add(btnRefreshDoctorList);

        add(topSelectionPanel, BorderLayout.NORTH);

        // --- PANEL TENGAH: Split Form dan Tabel ---
        // Gunakan JSplitPane untuk membagi form dan tabel secara horizontal
        JSplitPane centerSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        centerSplitPane.setDividerLocation(0.5); // Atur lebar awal 50%-50%
        centerSplitPane.setResizeWeight(0.5); // Agar keduanya resize sama rata

        // --- PANEL KIRI: Form Data Pasien ---
        JPanel formPanel = new JPanel(new BorderLayout()); // Gunakan BorderLayout untuk form
        formPanel.setBorder(BorderFactory.createTitledBorder("Form Pendaftaran Pasien"));

        // Panel input utama (GridLayout untuk label-field)
        JPanel inputFieldsPanel = new JPanel(new GridLayout(0, 2, 5, 5)); // 0 baris fleksibel
        inputFieldsPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Margin dalam

        inputFieldsPanel.add(new JLabel("Nama Pasien:")); inputFieldsPanel.add(txtName);
        inputFieldsPanel.add(new JLabel("NIK/ID:")); inputFieldsPanel.add(txtNik);
        inputFieldsPanel.add(new JLabel("Tanggal Lahir:")); inputFieldsPanel.add(dateChooserDob);
        inputFieldsPanel.add(new JLabel("Alamat:")); inputFieldsPanel.add(new JScrollPane(txtAddress)); // Bungkus dengan JScrollPane
        inputFieldsPanel.add(new JLabel("No HP:")); inputFieldsPanel.add(txtPhone);
        inputFieldsPanel.add(new JLabel("Berat (kg):")); inputFieldsPanel.add(txtWeight);
        inputFieldsPanel.add(new JLabel("Tinggi (cm):")); inputFieldsPanel.add(txtHeight);
        inputFieldsPanel.add(new JLabel("Tekanan Darah:")); inputFieldsPanel.add(txtBloodPressure);

        // Panel tombol (FlowLayout untuk tombol)
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Rata tengah
        buttonPanel.add(btnAddToQueue);

        formPanel.add(inputFieldsPanel, BorderLayout.CENTER); // Tambahkan field ke tengah
        formPanel.add(buttonPanel, BorderLayout.SOUTH); // Tambahkan tombol ke bawah

        // --- PANEL KANAN: Tabel Antrian ---
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Daftar Antrian"));

        queueTableModel = new DefaultTableModel(new Object[]{"No Antrian", "Nama Pasien", "Dokter", "Status"}, 0);
        tableQueue.setModel(queueTableModel);

        tablePanel.add(new JScrollPane(tableQueue), BorderLayout.CENTER); // Tabel di tengah panel kanan

        // Gabungkan panel kiri dan kanan ke split pane
        centerSplitPane.setLeftComponent(formPanel);
        centerSplitPane.setRightComponent(tablePanel);

        // Tambahkan split pane ke tengah panel utama
        add(centerSplitPane, BorderLayout.CENTER);
    }

    // --- Getter untuk komponen atas ---
    public JComboBox<MedicalSpecialty> getComboSpecialty() { return comboSpecialty; }
    public JComboBox<User> getComboActiveDoctor() { return comboActiveDoctor; }
    public JButton getBtnRefreshDoctorList() { return btnRefreshDoctorList; }

    // --- Getter untuk field baru ---
    public String getBloodPressure() { return txtBloodPressure.getText(); }

    // --- Getter untuk komponen form ---
    public String getPatientName() { return txtName.getText(); }
    public String getNik() { return txtNik.getText(); }
    public LocalDate getDob() {
        Date selectedDate = dateChooserDob.getDate();
        if (selectedDate == null) { return null; }
        return selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    public String getAddress() { return txtAddress.getText(); }
    public String getPhone() { return txtPhone.getText(); }
    public String getSelectedDoctorId() {
        User selectedDoctor = (User) comboActiveDoctor.getSelectedItem();
        if (selectedDoctor != null) {
            return String.valueOf(selectedDoctor.getId());
        }
        return null;
    }
    public String getWeight() { return txtWeight.getText(); }
    public String getPatientHeight() { return txtHeight.getText(); }
    public JButton getBtnAddToQueue() { return btnAddToQueue; }

    // --- Getter untuk komponen tabel ---
    public DefaultTableModel getQueueModel() { return queueTableModel; }

    // --- Getter untuk komponen lainnya ---
    public JTextField getTxtName() { return txtName; }
    public JTextField getTxtNik() { return txtNik; }
    public JDateChooser getDateChooserDob() { return dateChooserDob; }
    public JTextArea getTxtAddress() { return txtAddress; }
    public JTextField getTxtPhone() { return txtPhone; }
    public JTextField getTxtWeight() { return txtWeight; }
    public JTextField getTxtHeight() { return txtHeight; }
    public JTextField getTxtBloodPressure() { return txtBloodPressure; }

    public void clearForm() {
        txtName.setText("");
        txtNik.setText("");
        dateChooserDob.setDate(null);
        txtAddress.setText("");
        txtPhone.setText("");
        txtWeight.setText("");
        txtHeight.setText("");
        txtBloodPressure.setText("");
        comboActiveDoctor.setSelectedIndex(-1);
    }
}
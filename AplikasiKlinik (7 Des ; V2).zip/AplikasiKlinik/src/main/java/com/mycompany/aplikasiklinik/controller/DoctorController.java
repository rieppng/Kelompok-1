/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.AppointmentServiceDAO;
import com.mycompany.aplikasiklinik.model.dao.BillDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalRecordDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicationDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO;
import com.mycompany.aplikasiklinik.model.dao.PrescriptionItemDAO;
import com.mycompany.aplikasiklinik.model.dao.ServiceFeeDAO;
import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.AppointmentService;
import com.mycompany.aplikasiklinik.model.entity.ServiceFee;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecord;
import com.mycompany.aplikasiklinik.model.entity.Medication;
import com.mycompany.aplikasiklinik.model.entity.Patient;
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.DoctorPanel;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

public class DoctorController {
    private final DoctorPanel doctorPanel;
    private final AppointmentDAO appointmentDAO;
    private final MedicalRecordDAO medicalRecordDAO;
    private final BillDAO billDAO;
    private final PrescriptionItemDAO prescriptionItemDAO;
    private final AppointmentServiceDAO appointmentServiceDAO;
    private final PatientDAO patientDAO;
    private final MedicationDAO medicationDAO;
    private final ServiceFeeDAO serviceFeeDAO;

    // --- TAMBAHAN: Simpan referensi ke DAO dan ID dokter ---
    private final UserDAO userDAO;
    private final int doctorId;

    private Appointment selectedAppointment;
    private final List<Appointment> waitingListCache;
    private final List<PrescriptionItem> tempPrescriptionList;
    private final List<AppointmentService> tempServiceList;

    private Timer refreshTimer;
    private static final int REFRESH_INTERVAL_MS = 5000;

    // --- CONSTRUCTOR BARU: Menerima UserDAO dan doctorId ---
    public DoctorController(DoctorPanel doctorPanel, UserDAO userDAO, int doctorId) {
        this.doctorPanel = doctorPanel;
        this.appointmentDAO = new AppointmentDAO();
        this.medicalRecordDAO = new MedicalRecordDAO();
        this.billDAO = new BillDAO();
        this.prescriptionItemDAO = new PrescriptionItemDAO();
        this.appointmentServiceDAO = new AppointmentServiceDAO();
        this.patientDAO = new PatientDAO();
        this.medicationDAO = new MedicationDAO();
        this.serviceFeeDAO = new ServiceFeeDAO();

        this.userDAO = userDAO; // Simpan referensi
        this.doctorId = doctorId; // Simpan ID dokter

        this.waitingListCache = new ArrayList<>();
        this.tempPrescriptionList = new ArrayList<>();
        this.tempServiceList = new ArrayList<>();

        loadTreatmentServiceList();
        loadWaitingList();
        setupActionListeners();
        startAutoRefresh();
        updateBtnStartConsultState();

        // --- TAMBAHAN: Listener untuk window closing ---
        javax.swing.SwingUtilities.getWindowAncestor(doctorPanel).addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                // Update status aktif di database saat window ditutup
                userDAO.updateUserActiveStatus(doctorId, false); // Set tidak aktif
            }
        });
    }

    private void setupActionListeners() {
        doctorPanel.getBtnStartConsult().addActionListener(e -> startConsultation());
        doctorPanel.getBtnSaveRecord().addActionListener(e -> saveMedicalRecord());
        doctorPanel.getBtnAddMedication().addActionListener(e -> showAddMedicationDialog());
        
        // GANTI LISTENER: Dari tombol ke ComboBox
        // doctorPanel.getBtnAddSelectedTreatment().addActionListener(e -> addSelectedTreatmentService()); -> DIHAPUS
        doctorPanel.getComboTreatmentService().addActionListener(e -> handleServiceSelection()); // -> DIGANTI

        doctorPanel.getBtnRemoveSelectedPrescription().addActionListener(e -> removeSelectedPrescriptionItem());
        doctorPanel.getTableWaitingList().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> {
            if (selectedAppointment == null) {
                loadWaitingList();
            }
        });
        refreshTimer.start();
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    private void loadWaitingList() {
        DefaultTableModel model = doctorPanel.getWaitingListModel();
        model.setRowCount(0);

        User currentDoctor = SessionManager.getInstance().getCurrentUser();
        if (currentDoctor == null) return;

        waitingListCache.clear();
        waitingListCache.addAll(appointmentDAO.getWaitingListByDoctor(currentDoctor.getId(), LocalDate.now()));
        for (Appointment app : waitingListCache) {
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            String patientName = (patient != null) ? patient.getName() : "Pasien Tidak Ditemukan (ID: " + app.getPatientId() + ")";
            model.addRow(new Object[]{
                app.getQueueNumber(),
                patientName,
                app.getStatus()
            });
        }
    }

    private void loadTreatmentServiceList() {
        List<ServiceFee> services = serviceFeeDAO.getAllServiceFees();
        DefaultComboBoxModel<ServiceFee> model = new DefaultComboBoxModel<>();
        if (services != null) {
            for (ServiceFee service : services) {
                model.addElement(service);
            }
        }
        doctorPanel.getComboTreatmentService().setModel(model);
        
        // --- PERBAIKAN 1: Set Index ke -1 agar kosong saat awal ---
        doctorPanel.getComboTreatmentService().setSelectedIndex(-1);
    }

    private void tableSelectionChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting() || selectedAppointment != null) {
            if (doctorPanel.getTableWaitingList().getSelectedRow() != -1 && selectedAppointment != null) {
                doctorPanel.getTableWaitingList().clearSelection();
                JOptionPane.showMessageDialog(doctorPanel, "Anda sedang memeriksa pasien. Simpan rekam medis terlebih dahulu.");
            }
            return;
        }

        int row = doctorPanel.getTableWaitingList().getSelectedRow();
        if (row >= 0 && row < waitingListCache.size()) {
            Appointment selected = waitingListCache.get(row);
            if (!"IN_CONSULTATION".equals(selected.getStatus())) {
                doctorPanel.getBtnStartConsult().setEnabled(true);
            } else {
                doctorPanel.getTableWaitingList().clearSelection();
                doctorPanel.getBtnStartConsult().setEnabled(false);
            }
        } else {
            doctorPanel.getBtnStartConsult().setEnabled(false);
        }
    }

    private void startConsultation() {
        int selectedRow = doctorPanel.getTableWaitingList().getSelectedRow();
        if (selectedRow == -1 || selectedAppointment != null) {
            JOptionPane.showMessageDialog(doctorPanel, "Pilih pasien yang belum diperiksa.");
            return;
        }

        Appointment appToConsult = waitingListCache.get(selectedRow);
        if ("IN_CONSULTATION".equals(appToConsult.getStatus())) {
            JOptionPane.showMessageDialog(doctorPanel, "Pasien ini sedang diperiksa.");
            return;
        }

        if (appointmentDAO.updateStatus(appToConsult.getId(), "IN_CONSULTATION")) {
            appToConsult.setStatus("IN_CONSULTATION");
            selectedAppointment = appToConsult;
            doctorPanel.getBtnStartConsult().setEnabled(false);
            doctorPanel.getTableWaitingList().clearSelection();
            loadWaitingList(); // Refresh tabel
            JOptionPane.showMessageDialog(doctorPanel, "Mulai pemeriksaan untuk Antrian No: " + appToConsult.getQueueNumber());
        } else {
            JOptionPane.showMessageDialog(doctorPanel, "Gagal memperbarui status pasien.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

        private void saveMedicalRecord() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu.");
            return;
        }

        String symptoms = doctorPanel.getSymptoms().trim();
        String diagnosis = doctorPanel.getDiagnosis().trim();
        String treatment = doctorPanel.getTreatment().trim();

        if (symptoms.isEmpty() || diagnosis.isEmpty() || treatment.isEmpty()) {
            JOptionPane.showMessageDialog(doctorPanel, "Semua field gejala, diagnosa, dan tindakan harus diisi.");
            return;
        }

        ServiceFee consultationFeeObj = serviceFeeDAO.getServiceFeeById(1);
        if (consultationFeeObj == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Biaya konsultasi tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            MedicalRecord mr = new MedicalRecord(0, selectedAppointment.getId(), symptoms, diagnosis, treatment, consultationFeeObj.getPrice());
            int medicalRecordId = medicalRecordDAO.addMedicalRecord(mr);

            if (medicalRecordId > 0) {
                double totalMedCost = 0, totalServCost = 0;

                // Simpan Obat
                for (PrescriptionItem item : tempPrescriptionList) {
                    item.setMedicalRecordId(medicalRecordId);
                    item.setStatus("PENDING"); // Pastikan status PENDING
                    prescriptionItemDAO.addPrescriptionItem(item);
                    totalMedCost += item.getSubTotal();
                }

                // Simpan Tindakan Tambahan
                for (AppointmentService service : tempServiceList) {
                    service.setAppointmentId(selectedAppointment.getId()); // Set appointment_id
                    appointmentServiceDAO.addAppointmentService(service);
                    totalServCost += service.getSubTotal();
                }

                Bill newBill = new Bill(0, selectedAppointment.getId(), totalMedCost, totalServCost, consultationFeeObj.getPrice(), false);
                if (billDAO.createBill(newBill)) {
                    // --- PERUBAHAN LOGIKA STATUS DI SINI ---
                    String nextStatus = "IN_PHARMACY"; // Default jika ada obat

                    // Jika tidak ada obat (PENDING) tetapi ada tindakan, langsung ke kasir
                    if (tempPrescriptionList.isEmpty() && !tempServiceList.isEmpty()) {
                        nextStatus = "IN_CASHIER";
                    }
                    // --- BARIS YANG DITAMBAHKAN: Jika tidak ada obat dan tidak ada tindakan, langsung ke kasir ---
                    else if (tempPrescriptionList.isEmpty() && tempServiceList.isEmpty()) {
                        nextStatus = "IN_CASHIER";
                    }
                    // --- AKHIR BARIS YANG DITAMBAHKAN ---

                    appointmentDAO.updateStatus(selectedAppointment.getId(), nextStatus);
                    selectedAppointment = null;

                    String message = "Rekam medis dan tagihan disimpan.";
                    if ("IN_CASHIER".equals(nextStatus)) {
                        message += " Status pasien: IN_CASHIER (langsung ke kasir).";
                    } else {
                        message += " Status pasien: IN_PHARMACY.";
                    }

                    JOptionPane.showMessageDialog(doctorPanel, message);
                    doctorPanel.clearForm();
                    tempPrescriptionList.clear();
                    tempServiceList.clear();

                    doctorPanel.getComboTreatmentService().setSelectedIndex(-1); // Reset combo box

                    loadWaitingList();
                    updateBtnStartConsultState();
                } else {
                    JOptionPane.showMessageDialog(doctorPanel, "Gagal menyimpan tagihan.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(doctorPanel, "Gagal menyimpan rekam medis.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(doctorPanel, "Error saat menyimpan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void showAddMedicationDialog() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu.");
            return;
        }

        List<Medication> meds = medicationDAO.getAllMedications();
        JComboBox<Medication> comboMeds = new JComboBox<>(meds.toArray(new Medication[0]));
        JTextField txtQty = new JTextField("1");
        JTextField txtInstructions = new JTextField();
        final JComponent[] inputs = new JComponent[]{
            new JLabel("Pilih Obat:"), comboMeds,
            new JLabel("Jumlah:"), txtQty,
            new JLabel("Aturan Pakai:"), txtInstructions
        };
        int result = JOptionPane.showConfirmDialog(null, inputs, "Tambah Obat", JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                Medication med = (Medication) comboMeds.getSelectedItem();
                int qty = Integer.parseInt(txtQty.getText());
                String instructions = txtInstructions.getText();

                if (qty <= 0 || qty > med.getStockQuantity()) {
                    JOptionPane.showMessageDialog(doctorPanel, "Jumlah tidak valid atau stok tidak mencukupi.");
                    return;
                }

                PrescriptionItem item = new PrescriptionItem();
                item.setMedicationId(med.getId());
                item.setQuantity(qty);
                item.setInstructions(instructions);
                item.setPriceAtTime(med.getPrice());
                item.setStatus("PENDING"); 

                tempPrescriptionList.add(item);
                doctorPanel.getPrescriptionModel().addRow(new Object[]{"Obat", med.getName(), qty, med.getPrice(), item.getSubTotal(), instructions});
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(doctorPanel, "Jumlah harus angka.");
            }
        }
    }

    // --- PERBAIKAN 2: Mengganti method Tambah Tindakan ---
    private void handleServiceSelection() {
        // Cek apakah item yang dipilih valid (tidak null)
        ServiceFee selectedService = (ServiceFee) doctorPanel.getComboTreatmentService().getSelectedItem();
        
        // Jika null (misal saat reset), atau belum mulai konsultasi, abaikan
        if (selectedService == null) {
            return; 
        }

        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu.");
            // Reset pilihan agar tidak membingungkan
            doctorPanel.getComboTreatmentService().setSelectedIndex(-1);
            return;
        }

        // Langsung tambahkan ke list dengan Qty = 1
        int qty = 1;

        AppointmentService service = new AppointmentService(selectedAppointment.getId(), selectedService.getId(), qty, selectedService.getPrice());
        tempServiceList.add(service);
        
        // Tambahkan ke Tabel UI
        doctorPanel.getPrescriptionModel().addRow(new Object[]{"Tind. Layanan", selectedService.getName(), qty, selectedService.getPrice(), service.getSubTotal(), ""}); 
        
        // --- PENTING: Reset Combo Box agar kosong kembali ---
        // Ini memungkinkan dokter untuk tidak memilih apa-apa lagi (tetap kosong)
        // Atau memilih layanan lain jika diperlukan
        // Kita gunakan invokeLater agar tidak konflik dengan event listener yang sedang berjalan
        javax.swing.SwingUtilities.invokeLater(() -> {
            doctorPanel.getComboTreatmentService().setSelectedIndex(-1);
        });
    }

    private void removeSelectedPrescriptionItem() {
        int selectedRow = doctorPanel.getTablePrescription().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(doctorPanel, "Pilih item yang akan dihapus dari tabel.");
            return;
        }

        DefaultTableModel model = doctorPanel.getPrescriptionModel();
        String jenisItem = (String) model.getValueAt(selectedRow, 0);

        if ("Obat".equals(jenisItem)) {
            tempPrescriptionList.remove(selectedRow);
        } else if ("Tind. Layanan".equals(jenisItem)) {
             String namaItem = (String) model.getValueAt(selectedRow, 1);
             int qtyItem = (Integer) model.getValueAt(selectedRow, 2);
             double hargaItem = (Double) model.getValueAt(selectedRow, 3);
             
             tempServiceList.removeIf(s -> s.getQuantity() == qtyItem && s.getPriceAtTime() == hargaItem && serviceFeeDAO.getServiceFeeById(s.getServiceFeeId()).getName().equals(namaItem));
        }

        model.removeRow(selectedRow);
    }

    private void updateBtnStartConsultState() {
        boolean hasSelection = doctorPanel.getTableWaitingList().getSelectedRow() != -1;
        doctorPanel.getBtnStartConsult().setEnabled(selectedAppointment == null && hasSelection);
    }

    public Appointment getSelectedAppointment() {
        return selectedAppointment;
    }
}
package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdminPanel extends JPanel {
    // Components
    private JTextField txtNewUsername = new JTextField(15);
    private JTextField txtNewPassword = new JTextField(15); // Pakai textfield biasa utk test
    private JTextField txtFullname = new JTextField(20);
    private JComboBox<String> comboRole = new JComboBox<>(new String[]{"DOCTOR", "RECEPTIONIST", "PHARMACIST", "CASHIER", "SUPERADMIN"});
    private JButton btnAddUser = new JButton("Tambah User");
    private JTable tableUsers = new JTable();
    private DefaultTableModel userTableModel;

    public AdminPanel() {
        setLayout(new BorderLayout());
        
        // Form Panel (Top)
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Tambah Staff Baru"));
        formPanel.add(new JLabel("Username:")); formPanel.add(txtNewUsername);
        formPanel.add(new JLabel("Password:")); formPanel.add(txtNewPassword);
        formPanel.add(new JLabel("Nama Lengkap:")); formPanel.add(txtFullname);
        formPanel.add(new JLabel("Role:")); formPanel.add(comboRole);
        formPanel.add(new JLabel("")); formPanel.add(btnAddUser); // Empty label for spacing
        
        add(formPanel, BorderLayout.NORTH);

        // Table Panel (Center)
        userTableModel = new DefaultTableModel(new Object[]{"ID", "Username", "Nama", "Role"}, 0);
        tableUsers.setModel(userTableModel);
        add(new JScrollPane(tableUsers), BorderLayout.CENTER);
    }

    // Getters for Controller
    public String getUsername() { return txtNewUsername.getText(); }
    public String getPassword() { return txtNewPassword.getText(); }
    public String getFullname() { return txtFullname.getText(); }
    public String getSelectedRole() { return (String) comboRole.getSelectedItem(); }
    public JButton getBtnAddUser() { return btnAddUser; }
    public DefaultTableModel getUserTableModel() { return userTableModel; }
    
    public void clearForm() {
        txtNewUsername.setText("");
        txtNewPassword.setText("");
        txtFullname.setText("");
    }
}
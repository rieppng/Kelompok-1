package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class InventoryPanel extends JPanel {
    private JTextField txtMedName = new JTextField();
    private JComboBox<String> comboCategory = new JComboBox<>(new String[]{"Tablet", "Sirup", "Kapsul", "Salep", "Injeksi"});
    private JSpinner spinStock = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
    private JTextField txtPrice = new JTextField();
    
    private JButton btnAddMed = new JButton("Tambah");
    private JButton btnUpdateMed = new JButton("Update Stok/Harga");
    private JButton btnDeleteMed = new JButton("Hapus");
    private JButton btnProcessPrescription;

    private JTable tableInventory = new JTable();
    private DefaultTableModel inventoryModel;

    public InventoryPanel() {
        setLayout(new BorderLayout());

        // Form Input
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Data Obat"));
        inputPanel.add(new JLabel("Nama Obat:")); inputPanel.add(txtMedName);
        inputPanel.add(new JLabel("Kategori:")); inputPanel.add(comboCategory);
        inputPanel.add(new JLabel("Stok:")); inputPanel.add(spinStock);
        inputPanel.add(new JLabel("Harga:")); inputPanel.add(txtPrice);
        
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnAddMed); btnPanel.add(btnUpdateMed); btnPanel.add(btnDeleteMed);
        inputPanel.add(new JLabel("Aksi:")); inputPanel.add(btnPanel);

        add(inputPanel, BorderLayout.NORTH);

        btnProcessPrescription = new JButton("Proses Resep Masuk");
        this.add(btnProcessPrescription);

        // Table
        inventoryModel = new DefaultTableModel(new Object[]{"ID", "Nama", "Kategori", "Stok", "Harga"}, 0);
        tableInventory.setModel(inventoryModel);
        add(new JScrollPane(tableInventory), BorderLayout.CENTER);
    }

    // Getters NILAI (Value Getters, dipakai saat Add/Update)
    public String getMedName() { return txtMedName.getText(); }
    public String getCategory() { return (String) comboCategory.getSelectedItem(); }
    public int getStock() { return (int) spinStock.getValue(); }
    public String getPrice() { return txtPrice.getText(); }
    
    // Getters KOMPONEN (Component Getters, FIX Error 1-4, dipakai saat SelectionChanged)
    public JTextField getTxtMedName() { return txtMedName; }
    public JComboBox<String> getComboCategory() { return comboCategory; }
    public JSpinner getSpinStock() { return spinStock; }
    public JTextField getTxtPrice() { return txtPrice; }
    
    // Getters Aksi dan Tabel
    public JButton getBtnAddMed() { return btnAddMed; }
    public JButton getBtnUpdateMed() { return btnUpdateMed; }
    public JButton getBtnDeleteMed() { return btnDeleteMed; }
    public JButton getBtnProcessPrescription() { return btnProcessPrescription; }

    public JTable getTableInventory() { return tableInventory; }
    public DefaultTableModel getInventoryModel() { return inventoryModel; }

    public void clearForm() {
        txtMedName.setText("");
        comboCategory.setSelectedIndex(0);
        spinStock.setValue(0);
        txtPrice.setText("");
    }
}
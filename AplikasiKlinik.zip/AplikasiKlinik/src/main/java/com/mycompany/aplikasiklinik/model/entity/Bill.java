/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

import java.time.LocalDateTime;

/**
 *
 * @author LENOVO
 */
public class Bill {
    private int id;
    private int appointmentId;  // Kunci utama untuk melacak tagihan siapa
    
    private double totalMedicationCost; // Total harga obat
    private double consultationFee;     // Biaya dokter
    private double totalAmount;         // Grand Total (Obat + Dokter)
    
    private boolean isPaid;             // Status pembayaran
    private LocalDateTime paymentDate;  // Waktu bayar

    public Bill() {}

    public Bill(int id, int appointmentId, double totalMedicationCost, double consultationFee, boolean isPaid) {
        this.id = id;
        this.appointmentId = appointmentId;
        this.totalMedicationCost = totalMedicationCost;
        this.consultationFee = consultationFee;
        this.totalAmount = totalMedicationCost + consultationFee;
        this.isPaid = isPaid;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    public double getTotalMedicationCost() { return totalMedicationCost; }
    public void setTotalMedicationCost(double totalMedicationCost) { 
        this.totalMedicationCost = totalMedicationCost;
        recalculateTotal();
    }

    public double getConsultationFee() { return consultationFee; }
    public void setConsultationFee(double consultationFee) { 
        this.consultationFee = consultationFee;
        recalculateTotal();
    }

    public double getTotalAmount() { return totalAmount; }
    
    // Method helper untuk update total otomatis
    private void recalculateTotal() {
        this.totalAmount = this.totalMedicationCost + this.consultationFee;
    }

    public boolean isPaid() { return isPaid; }
    public void setPaid(boolean paid) { isPaid = paid; }

    public LocalDateTime getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; }
}

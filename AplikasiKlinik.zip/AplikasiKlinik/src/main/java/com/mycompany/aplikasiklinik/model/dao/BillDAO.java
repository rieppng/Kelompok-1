/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Bill;

/**
 *
 * @author LENOVO
 */
public class BillDAO {
    public boolean createBill(Bill bill) {
        String sql = "INSERT INTO bills (appointment_id, total_medication_cost, consultation_fee, total_amount, is_paid) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, bill.getAppointmentId());
            stmt.setDouble(2, bill.getTotalMedicationCost());
            stmt.setDouble(3, bill.getConsultationFee());
            stmt.setDouble(4, bill.getTotalAmount());
            stmt.setBoolean(5, false);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean markAsPaid(int billId) {
        String sql = "UPDATE bills SET is_paid = true, payment_date = NOW() WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, billId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

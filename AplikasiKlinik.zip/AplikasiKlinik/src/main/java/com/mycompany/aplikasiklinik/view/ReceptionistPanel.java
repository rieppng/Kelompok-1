package com.mycompany.aplikasiklinik.view;

import com.mycompany.aplikasiklinik.model.entity.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import com.toedter.calendar.JDateChooser;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class ReceptionistPanel extends JPanel {
    private JTextField txtName = new JTextField(15);
    private JTextField txtNik = new JTextField(15);
    private JDateChooser dateChooserDob = new JDateChooser(); // Ganti dari JTextField
    private JTextArea txtAddress = new JTextArea(3, 20);
    private JTextField txtPhone = new JTextField(15);
    private JComboBox<User> comboDoctor = new JComboBox<>();
    private JTextField txtWeight = new JTextField(5);
    private JTextField txtHeight = new JTextField(5);
    private JButton btnAddToQueue = new JButton("Daftarkan & Masuk Antrian");

    private JTable tableQueue = new JTable();
    private DefaultTableModel queueTableModel;

    public ReceptionistPanel() {
        setLayout(new BorderLayout());

        // --- FORM PANEL (WEST) ---
        JPanel formPanel = new JPanel(new GridLayout(10, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Pendaftaran Pasien"));
        formPanel.setPreferredSize(new Dimension(350, 0));

        formPanel.add(new JLabel("Nama Pasien:")); formPanel.add(txtName);
        formPanel.add(new JLabel("NIK/ID:")); formPanel.add(txtNik);
        formPanel.add(new JLabel("Tgl Lahir:")); formPanel.add(dateChooserDob); // Menggunakan JDateChooser
        formPanel.add(new JLabel("Alamat:")); formPanel.add(new JScrollPane(txtAddress));
        formPanel.add(new JLabel("No HP:")); formPanel.add(txtPhone);
        formPanel.add(new JLabel("Pilih Dokter:")); formPanel.add(comboDoctor);
        formPanel.add(new JLabel("Berat (kg):")); formPanel.add(txtWeight);
        formPanel.add(new JLabel("Tinggi (cm):")); formPanel.add(txtHeight);
        formPanel.add(new JLabel("")); formPanel.add(btnAddToQueue);

        add(formPanel, BorderLayout.WEST);

        // --- TABLE PANEL (CENTER) ---
        queueTableModel = new DefaultTableModel(new Object[]{"No Antrian", "Nama Pasien", "Dokter", "Status"}, 0);
        tableQueue.setModel(queueTableModel);
        add(new JScrollPane(tableQueue), BorderLayout.CENTER);
    }

    // Getters
    public String getPatientName() { return txtName.getText(); }
    public String getNik() { return txtNik.getText(); }
    
    // Getter BARU: Mengkonversi java.util.Date ke java.time.LocalDate
    public LocalDate getDob() { 
        Date selectedDate = dateChooserDob.getDate();
        if (selectedDate == null) {
            return null; // Penting untuk validasi di Controller
        }
        return selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    
    public String getAddress() { return txtAddress.getText(); }
    public String getPhone() { return txtPhone.getText(); }
    public User getSelectedDoctor() { return (User) comboDoctor.getSelectedItem(); }
    public String getWeight() { return txtWeight.getText(); }
    public String getPatientHeight() { return txtHeight.getText(); }
    
    public JButton getBtnAddToQueue() { return btnAddToQueue; }
    public JComboBox<User> getComboDoctor() { return comboDoctor; }
    public DefaultTableModel getQueueModel() { return queueTableModel; }

    public void clearForm() {
        txtName.setText(""); 
        txtNik.setText(""); 
        dateChooserDob.setDate(null); // Clear JDateChooser
        txtAddress.setText(""); 
        txtPhone.setText(""); 
        txtWeight.setText(""); 
        txtHeight.setText("");
        comboDoctor.setSelectedIndex(-1);
    }
}
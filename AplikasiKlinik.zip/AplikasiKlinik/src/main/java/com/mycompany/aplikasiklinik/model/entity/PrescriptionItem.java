/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

/**
 *
 * @author LENOVO
 */
public class PrescriptionItem {
    private int id;
    private int medicalRecordId; // FK ke MedicalRecord
    private int medicationId;    // FK ke Medication (Obat)
    
    private int quantity;        // Jumlah obat
    private double priceAtTime;  // Harga saat transaksi (untuk antisipasi perubahan harga)
    private String instructions; // Misal: "3x1 sesudah makan"
    private String status; // Field Baru untuk status item ("PENDING", "PROCESSED")

    public PrescriptionItem() {}

    public PrescriptionItem(int id, int medicalRecordId, int medicationId, int quantity, double priceAtTime, String instructions, String status) {
        this.id = id;
        this.medicalRecordId = medicalRecordId;
        this.medicationId = medicationId;
        this.quantity = quantity;
        this.priceAtTime = priceAtTime;
        this.instructions = instructions;
        this.status = status;
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Helper method untuk hitung subtotal
    public double getSubTotal() { return quantity * priceAtTime; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMedicalRecordId() { return medicalRecordId; }
    public void setMedicalRecordId(int medicalRecordId) { this.medicalRecordId = medicalRecordId; }

    public int getMedicationId() { return medicationId; }
    public void setMedicationId(int medicationId) { this.medicationId = medicationId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPriceAtTime() { return priceAtTime; }
    public void setPriceAtTime(double priceAtTime) { this.priceAtTime = priceAtTime; }

    public String getInstructions() { return instructions; }
    public void setInstructions(String instructions) { this.instructions = instructions; }
}

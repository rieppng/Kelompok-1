/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;
import com.mycompany.aplikasiklinik.view.AdminPanel;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LENOVO
 */
public class AdminController {
    private AdminPanel adminPanel;
    private UserDAO userDAO;

    public AdminController(AdminPanel adminPanel, UserDAO userDAO) {
        this.adminPanel = adminPanel;
        this.userDAO = userDAO;
        
        // Hubungkan aksi tombol
        this.adminPanel.getBtnAddUser().addActionListener(e -> addUser());
        
        // Load data awal
        loadAllUsers();
    }

    private void addUser() {
        try {
            String username = adminPanel.getUsername();
            String password = adminPanel.getPassword();
            String fullname = adminPanel.getFullname();
            String roleName = adminPanel.getSelectedRole(); // String dari JComboBox
            
            if (username.isEmpty() || password.isEmpty() || fullname.isEmpty()) {
                JOptionPane.showMessageDialog(adminPanel, "Semua field harus diisi!");
                return;
            }
            
            UserRole role = UserRole.valueOf(roleName);
            
            // Catatan: Password hashing harus dilakukan di sini sebelum disimpan
            User newUser = new User(username, password, fullname, role);
            
            if (userDAO.addUser(newUser)) {
                JOptionPane.showMessageDialog(adminPanel, "User berhasil ditambahkan!");
                adminPanel.clearForm();
                loadAllUsers(); // Refresh tabel
            } else {
                JOptionPane.showMessageDialog(adminPanel, "Gagal menambahkan user. Mungkin username sudah ada.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(adminPanel, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void loadAllUsers() {
        DefaultTableModel model = adminPanel.getUserTableModel();
        model.setRowCount(0); // Clear tabel lama
        
        List<User> users = userDAO.getAllUsers();
        for (User user : users) {
            model.addRow(new Object[]{
                user.getId(), 
                user.getUsername(), 
                user.getFullName(), 
                user.getRole().toString() // Menggunakan toString() dari UserRole
            });
        }
    }
}

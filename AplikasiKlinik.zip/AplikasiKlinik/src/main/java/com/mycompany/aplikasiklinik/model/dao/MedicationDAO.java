/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Medication;

/**
 *
 * @author LENOVO
 */
public class MedicationDAO {
    // ADD/CREATE (Perbaikan Error 5)
    public boolean addMedication(Medication med) {
        String sql = "INSERT INTO medications (name, category, stock_quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, med.getName());
            stmt.setString(2, med.getCategory());
            stmt.setInt(3, med.getStockQuantity());
            stmt.setDouble(4, med.getPrice());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // UPDATE (Perbaikan Error 7)
    public boolean updateMedication(Medication med) {
        String sql = "UPDATE medications SET name = ?, category = ?, stock_quantity = ?, price = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, med.getName());
            stmt.setString(2, med.getCategory());
            stmt.setInt(3, med.getStockQuantity());
            stmt.setDouble(4, med.getPrice());
            stmt.setInt(5, med.getId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // DELETE (Perbaikan Error 8)
    public boolean deleteMedication(int id) {
        String sql = "DELETE FROM medications WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // ... (getAllMedications dan updateStock methods)
    public List<Medication> getAllMedications() { /* ... */ return new ArrayList<>(); }
    

    // Fitur untuk mengurangi stok obat setelah resep yang dibuat oleh dokter diracik pharmacist                                                 
    public boolean updateStock(int medicationId, int quantityToDeduct) {
        String sql = "UPDATE medications SET stock_quantity = stock_quantity - ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, quantityToDeduct);
            ps.setInt(2, medicationId);
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.AppointmentDAO;
import com.mycompany.aplikasiklinik.model.dao.BillDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicalRecordDAO;
import com.mycompany.aplikasiklinik.model.dao.MedicationDAO;
import com.mycompany.aplikasiklinik.model.dao.PatientDAO; // IMPORT BARU
import com.mycompany.aplikasiklinik.model.dao.PrescriptionItemDAO;
import com.mycompany.aplikasiklinik.model.entity.Appointment;
import com.mycompany.aplikasiklinik.model.entity.Bill;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecord;
import com.mycompany.aplikasiklinik.model.entity.Medication;
import com.mycompany.aplikasiklinik.model.entity.Patient; // IMPORT BARU
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.DoctorPanel;
import java.time.LocalDate;
import java.util.ArrayList; // IMPORT BARU
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LENOVO
 */
public class DoctorController {
    private DoctorPanel doctorPanel;
    private AppointmentDAO appointmentDAO;
    private MedicalRecordDAO medicalRecordDAO;
    private BillDAO billDAO;
    private PrescriptionItemDAO prescriptionItemDAO;
    private PatientDAO patientDAO; // TAMBAHAN DAO
    private Appointment selectedAppointment;
    private User currentDoctor;
    private MedicationDAO medicationDAO;
    
    // TAMBAHAN: List untuk menyimpan data asli agar index tabel sinkron dengan data
    private List<Appointment> waitingListCache; 
    private List<PrescriptionItem> tempPrescriptionList;
    
    private Timer refreshTimer;
    private final int REFRESH_INTERVAL_MS = 5000;

    public DoctorController(DoctorPanel doctorPanel) {
        this.doctorPanel = doctorPanel;
        this.appointmentDAO = new AppointmentDAO();
        this.medicalRecordDAO = new MedicalRecordDAO();
        this.billDAO = new BillDAO();
        this.prescriptionItemDAO = new PrescriptionItemDAO();
        this.patientDAO = new PatientDAO(); // INISIALISASI
        
        this.currentDoctor = SessionManager.getInstance().getCurrentUser();
        this.waitingListCache = new ArrayList<>(); // INISIALISASI LIST
        
        this.medicationDAO = new MedicationDAO();
        this.tempPrescriptionList = new ArrayList<>();

        loadWaitingList();
        startAutoRefresh();
        
        this.doctorPanel.getBtnStartConsult().addActionListener(e -> startConsultation());
        this.doctorPanel.getBtnSaveRecord().addActionListener(e -> saveMedicalRecord());
        
        this.doctorPanel.getTableWaitingList().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
        this.doctorPanel.getBtnAddMedication().addActionListener(e -> showAddMedicationDialog());
    }
    
    private void startAutoRefresh() {
        refreshTimer = new Timer(REFRESH_INTERVAL_MS, e -> {
            if (selectedAppointment == null) {
                loadWaitingList(); 
            }
        });
        refreshTimer.start();
    }
    
    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }
    
    public void loadWaitingList() {
        DefaultTableModel model = doctorPanel.getWaitingListModel();
        model.setRowCount(0);
        
        if (currentDoctor == null) return;
        
        // Simpan hasil query ke variabel class 'waitingListCache'
        waitingListCache = appointmentDAO.getWaitingListByDoctor(currentDoctor.getId(), LocalDate.now());
        
        for (Appointment app : waitingListCache) {
            // Ambil Nama Pasien menggunakan PatientDAO
            Patient patient = patientDAO.getPatientById(app.getPatientId());
            String patientName = (patient != null) ? patient.getName() : "Unknown (ID: " + app.getPatientId() + ")";
            
            // Masukkan ke tabel: [Nomor Antrian, Nama Pasien, Status]
            model.addRow(new Object[]{
                app.getQueueNumber(), // Kolom 0: Ganti ID dengan Nomor Antrian
                patientName,          // Kolom 1: Ganti PatientID dengan Nama
                app.getStatus()       // Kolom 2: Status
            });
        }
    }
    
    private void tableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && doctorPanel.getTableWaitingList().getSelectedRow() != -1) {
            int row = doctorPanel.getTableWaitingList().getSelectedRow();
            
            // LOGIKA BARU:
            // Karena tabel sekarang menampilkan No Antrian (bukan ID unik),
            // kita ambil objek Appointment aslinya dari 'waitingListCache' menggunakan index baris.
            if (row < waitingListCache.size()) {
                selectedAppointment = waitingListCache.get(row); // Ambil langsung object aslinya
                doctorPanel.getBtnStartConsult().setEnabled(true);
            }
        }
    }

    private void startConsultation() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Pilih pasien dari antrian!");
            return;
        }
        
        appointmentDAO.updateStatus(selectedAppointment.getId(), "IN_CONSULTATION");
        doctorPanel.getBtnStartConsult().setEnabled(false);
        
        // Refresh tabel manual agar status berubah jadi IN_CONSULTATION di tampilan
        loadWaitingList(); 
        
        JOptionPane.showMessageDialog(doctorPanel, "Mulai pemeriksaan untuk Antrian No: " + selectedAppointment.getQueueNumber());
    }

    private void saveMedicalRecord() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Harap mulai konsultasi terlebih dahulu.");
            return;
        }
        
        String symptoms = doctorPanel.getSymptoms();
        String diagnosis = doctorPanel.getDiagnosis();
        String treatment = doctorPanel.getTreatment();
        double fee = 50000.0; 
        
        if (symptoms.isEmpty() || diagnosis.isEmpty() || treatment.isEmpty()) {
            JOptionPane.showMessageDialog(doctorPanel, "Semua field Rekam Medis harus diisi.");
            return;
        }

        try {
            MedicalRecord mr = new MedicalRecord(0, selectedAppointment.getId(), symptoms, diagnosis, treatment, fee);
            
            int medicalRecordId = medicalRecordDAO.addMedicalRecord(mr);
            
            if (medicalRecordId > 0) {
                
                double totalMedicationCost = 0;

                // Simpan resep ke database
                for (PrescriptionItem item : tempPrescriptionList) {
                    item.setMedicalRecordId(medicalRecordId); // Set ID rekam medis yang baru dibuat
                    prescriptionItemDAO.addPrescriptionItem(item); // Simpan ke tabel prescription_items
                    
                    // Hitung total harga obat untuk tagihan
                    totalMedicationCost += (item.getPriceAtTime() * item.getQuantity());
                }

                Bill newBill = new Bill(0, selectedAppointment.getId(), 0.0, fee, false); 
                billDAO.createBill(newBill);
                
                appointmentDAO.updateStatus(selectedAppointment.getId(), "COMPLETED");
                
                JOptionPane.showMessageDialog(doctorPanel, "Rekam Medis dan Tagihan berhasil disimpan!");
                doctorPanel.clearForm();
                
                selectedAppointment = null; // Reset pilihan
                loadWaitingList(); // Refresh list
                
                // Kosongkan list obat setelah simpan berhasil
                tempPrescriptionList.clear();
            } else {
                 JOptionPane.showMessageDialog(doctorPanel, "Gagal menyimpan Rekam Medis.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(doctorPanel, "Kesalahan saat menyimpan data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Method untuk memunculkan Dialog pilih obat di DoctorPanel
    private void showAddMedicationDialog() {
        if (selectedAppointment == null) {
            JOptionPane.showMessageDialog(doctorPanel, "Mulai konsultasi terlebih dahulu!");
            return;
        }

        // Ambil daftar obat dari DB untuk ditampilkan di ComboBox
        List<Medication> meds = medicationDAO.getAllMedications();
        JComboBox<Medication> comboMeds = new JComboBox<>(meds.toArray(new Medication[0]));
        JTextField txtQty = new JTextField();
        JTextField txtInstructions = new JTextField();

        final JComponent[] inputs = new JComponent[] {
            new javax.swing.JLabel("Pilih Obat:"),
            comboMeds,
            new javax.swing.JLabel("Jumlah:"),
            txtQty,
            new javax.swing.JLabel("Instruksi (Contoh: 3x1 Sesudah makan):"),
            txtInstructions
        };

        int result = JOptionPane.showConfirmDialog(null, inputs, "Tambah Resep Obat", JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                Medication selectedMed = (Medication) comboMeds.getSelectedItem();
                int qty = Integer.parseInt(txtQty.getText());
                String instruction = txtInstructions.getText();

                // Validasi stok sederhana (Optional: Dokter dikasih tahu kalau stok kurang)
                if (qty > selectedMed.getStockQuantity()) {
                    JOptionPane.showMessageDialog(doctorPanel, "Stok tidak cukup! Sisa: " + selectedMed.getStockQuantity());
                    return;
                }

                // Buat object PrescriptionItem (ID Medical Record masih 0/null karena belum disimpan)
                PrescriptionItem item = new PrescriptionItem();
                item.setMedicationId(selectedMed.getId());
                item.setQuantity(qty);
                item.setInstructions(instruction);
                item.setPriceAtTime(selectedMed.getPrice()); // Simpan harga saat ini

                // Masukkan ke list sementara
                tempPrescriptionList.add(item);
                
                JOptionPane.showMessageDialog(doctorPanel, "Obat " + selectedMed.getName() + " ditambahkan ke antrian resep.");

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(doctorPanel, "Jumlah harus angka!");
            }
        }
    }
}
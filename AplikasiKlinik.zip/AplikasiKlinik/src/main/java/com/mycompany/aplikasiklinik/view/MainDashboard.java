package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import java.awt.*;

public class MainDashboard extends JFrame {
    private CardLayout cardLayout = new CardLayout();
    private JPanel mainPanel = new JPanel(cardLayout);
    
    // Instance Panel
    private AdminPanel adminPanel = new AdminPanel();
    private ReceptionistPanel receptionistPanel = new ReceptionistPanel();
    private DoctorPanel doctorPanel = new DoctorPanel();
    private InventoryPanel inventoryPanel = new InventoryPanel();
    private CashierPanel cashierPanel = new CashierPanel();

    private JButton btnLogout = new JButton("Logout");

    public MainDashboard() {
        setTitle("Sistem Informasi Klinik - Dashboard");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.DARK_GRAY);
        JLabel title = new JLabel("  Klinik Sehat Sejahtera");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(title, BorderLayout.WEST);
        headerPanel.add(btnLogout, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Add Panels to CardLayout
        mainPanel.add(adminPanel, "ADMIN");
        mainPanel.add(receptionistPanel, "RECEPTIONIST");
        mainPanel.add(doctorPanel, "DOCTOR");
        mainPanel.add(inventoryPanel, "PHARMACIST");
        mainPanel.add(cashierPanel, "CASHIER");
        
        add(mainPanel, BorderLayout.CENTER);
    }

    // Method untuk ganti tampilan berdasarkan Role
    public void showPanel(String roleName) {
        // Mapping role DB ke nama Card
        switch(roleName) {
            case "SUPERADMIN": cardLayout.show(mainPanel, "ADMIN"); break;
            case "RECEPTIONIST": cardLayout.show(mainPanel, "RECEPTIONIST"); break;
            case "DOCTOR": cardLayout.show(mainPanel, "DOCTOR"); break;
            case "PHARMACIST": cardLayout.show(mainPanel, "PHARMACIST"); break;
            case "CASHIER": cardLayout.show(mainPanel, "CASHIER"); break;
            default: JOptionPane.showMessageDialog(this, "Role tidak dikenali!");
        }
    }

    public JButton getBtnLogout() { return btnLogout; }
    
    // Getters untuk Panel (Supaya Controller bisa akses komponen di dalamnya)
    public AdminPanel getAdminPanel() { return adminPanel; }
    public ReceptionistPanel getReceptionistPanel() { return receptionistPanel; }
    public DoctorPanel getDoctorPanel() { return doctorPanel; }
    public InventoryPanel getInventoryPanel() { return inventoryPanel; }
    public CashierPanel getCashierPanel() { return cashierPanel; }
}
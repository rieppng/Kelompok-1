package com.mycompany.aplikasiklinik.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DoctorPanel extends JPanel {
    // Left Side (Queue)
    private JTable tableWaitingList = new JTable();
    private DefaultTableModel waitingListModel;
    private JButton btnStartConsult = new JButton("Mulai Periksa");

    // Right Side (Consultation)
    private JTextArea txtSymptoms = new JTextArea(3, 20);
    private JTextArea txtDiagnosis = new JTextArea(3, 20);
    private JTextArea txtTreatment = new JTextArea(3, 20);
    private JButton btnAddMedication = new JButton("Tambah Obat (Pop-up)");
    private JTable tablePrescription = new JTable(); // Obat yg diresepkan
    private DefaultTableModel prescriptionModel;
    private JButton btnSaveRecord = new JButton("Simpan Rekam Medis");

    public DoctorPanel() {
        setLayout(new GridLayout(1, 2)); // Split kiri kanan

        // --- LEFT: WAITING LIST ---
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBorder(BorderFactory.createTitledBorder("Daftar Tunggu Pasien"));
        
        waitingListModel = new DefaultTableModel(new Object[]{"Nomor Antrian", "Nama Pasien", "Status"}, 0);
        tableWaitingList.setModel(waitingListModel);
        
        leftPanel.add(new JScrollPane(tableWaitingList), BorderLayout.CENTER);
        leftPanel.add(btnStartConsult, BorderLayout.SOUTH);

        // --- RIGHT: EXAMINATION ---
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Form Pemeriksaan"));

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.add(new JLabel("Keluhan/Gejala:")); inputPanel.add(new JScrollPane(txtSymptoms));
        inputPanel.add(new JLabel("Diagnosa:")); inputPanel.add(new JScrollPane(txtDiagnosis));
        inputPanel.add(new JLabel("Tindakan:")); inputPanel.add(new JScrollPane(txtTreatment));
        inputPanel.add(new JLabel("Resep Obat:")); inputPanel.add(btnAddMedication);

        prescriptionModel = new DefaultTableModel(new Object[]{"ID Obat", "Nama Obat", "Qty", "Aturan Pakai"}, 0);
        tablePrescription.setModel(prescriptionModel);

        rightPanel.add(inputPanel, BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(tablePrescription), BorderLayout.CENTER);
        rightPanel.add(btnSaveRecord, BorderLayout.SOUTH);

        add(leftPanel);
        add(rightPanel);
    }

    // Getters
    public JTable getTableWaitingList() { return tableWaitingList; }
    public DefaultTableModel getWaitingListModel() { return waitingListModel; }
    public JButton getBtnStartConsult() { return btnStartConsult; }
    
    public String getSymptoms() { return txtSymptoms.getText(); }
    public String getDiagnosis() { return txtDiagnosis.getText(); }
    public String getTreatment() { return txtTreatment.getText(); }
    
    public JButton getBtnAddMedication() { return btnAddMedication; }
    public DefaultTableModel getPrescriptionModel() { return prescriptionModel; }
    public JButton getBtnSaveRecord() { return btnSaveRecord; }

    public void clearForm() {
        txtSymptoms.setText(""); txtDiagnosis.setText(""); txtTreatment.setText("");
        prescriptionModel.setRowCount(0);
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import com.mycompany.aplikasiklinik.model.dao.MedicationDAO;
import com.mycompany.aplikasiklinik.model.entity.Medication;
import com.mycompany.aplikasiklinik.view.InventoryPanel;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import com.mycompany.aplikasiklinik.model.dao.PrescriptionItemDAO;
import com.mycompany.aplikasiklinik.model.entity.PrescriptionItem;
import java.util.ArrayList;

/**
 *
 * @author LENOVO
 */
public class InventoryController {
    private InventoryPanel inventoryPanel;
    private MedicationDAO medicationDAO;
    private Medication selectedMedication; 
    private PrescriptionItemDAO prescriptionItemDAO;

    public InventoryController(InventoryPanel inventoryPanel) {
        this.inventoryPanel = inventoryPanel;
        this.medicationDAO = new MedicationDAO();
        this.prescriptionItemDAO = new PrescriptionItemDAO();
        
        loadMedicationTable();
        
        this.inventoryPanel.getBtnAddMed().addActionListener(e -> addMedication());
        this.inventoryPanel.getBtnUpdateMed().addActionListener(e -> updateMedication());
        this.inventoryPanel.getBtnDeleteMed().addActionListener(e -> deleteMedication());
        this.inventoryPanel.getBtnProcessPrescription().addActionListener(e -> processIncomingPrescriptions());

        this.inventoryPanel.getTableInventory().getSelectionModel().addListSelectionListener(this::tableSelectionChanged);
    }
    
    private void processIncomingPrescriptions() {
        // 1. Ambil data resep yang PENDING
        List<PrescriptionItem> pendingItems = prescriptionItemDAO.getPendingPrescriptions();

        if (pendingItems.isEmpty()) {
            JOptionPane.showMessageDialog(inventoryPanel, "Tidak ada resep baru yang perlu diproses.");
            return;
        }

        // 2. Tampilkan Konfirmasi
        int confirm = JOptionPane.showConfirmDialog(inventoryPanel, 
            "Ditemukan " + pendingItems.size() + " obat dalam antrian resep.\n" +
            "Proses dan kurangi stok sekarang?", 
            "Konfirmasi Apoteker", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            int successCount = 0;
            StringBuilder errorLog = new StringBuilder();

            for (PrescriptionItem item : pendingItems) {
                // Ambil data obat untuk cek stok saat ini (Opsional tapi disarankan)
                // Medication med = medicationDAO.getMedicationById(item.getMedicationId());
                
                // 3. KURANGI STOK DI DATABASE (Pastikan method updateStock ada di MedicationDAO)
                // updateStock: UPDATE medications SET stock = stock - qty WHERE id = ...
                boolean stockUpdated = medicationDAO.updateStock(item.getMedicationId(), item.getQuantity());

                if (stockUpdated) {
                    // 4. JIKA STOK BERHASIL DIKURANGI, UBAH STATUS JADI 'PROCESSED'
                    prescriptionItemDAO.updateStatus(item.getId(), "PROCESSED");
                    successCount++;
                } else {
                    errorLog.append("Gagal memproses Item ID: ").append(item.getId()).append(" (Stok Habis?)\n");
                }
            }

            // 5. Feedback ke User
            String message = successCount + " resep berhasil diproses.";
            if (errorLog.length() > 0) {
                message += "\n\nError:\n" + errorLog.toString();
            }
            
            JOptionPane.showMessageDialog(inventoryPanel, message);
            
            // 6. Refresh tabel inventaris agar stok terbaru terlihat
            loadMedicationTable();
        }
    }

    private void loadMedicationTable() {
        DefaultTableModel model = inventoryPanel.getInventoryModel();
        model.setRowCount(0); 
        
        List<Medication> meds = medicationDAO.getAllMedications();
        for (Medication med : meds) {
            model.addRow(new Object[]{
                med.getId(), 
                med.getName(), 
                med.getCategory(), 
                med.getStockQuantity(), 
                med.getPrice()
            });
        }
    }
    
    private void tableSelectionChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting() && inventoryPanel.getTableInventory().getSelectedRow() != -1) {
            int row = inventoryPanel.getTableInventory().getSelectedRow();
            DefaultTableModel model = inventoryPanel.getInventoryModel();
            
            int id = (int) model.getValueAt(row, 0); 
            
            selectedMedication = new Medication(
                id,
                (String) model.getValueAt(row, 1),
                (String) model.getValueAt(row, 2),
                (int) model.getValueAt(row, 3),
                (double) model.getValueAt(row, 4)
            );
            
            // Menggunakan getter komponen yang diasumsikan ada (FIX Error 1-4)
            inventoryPanel.getTxtMedName().setText(selectedMedication.getName());
            inventoryPanel.getComboCategory().setSelectedItem(selectedMedication.getCategory());
            inventoryPanel.getSpinStock().setValue(selectedMedication.getStockQuantity());
            inventoryPanel.getTxtPrice().setText(String.valueOf(selectedMedication.getPrice()));
            
        }
    }

    private void addMedication() {
        try {
            // Menggunakan getter nilai yang sudah ada di InventoryPanel snippet
            String medName = inventoryPanel.getMedName();
            String category = inventoryPanel.getCategory();
            int stock = inventoryPanel.getStock();
            double price = Double.parseDouble(inventoryPanel.getPrice());
            
            if (medName.isEmpty() || price <= 0) {
                JOptionPane.showMessageDialog(inventoryPanel, "Nama dan Harga harus diisi dengan benar!", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Medication newMed = new Medication(0, medName, category, stock, price);
            
            // FIX Error 5
            if (medicationDAO.addMedication(newMed)) {
                JOptionPane.showMessageDialog(inventoryPanel, "Obat berhasil ditambahkan!");
                inventoryPanel.clearForm();
                loadMedicationTable();
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal menambahkan obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inventoryPanel, "Harga harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void updateMedication() {
        if (selectedMedication == null) {
            JOptionPane.showMessageDialog(inventoryPanel, "Pilih obat yang ingin diupdate dari tabel.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Menggunakan getter nilai yang sudah ada di InventoryPanel snippet
            String medName = inventoryPanel.getMedName();
            String category = inventoryPanel.getCategory();
            int stock = inventoryPanel.getStock();
            double price = Double.parseDouble(inventoryPanel.getPrice());
            
            Medication updatedMed = new Medication(
                selectedMedication.getId(), 
                medName, category, stock, price
            );
            
            // FIX Error 7
            if (medicationDAO.updateMedication(updatedMed)) {
                JOptionPane.showMessageDialog(inventoryPanel, "Data obat berhasil diupdate!");
                inventoryPanel.clearForm();
                loadMedicationTable();
                selectedMedication = null;
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal mengupdate obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inventoryPanel, "Harga harus berupa angka yang valid!", "Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void deleteMedication() {
        if (selectedMedication == null) {
            JOptionPane.showMessageDialog(inventoryPanel, "Pilih obat yang ingin dihapus dari tabel.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(inventoryPanel, "Yakin hapus obat " + selectedMedication.getName() + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            // FIX Error 8
            if (medicationDAO.deleteMedication(selectedMedication.getId())) {
                JOptionPane.showMessageDialog(inventoryPanel, "Obat berhasil dihapus!");
                inventoryPanel.clearForm();
                loadMedicationTable();
                selectedMedication = null;
            } else {
                JOptionPane.showMessageDialog(inventoryPanel, "Gagal menghapus obat.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}

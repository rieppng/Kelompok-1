/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.controller;

import javax.swing.JOptionPane;

import com.mycompany.aplikasiklinik.model.dao.UserDAO;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.util.SessionManager;
import com.mycompany.aplikasiklinik.view.LoginView;
import com.mycompany.aplikasiklinik.view.MainDashboard;

/**
 *
 * @author LENOVO
 */
public class LoginController {
    private final LoginView view;
    private final UserDAO userDAO;

    public LoginController(LoginView view) {
        this.view = view;
        this.userDAO = new UserDAO();
        // Menghubungkan tombol login di view ke method handleLogin
        this.view.getBtnLogin().addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = view.getUsernameInput();
        String password = view.getPasswordInput();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Username dan Password tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Cek Login ke Database menggunakan UserDAO
        User user = userDAO.login(username, password); 

        if (user != null) {
            // 1. Simpan user ke SessionManager
            SessionManager.getInstance().setCurrentUser(user);
            
            // 2. Tutup LoginView dan Buka MainDashboard
            view.dispose();
            MainDashboard dashboard = new MainDashboard();
            
            // Logika Logout
            dashboard.getBtnLogout().addActionListener(e -> {
                // Clear Session
                SessionManager.getInstance().setCurrentUser(null);
                
                // Tutup Dashboard saat ini
                dashboard.dispose();
                
                // Buka kembali Login View
                LoginView newLoginView = new LoginView();
                // PENTING: Inisialisasi controller baru untuk view login yang baru!
                new LoginController(newLoginView); 
                newLoginView.setVisible(true);
            });
            
            // Inisialisasi Controller untuk setiap panel di Dashboard
            // UserDAO di-inject hanya di AdminController karena Admin yang mengelola User
            new AdminController(dashboard.getAdminPanel(), userDAO);
            new ReceptionistController(dashboard.getReceptionistPanel());
            new InventoryController(dashboard.getInventoryPanel());
            new DoctorController(dashboard.getDoctorPanel());
            new CashierController(dashboard.getCashierPanel());

            // 3. Tampilkan Dashboard dan Panel sesuai Role
            dashboard.setVisible(true);
            // Menampilkan panel yang sesuai dengan role user yang berhasil login
            dashboard.showPanel(user.getRole().name());

        } else {
            // Login gagal
            JOptionPane.showMessageDialog(view, "Username atau Password salah!", "Login Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }
}

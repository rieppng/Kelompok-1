/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecord;
import com.mycompany.aplikasiklinik.model.entity.MedicalRecordHistory; // Import DTO Baru
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class MedicalRecordDAO {
    // Method ini mengembalikan ID record yang baru dibuat (untuk keperluan resep)
    public int addMedicalRecord(MedicalRecord mr) {
        // HAPUS kolom consultation_fee dari query jika kolom dihapus dari DB
        String sql = "INSERT INTO medical_records (appointment_id, symptoms, diagnosis, treatment) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
             
            stmt.setInt(1, mr.getAppointmentId());
            stmt.setString(2, mr.getSymptoms());
            stmt.setString(3, mr.getDiagnosis());
            stmt.setString(4, mr.getTreatment());
            // stmt.setDouble(5, mr.getConsultationFee()); // HAPUS BARIS INI

            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // Mengembalikan ID
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    // --- METHOD BARU: Ambil Riwayat Lengkap untuk Admin ---
    public List<MedicalRecordHistory> getAllHistory() {
        List<MedicalRecordHistory> list = new ArrayList<>();
        // Query JOIN kompleks untuk mengambil data dari 5 tabel
        String sql = "SELECT mr.id, a.date, p.name AS patient_name, u.full_name AS doctor_name, ms.name AS poli_name, mr.diagnosis, mr.treatment " +
                     "FROM medical_records mr " +
                     "JOIN appointments a ON mr.appointment_id = a.id " +
                     "JOIN patients p ON a.patient_id = p.id " +
                     "JOIN users u ON a.doctor_id = u.id " +
                     "LEFT JOIN medical_specialties ms ON u.medical_specialty_id = ms.id " +
                     "ORDER BY a.date DESC, mr.id DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new MedicalRecordHistory(
                    rs.getInt("id"),
                    rs.getDate("date").toLocalDate(),
                    rs.getString("patient_name"),
                    rs.getString("doctor_name"),
                    rs.getString("poli_name") != null ? rs.getString("poli_name") : "Umum", // Handle null
                    rs.getString("diagnosis"),
                    rs.getString("treatment")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    // --- METHOD BARU: Ambil Daftar Obat per Rekam Medis ---
    public String getPrescriptionDetails(int medicalRecordId) {
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT m.name, pi.quantity, pi.instructions " +
                     "FROM prescription_items pi " +
                     "JOIN medications m ON pi.medication_id = m.id " +
                     "WHERE pi.medical_record_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, medicalRecordId);
            ResultSet rs = ps.executeQuery();
            
            int count = 1;
            while (rs.next()) {
                sb.append(count++).append(". ")
                  .append(rs.getString("name")).append(" (")
                  .append(rs.getInt("quantity")).append(") - ")
                  .append(rs.getString("instructions")).append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        if (sb.length() == 0) return "- Tidak ada resep obat -";
        return sb.toString();
    }

    // --- METHOD BARU: Ambil Daftar Layanan Tambahan per Rekam Medis ---
    // (Note: Layanan terhubung ke appointment_id, jadi kita butuh appointment_id dulu)
    public String getServiceDetails(int appointmentId) {
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT sf.name, aps.quantity " +
                     "FROM appointment_services aps " +
                     "JOIN service_fees sf ON aps.service_fee_id = sf.id " +
                     "WHERE aps.appointment_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            
            int count = 1;
            while (rs.next()) {
                sb.append(count++).append(". ")
                  .append(rs.getString("name")).append(" (")
                  .append(rs.getInt("quantity")).append("x)\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        if (sb.length() == 0) return "- Tidak ada layanan tambahan -";
        return sb.toString();
    }
    
    // --- METHOD BARU: Ambil Detail Pasien (Vital Signs) saat appointment itu ---
    public String getPatientVitals(int appointmentId) {
        String sql = "SELECT weight, height, blood_pressure FROM appointments WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return "Berat: " + rs.getDouble("weight") + " kg, Tinggi: " + 
                       rs.getDouble("height") + " cm, Tensi: " + 
                       rs.getString("blood_pressure");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Data vital tidak ditemukan";
    }
    
    // Helper untuk mendapatkan appointment_id dari medical_record_id
    public int getAppointmentIdByMedicalRecord(int medicalRecordId) {
        String sql = "SELECT appointment_id FROM medical_records WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, medicalRecordId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("appointment_id");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
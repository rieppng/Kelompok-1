/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.entity;

import java.time.LocalDate;

/**
 *
 * @author LENOVO
 */
public class MedicalRecordHistory {
    private int id; // ID Rekam Medis
    private LocalDate date;
    private String patientName;
    private String doctorName;
    private String poliName;
    private String diagnosis;
    private String treatment;

    public MedicalRecordHistory(int id, LocalDate date, String patientName, String doctorName, String poliName, String diagnosis, String treatment) {
        this.id = id;
        this.date = date;
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.poliName = poliName;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
    }

    // Getters
    public int getId() { return id; }
    public LocalDate getDate() { return date; }
    public String getPatientName() { return patientName; }
    public String getDoctorName() { return doctorName; }
    public String getPoliName() { return poliName; }
    public String getDiagnosis() { return diagnosis; }
    public String getTreatment() { return treatment; }
}
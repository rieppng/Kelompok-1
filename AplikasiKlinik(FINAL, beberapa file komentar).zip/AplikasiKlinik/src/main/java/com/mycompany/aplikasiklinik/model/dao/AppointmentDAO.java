/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplikasiklinik.model.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.Appointment;

/**
 *
 * @author LENOVO
 */
public class AppointmentDAO {
    public boolean addAppointment(Appointment app) {
        // Tambahkan kolom consultation_service_fee_id ke query INSERT
        String sql = "INSERT INTO appointments (patient_id, doctor_id, date, queue_number, weight, height, blood_pressure, status, consultation_service_fee_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, app.getPatientId());
            stmt.setInt(2, app.getDoctorId());
            stmt.setDate(3, java.sql.Date.valueOf(app.getDate()));
            stmt.setInt(4, app.getQueueNumber());
            stmt.setDouble(5, app.getWeight());
            stmt.setDouble(6, app.getHeight());
            stmt.setString(7, app.getBloodPressure());
            stmt.setString(8, app.getStatus());
            // Tambahkan ID biaya konsultasi
            stmt.setInt(9, app.getConsultationServiceFeeId()); // Baris ini ditambahkan

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Method untuk DoctorController (getWaitingListByDoctor)
    public List<Appointment> getWaitingListByDoctor(int doctorId, LocalDate date) {
        List<Appointment> list = new ArrayList<>();
        
        // PERBAIKAN 1: Tambahkan 'blood_pressure' ke dalam SELECT query
        String sql = "SELECT id, patient_id, doctor_id, date, queue_number, weight, height, blood_pressure, status FROM appointments WHERE doctor_id = ? AND date = ? AND status IN ('WAITING', 'IN_CONSULTATION') ORDER BY queue_number ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, doctorId);
            stmt.setDate(2, java.sql.Date.valueOf(date));
            
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                // Buat objek Appointment menggunakan Constructor yang ada
                Appointment app = new Appointment(
                    rs.getInt("id"),
                    rs.getInt("patient_id"),
                    rs.getInt("doctor_id"),
                    rs.getDate("date").toLocalDate(),
                    rs.getInt("queue_number"),
                    rs.getDouble("weight"),
                    rs.getDouble("height"),
                    rs.getString("status")
                );
                
                // PERBAIKAN 2: Set nilai blood_pressure secara manual (karena constructor di atas mungkin tidak memuatnya)
                app.setBloodPressure(rs.getString("blood_pressure"));
                
                list.add(app);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public int getNextQueueNumber(int doctorId, LocalDate date) {
        String sql = "SELECT MAX(queue_number) AS max_queue FROM appointments WHERE doctor_id = ? AND date = ?";
        int maxQueue = 0;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, doctorId);
            stmt.setDate(2, Date.valueOf(date));
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getObject("max_queue") != null) {
                maxQueue = rs.getInt("max_queue");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return maxQueue + 1;
    }

    public List<Appointment> getAppointmentsByDate(LocalDate date) {
        List<Appointment> list = new ArrayList<>();
        // Hanya ambil antrian hari ini yang statusnya BELUM selesai
        String sql = "SELECT * FROM appointments WHERE date = ? AND status != 'COMPLETED' ORDER BY queue_number ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setDate(1, Date.valueOf(date));
            
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Appointment app = new Appointment();
                app.setId(rs.getInt("id"));
                app.setPatientId(rs.getInt("patient_id"));
                app.setDoctorId(rs.getInt("doctor_id"));
                app.setDate(rs.getDate("date").toLocalDate());
                app.setQueueNumber(rs.getInt("queue_number"));
                app.setWeight(rs.getDouble("weight"));
                app.setHeight(rs.getDouble("height"));
                app.setStatus(rs.getString("status"));
                list.add(app);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public boolean updateStatus(int id, String status) {
        // Pastikan status yang dikirimkan adalah salah satu dari enum yang didefinisikan di database
        String sql = "UPDATE appointments SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status); // Status baru seperti "IN_PHARMACY", "IN_CASHIER" harus dikenali
            stmt.setInt(2, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method baru untuk mereset status pasien IN_CONSULTATION milik dokter tertentu ke WAITING
    public boolean resetDoctorConsultationStatus(int doctorId) {
        String sql = "UPDATE appointments SET status = 'WAITING' WHERE doctor_id = ? AND status = 'IN_CONSULTATION'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, doctorId); // ID dokter yang logout
            int rowsAffected = stmt.executeUpdate();
            // Jika rowsAffected > 0, artinya ada pasien yang statusnya direset
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Appointment getAppointmentById(int id) {
        String sql = "SELECT id, patient_id, doctor_id, date, queue_number, weight, height, blood_pressure, status, consultation_service_fee_id FROM appointments WHERE id = ?"; // Tambahkan kolom
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Appointment app = new Appointment();
                app.setId(rs.getInt("id"));
                app.setPatientId(rs.getInt("patient_id"));
                app.setDoctorId(rs.getInt("doctor_id"));
                app.setDate(rs.getDate("date").toLocalDate());
                app.setQueueNumber(rs.getInt("queue_number"));
                app.setWeight(rs.getDouble("weight"));
                app.setHeight(rs.getDouble("height"));
                app.setBloodPressure(rs.getString("blood_pressure"));
                app.setStatus(rs.getString("status"));
                // Ambil ID biaya konsultasi
                app.setConsultationServiceFeeId(rs.getInt("consultation_service_fee_id")); // Baris ini ditambahkan
                return app;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

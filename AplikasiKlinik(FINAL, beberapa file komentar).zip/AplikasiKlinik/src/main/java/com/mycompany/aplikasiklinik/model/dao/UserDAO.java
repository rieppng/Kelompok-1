package com.mycompany.aplikasiklinik.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.aplikasiklinik.model.db.DatabaseConnection;
import com.mycompany.aplikasiklinik.model.entity.User;
import com.mycompany.aplikasiklinik.model.entity.UserRole;

public class UserDAO {
    public User login(String username, String password) {
        String sql = "SELECT u.id, u.username, u.password, u.full_name, u.role, u.medical_specialty_id, u.is_active, u.consultation_fee FROM users u WHERE u.username = ? AND u.password = ?"; // Tambahkan kolom
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Gunakan constructor baru
                return new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("full_name"),
                    UserRole.valueOf(rs.getString("role")),
                    rs.getInt("medical_specialty_id"),
                    rs.getBoolean("is_active"),
                    rs.getDouble("consultation_fee") // Ambil biaya konsultasi
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- Method addUser (diupdate) ---
    public boolean addUser(User user) {
        String sql = "INSERT INTO users (username, password, full_name, role, medical_specialty_id, is_active, consultation_fee) VALUES (?, ?, ?, ?, ?, ?, ?)"; // Tambahkan kolom
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getFullName());
            stmt.setString(4, user.getRole().name());
            stmt.setInt(5, user.getMedicalSpecialtyId());
            stmt.setBoolean(6, user.isActive());
            stmt.setDouble(7, user.getConsultationFee()); // Simpan biaya konsultasi

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- Method getAllUsers (diupdate) ---
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT id, username, full_name, role, is_active, consultation_fee FROM users"; // Tambahkan kolom
        try (Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()) {
                list.add(new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    "***", // Sembunyikan password
                    rs.getString("full_name"),
                    UserRole.valueOf(rs.getString("role")),
                    0, // medicalSpecialtyId bisa diambil jika diperlukan
                    rs.getBoolean("is_active"),
                    rs.getDouble("consultation_fee") // Ambil biaya konsultasi
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // --- Method getUserById (diupdate) ---
    public User getUserById(int id) {
        String sql = "SELECT u.id, u.username, u.full_name, u.role, u.medical_specialty_id, u.is_active, u.consultation_fee FROM users u WHERE u.id = ?"; // Tambahkan kolom
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Gunakan constructor baru
                return new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    "***", // Jangan kembalikan password
                    rs.getString("full_name"),
                    UserRole.valueOf(rs.getString("role")),
                    rs.getInt("medical_specialty_id"),
                    rs.getBoolean("is_active"),
                    rs.getDouble("consultation_fee") // Ambil biaya konsultasi
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- Method getDoctors (diupdate) ---
    public List<User> getDoctors() {
        List<User> list = new ArrayList<>();
        // Hanya ambil user dengan role 'DOCTOR', tambahkan kolom consultation_fee
        String sql = "SELECT id, username, full_name, medical_specialty_id, is_active, consultation_fee FROM users WHERE u.role = 'DOCTOR'"; // Tambahkan kolom
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()) {
                // Gunakan constructor User yang menyertakan consultation_fee
                list.add(new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    "***", // Sembunyikan password
                    rs.getString("full_name"),
                    UserRole.DOCTOR, // Role pasti DOCTOR
                    rs.getInt("medical_specialty_id"),
                    rs.getBoolean("is_active"),
                    rs.getDouble("consultation_fee") // Ambil biaya konsultasi
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Method untuk DoctorController (mendapatkan dokter aktif berdasarkan ID Poli)
    public List<User> getActiveDoctorsBySpecialtyId(int specialtyId) {
        // Query ini sekarang mengambil dokter aktif dari database
        String sql = "SELECT u.id, u.username, u.full_name, u.medical_specialty_id, u.is_active, u.consultation_fee FROM users u WHERE u.role = 'DOCTOR' AND u.medical_specialty_id = ? AND u.is_active = TRUE"; // Filter aktif dan tambahkan consultation_fee
        List<User> doctors = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, specialtyId);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                User doctor = new User();
                doctor.setId(rs.getInt("id"));
                doctor.setUsername(rs.getString("username"));
                doctor.setFullName(rs.getString("full_name"));
                doctor.setMedicalSpecialtyId(rs.getInt("medical_specialty_id"));
                doctor.setRole(UserRole.DOCTOR);
                doctor.setActive(rs.getBoolean("is_active")); // Status aktif pasti true karena filter query
                doctor.setConsultationFee(rs.getDouble("consultation_fee")); // Ambil biaya konsultasi
                doctors.add(doctor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctors;
    }

    // Method untuk AdminController (mengupdate user - termasuk dokter)
    public boolean updateUser(User user) {
        String sql = "UPDATE users SET username = ?, full_name = ?, role = ?, medical_specialty_id = ?, is_active = ?, consultation_fee = ? WHERE id = ?"; // Tambahkan kolom consultation_fee
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getFullName());
            stmt.setString(3, user.getRole().name());
            stmt.setInt(4, user.getMedicalSpecialtyId());
            stmt.setBoolean(5, user.isActive());
            stmt.setDouble(6, user.getConsultationFee()); // Update biaya konsultasi
            stmt.setInt(7, user.getId()); // ID user yang diupdate

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method untuk LoginController (update status aktif saat login/logout)
    public boolean updateUserActiveStatus(int userId, boolean isActive) {
        String sql = "UPDATE users SET is_active = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBoolean(1, isActive); // true untuk aktif, false untuk tidak aktif
            stmt.setInt(2, userId);       // ID user yang statusnya diupdate

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // --- METHOD BARU: Get User by Username (Untuk pencarian Admin) ---
    public User getUserByUsername(String username) {
        String sql = "SELECT u.id, u.username, u.full_name, u.role, u.medical_specialty_id, u.is_active, u.consultation_fee FROM users u WHERE u.username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    "***", // Password disembunyikan
                    rs.getString("full_name"),
                    UserRole.valueOf(rs.getString("role")),
                    rs.getInt("medical_specialty_id"),
                    rs.getBoolean("is_active"),
                    rs.getDouble("consultation_fee")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}